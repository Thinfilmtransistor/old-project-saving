# 재무상태표 항목분석

file_pl4 = open('D:\\\Database\\2017\\2017_반기보고서_01_재무상태표_20171102.txt', 'rt')
lines_pl4 = file_pl4.readlines()
length = len(lines_pl4)
f = open('d:\\analysis.txt', 'r+')
now = 0
focus = []
for i in lines_pl4:
    data_list4 = i.split('\t')[:-1]
    compare_data = [data_list4[10], data_list4[11]]
    now = now + 1
    if compare_data not in focus:

        f.write(str(compare_data) + '\n')

        focus.append(compare_data)
        print(now, '/', length)
        print(compare_data)
file_pl4.close()

f.close()

print("end")

