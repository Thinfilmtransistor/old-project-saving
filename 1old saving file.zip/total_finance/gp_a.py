import operator

# 자산총계(비연결) 구하기
file_bs = open('D:\\Database\\2017\\2017_반기보고서_01_재무상태표_20171102.txt', 'rt')
# f = open('D:\\연습용.txt', 'rt')
lines_bs = file_bs.readlines()
length_bs = len(lines_bs)
company_assats = []
for i in range(length_bs):
    data_bs = lines_bs[i]
    data_list = data_bs.split('\t')[:-1]
    if data_list[10] == 'ifrs_Assets':
        assts_list = [data_list[1], data_list[11], data_list[12]]
        company_assats.append(assts_list)
file_bs.close()
# print("자산총계", company_assats)

# 매출총이익(비연결) 구하기
file_pl = open('D:\\Database\\2017\\2017_반기보고서_02_손익계산서_20171102.txt', 'rt')
lines_pl = file_pl.readlines()
length_pl = len(lines_pl)
company_grossprofit = []

for i in range(length_pl):
    data_pl = lines_pl[i]
    data_list = data_pl.split('\t')[:-1]
    if data_list[10] == 'ifrs_GrossProfit':
        gp_list = [data_list[1], data_list[11], data_list[13]]
        company_grossprofit.append(gp_list)
file_pl.close()


file_pl2 = open('D:\\Database\\2017\\2017_반기보고서_03_포괄손익계산서_20171102.txt', 'rt')
lines_pl2 = file_pl2.readlines()
length_pl2 = len(lines_pl2)
for i in range(length_pl2):
    data_pl2 = lines_pl2[i]
    data_list2 = data_pl2.split('\t')[:-1]
    if data_list2[10] == 'ifrs_GrossProfit':
        gp_list2 = [data_list2[1], data_list2[11], data_list2[13]]
        company_grossprofit.append(gp_list2)
file_pl2.close()
# print("매출총이익", company_grossprofit)


# GP/A (비연결) 구하기
company_gp_a = {}
for x in company_grossprofit:
    for y in company_assats:
        if x[0] == y[0]:
            grossprofit_value = x[2].replace(",", "")
            assats_value = y[2].replace(",", "")
            if grossprofit_value == '':
                pass
            else:
                gp_a = float(grossprofit_value) / float(assats_value) * 100
                gp_a = round(gp_a, 1)
                company_gp_a[x[0]] = gp_a


company_gp_a = sorted(company_gp_a.items(), key=operator.itemgetter(1), reverse=True)
print("GP_A     ", company_gp_a)

# 자산총계(연결) 구하기
file_bs5 = open('D:\\Database\\2017\\2017_반기보고서_01_재무상태표_연결_20171102.txt', 'rt')
lines_bs5 = file_bs5.readlines()
length_bs5 = len(lines_bs5)
company_assats_link = []
for i in range(length_bs5):
    data_bs5 = lines_bs5[i]
    data_list5 = data_bs5.split('\t')[:-1]
    if data_list5[10] == 'ifrs_Assets':
        assts_list5 = [data_list5[1], data_list5[11], data_list5[12]]
        company_assats_link.append(assts_list5)
file_bs5.close()
# print("자산총계(연결)", company_assats_link)

#매출총이익(연결) 구하기
company_grossprofit_link = []
file_pl3 = open('D:\\Database\\2017\\2017_반기보고서_02_손익계산서_연결_20171102.txt', 'rt')
lines_pl3 = file_pl3.readlines()
length_pl3 = len(lines_pl3)
for i in range(length_pl3):
    data_pl3 = lines_pl3[i]
    data_list3 = data_pl3.split('\t')[:-1]
    if data_list3[10] == 'ifrs_GrossProfit':
        gp_list3 = [data_list3[1], data_list3[11], data_list3[13]]
        company_grossprofit_link.append(gp_list3)
file_pl3.close()


file_pl4 = open('D:\\Database\\2017\\2017_반기보고서_03_포괄손익계산서_연결_20171102.txt', 'rt')
lines_pl4 = file_pl4.readlines()
length_pl4 = len(lines_pl4)
for i in range(length_pl4):
    data_pl4 = lines_pl4[i]
    data_list4 = data_pl4.split('\t')[:-1]
    if data_list4[10] == 'ifrs_GrossProfit':
        gp_list4 = [data_list4[1], data_list4[11], data_list4[13]]
        company_grossprofit_link.append(gp_list4)
file_pl4.close()
# print("매출총이익(연결)", company_grossprofit_link)

company_gp_a_link = {}
for x2 in company_grossprofit_link:
    for y2 in company_assats_link:
        if x2[0] == y2[0]:
            grossprofit_value = x2[2].replace(',', '')
            assats_value = y2[2].replace(',', '')
            if grossprofit_value == '':
                pass
            else:
                gp_a = float(grossprofit_value) / float(assats_value) * 100
                gp_a = round(gp_a, 1)
                company_gp_a_link[x2[0]] = gp_a

company_gp_a_link = sorted(company_gp_a_link.items(), key=operator.itemgetter(1), reverse=True)
print("GP_A_link", company_gp_a_link)


# 결과 txt파일로 정리
file_1 = open('D:\\company_GP_A.txt','r+')
for company in company_gp_a:
    if company[1] >= 15:

        file_1.write(str(company[0][1:7]) + "\t" + str(company[1]) + "\n")
file_1.close()

file_2 = open('D:\\company_GP_A_link.txt', 'r+')
for company2 in company_gp_a_link:
    if company2[1] >= 15:
        file_2.write(str(company2[0][1:7]) + "\t" + str(company2[1]) + '\n')

file_2.close()