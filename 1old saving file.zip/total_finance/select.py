data = open('D:\\Totaldata.txt', 'r')
select = open('D:\\select.txt', 'r+')
Totaldata = data.readlines()
a = 0
for i in Totaldata:
    temp1 = i.split("\t")
    if 1.5 >= float(temp1[2]) > 1.0:
        select.write(i)
        a = a + 1
        print(a)
    else:
        pass
data.close()
select.close()
