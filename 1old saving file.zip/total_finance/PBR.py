import win32com.client

# GPA가 높은 상위 150 종목의 PBR 구하기
company_data = open('D:\\company_GP_A_link.txt', 'r')
lines = company_data.readlines()
company_code_list = []
company_gp_a_list = []
for i in lines[0:150]:
    temp1 = i.strip('\n')
    temp2 = temp1.split('\t')
    company_code = "A" + temp2[0]
    company_code_list.append(company_code)
    company_gp_a_list.append(temp2[1])

company_data.close()

print(company_code_list)
print(company_gp_a_list)


instMarketEye = win32com.client.Dispatch("cpsysdib.MarketEye")
instMarketEye.SetInputValue(0, (4, 89, 96))  # 사업보고서 BPS 와 분기보고서 BPS
instMarketEye.SetInputValue(1, company_code_list)
instMarketEye.BlockRequest()


company_data = open('D:\\Totaldata.txt', 'r+')
company_data.write("종목코드" + "\t" + "GP/A" + "\t" + "PBR" + "\t" + "사업 BPS" + "\t" + "분기 BPS" + "\t" + "현재가" + "\n")
for j in range(len(company_code_list)):
    company_code = company_code_list[j]
    company_gp_a = company_gp_a_list[j]
    cur_price = instMarketEye.GetDataValue(0, j)
    BPS_1 = instMarketEye.GetDataValue(1, j)   # 사업보고서 BPS
    BPS_2 = instMarketEye.GetDataValue(2, j)   # 분기보고서 BPS
    pbr = round(cur_price / BPS_2, 1)
    company_data.write(str(company_code) + "\t" + str(company_gp_a) + '\t' + str(pbr) + "\t"+ str(BPS_1) + '\t' + str(BPS_2) + '\t' + str(cur_price) + '\n')

company_data.close()
