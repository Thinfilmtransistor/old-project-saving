# import market_capitalization
# market_capitalization.get_maca("kosdaq_목록")

import win32com.client

instMarketEye = win32com.client.Dispatch("cpsysdib.MarketEye")
instMarketEye.SetInputValue(0, (4, 67, 70, 86, 87, 88, 89, 91, 95))  # 사업보고서 BPS 와 분기보고서 BPS
instMarketEye.SetInputValue(1, "A005930")
instMarketEye.BlockRequest()
print("현재가", instMarketEye.GetDataValue(0, 0))
print("PER", instMarketEye.GetDataValue(1, 0))
print("EPS", instMarketEye.GetDataValue(2, 0))
print("매출액", instMarketEye.GetDataValue(3, 0))
print("경상이익", instMarketEye.GetDataValue(4, 0))
print("당기순이익", instMarketEye.GetDataValue(5, 0))
print("BPS", instMarketEye.GetDataValue(6, 0))
print("영업이익", instMarketEye.GetDataValue(7, 0))
print("결산년월", instMarketEye.GetDataValue(8, 0))