# 3분기 영업현금흐름 database 만들기


import operator

f1 = open("E:\\Database\\Data_가공\\2017_반기_영업현금흐름.txt", "r")
com_code = []
cur_cash = []
lines1 = f1.readlines()
for i in lines1:
    temp = i.replace("\n", "")
    temp_list = temp.split("\t")
    cur_cash.append(temp_list[1])
    com_code.append(temp_list[0])
f1.close()

f2 = open("E:\\Database\\Data_가공\\20180119시가총액.txt", "r")
capitalism = []
lines2 = f2.readlines()
for j in lines2:
    temp = j.replace("\n", "")
    capitalism.append(temp)
f2.close()

pcr_dic = {}
for k in range(len(lines1)):
    pcr = float(capitalism[k]) / float(cur_cash[k])
    pcr_dic[com_code[k]] = pcr

pcr_sort = sorted(pcr_dic.items(),key=operator.itemgetter(1), reverse=True)

pcr_rank = []
a = 1
for i in range(len(pcr_dic)):
    pcr_rank.append(pcr_sort[i][0] + "\t" + str(a) + "\n")
    a = a +1

f3 = open("E:\\Database\\pcr_rank.txt", "wt")
for j in pcr_rank:
    f3.write(j)
f3.close()

print(pcr_rank)

f4 = open("E:\\Database\\company.txt", "wt")
for k in com_code:
    f4.write(k + "\n")

f4.close()


