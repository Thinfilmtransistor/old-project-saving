import re
# 영업현금흐름 data 가공

PL_2017 = open("E:\\CurrentAssats\\2017\\2017_3분기보고서_04_현금흐름표_연결_20180131.txt", "r")

Company_code = []
target_list = []
Company_code1 = []


p1 = re.compile("영업활동")
p2 = re.compile("현금")
p3 = re.compile("창출")


while True:
    line = PL_2017.readline()
    if not line:
        break
    temp = line.split("\t")

    m1 = p1.search(temp[11])
    m2 = p2.search(temp[11])
    m3 = p3.search(temp[11])

    if temp[1] not in Company_code1:
        Company_code1.append(temp[1])
    if temp[1] not in Company_code:
        if temp[10] == "ifrs_CashFlowsFromUsedInOperatingActivities":
            if temp[12] == "":
                pass
            else:
                Company_code.append(temp[1])
                target_list.append(temp[1] + "\t" + temp[12] + "\n")
        elif m1 != None and m2 != None and m3 == None:
            if temp[12] == "":
                pass
            else:
                Company_code.append(temp[1])
                target_list.append(temp[1] + "\t" + temp[12] + "\n")

    elif temp[1] in Company_code:
        pass

PL_2017.close()

print(Company_code)
print(Company_code1[1:])

icl = list(set(Company_code1).intersection(Company_code))   # 교집합
sb1 = list(set(Company_code1)-set(icl))  # 차집합
print(sb1)  # 문제가 되는 종목 코드
print(len(target_list))


Lia_2017 = open("E:\\CurrentAssats\\2017_Q3_영업현금흐름_연결.txt", "wt")
for i in target_list:
    Lia_2017.write(i)
Lia_2017.close()
