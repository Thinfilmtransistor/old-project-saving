PL_2017 = open("E:\\Database\\2017\\2017_3분기보고서_01_재무상태표_연결_20180131.txt", "r")
file = PL_2017.readlines()


# 통화종류 확인
def curruncy_type():
    print("화폐종류")
    code_list = []
    day = []
    cur_type = []
    for i in file[1:]:
        temp = i.replace("\n", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if temp[9] != "KRW":
            if code not in code_list:
                code_list.append(code)
                day.append(temp[7])
                cur_type.append(temp[9])

    for i in range(len(code_list)):
        print(code_list[i], day[i], cur_type[i])


# 코드명이 "ifrs_CurrentAssets"이지만 값이 비어있는 line 확인
def check1():
    print("코드명이 'ifrs_CurrentAsset'이지만 값이 비어있는 line")
    for i in file[1:]:
        temp = i.replace("\n", "").replace(",", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if temp[10] == "ifrs_CurrentAssets" and temp[12] == "":
            print(code)


# "ifrs_CurrentAssets"를 사용하지 않는 종목 확인
def check2():
    print("'ifrs_CurrentAssets'를 사용하지 않는 종목")
    com_line = []
    right = []
    for i in file[1:]:
        temp = i.replace("\n", "").replace(",", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if code not in com_line:
            com_line.append(code)
        if temp[10] == "ifrs_CurrentAssets":
            right.append(code)
    for i in com_line:
        if i not in right:
            print(i)


# 예외 항목 유무 검사
def check3(filename):
    # 2016 Q1보고서 당기 유동자산 database화

    PL_2017 = open("E:\\Database\\2017\\" + filename + ".txt", "r")
    file = PL_2017.readlines()

    # 재무상태표의 종목코드list를 만들기
    code_list = []
    for i in file[1:]:
        temp = i.replace("\n", "").replace(",", "").split("\t")
        code = temp[1].replace("[", "A").replace("]", "")
        if code not in code_list:
            code_list.append(code)

    right = []

    def data_insert():
        right.append(code)

    b = 0

    anchoring = []
    data1 = []
    data2 = []
    data3 = []

    for i in file[1:]:
        temp = i.replace("\n", "").replace(",", "").split("\t")
        code = temp[1].replace("[", "A").replace("]", "")

        b = b + 1
        print("phase 2 " + str(b) + "/" + str(len(file[1:])))

        if temp[10] == "ifrs_CurrentAssets" and temp[12] != "":
            data_insert()

        elif temp[10] == "ifrs_CurrentAssets" and temp[12] == "":
            pass

        elif temp[1] == "[008700]":
            if temp[11] == "      현금및현금성자산":
                anchoring.append(temp[7])
                data1.append(temp[12])
            if temp[11] == "      매출채권 및 기타유동채권":
                data1.append(temp[12])
            if temp[11] == "      재고자산":
                data1.append(temp[12])
            if temp[11] == "      당기법인세자산":
                data1.append(temp[12])
            if temp[11] == "      기타유동금융자산":
                data1.append(temp[12])

        elif temp[1] == "[036260]":
            if temp[11] == "   현금및현금성자산":
                anchoring.append(temp[7])
                data2.append(temp[12])
            if temp[11] == "   단기금융상품":
                data2.append(temp[12])
            if temp[11] == "   매출채권 및 기타채권":
                data2.append(temp[12])
            if temp[11] == "   당기법인세자산":
                data2.append(temp[12])
            if temp[11] == "   재고자산":
                data2.append(temp[12])
            if temp[11] == "   기타유동자산":
                data2.append(temp[12])

    exlist = ["A008700", "A036260"]
    excurlist = []

    def get_total(data):
        total = 0
        for i in data:
            if i == "":
                pass
            else:
                total = total + int(i)
        excurlist.append(total)

    get_total(data1)
    get_total(data2)


    for i in range(2):
        right.append(exlist[i])

    print(len(code_list))
    print(len(right))
    for i in code_list:
        if i not in right:
            print(i)

    if len(right) > len(code_list):
        for i in range(len(right) - 1):
            if right[i] == right[i + 1]:
                print(right[i])
                print("140890은 트러스제7호로 3개월마다 사업보고서와 반기보고서를 교대로 제출하고 있다.")
# curruncy_type()
# check1()
# check2()
check3("2017_3분기보고서_01_재무상태표_연결_20180131")