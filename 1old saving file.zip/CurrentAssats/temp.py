PL1 = open("E:\\Database\\2017\\2017_3분기보고서_01_재무상태표_20180131.txt", "r")

file1 = PL1.readlines()
code1 = []
for i in file1[1:]:
    temp = i.split("\t")
    if temp[1] not in code1:
        code1.append(temp[1])


PL2 = open("E:\\Database\\2017\\2017_3분기보고서_01_재무상태표_연결_20180131.txt", "r")
file2 = PL2.readlines()
code2 = []
for i in file2[1:]:
    temp = i.split("\t")
    if temp[1] not in code2:
        code2.append(temp[1])

print("연결 재무상태표에 있으나 별도 재무상태표에 없는 종목")
for i in code2:
    if i not in code1:
        print(i)
print("별도 재무상태표에 있으나 연결 재무상태표에 없는 종목")
for i in code1:
    if i not in code2:
        print(i)
print(len(code1), code1)
print(len(code2), code2)