# 2016 Q1보고서 당기 유동자산 database화
import sqlite3

con = sqlite3.connect("E:/Database/연결유동자산.db")
cursor = con.cursor()

PL_2017 = open("E:\\Database\\2017\\2017_3분기보고서_01_재무상태표_연결_20180131.txt", "r")
file = PL_2017.readlines()

# database의 table list 만들기
com_list = []
cursor.execute('select name from sqlite_master where type="table"')
qd = cursor.fetchall()

for i in qd:
    com_list.append(i[0])

# 재무상태표의 종목코드list를 만들기
code_list = []
for i in file[1:]:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if code not in code_list:
        code_list.append(code)

# 유동자산 database에 없는 종목 table 만들기
a = 0
for i in code_list:
    if i not in com_list:
        cursor.execute("CREATE TABLE " + i + "(결산기준일 text, 유동자산 int)")
        a = a + 1
        print("phase 1 " + str(a) + "/" + str(len(code_list)))
    else:
        pass


exchange1 = 1146.50  # KRW/USD 환율
exchange2 = 172.64  #KRW/CNY 환율

right = []


def data_insert():
    data = [temp[7], int(temp[12])]
    sql = "insert into " + code + "(결산기준일, 유동자산) values (?, ?)"
    cursor.execute(sql, data)
    right.append(code)


b = 0

anchoring = []
data1 = []
data2 = []
data3 = []

for i in file[1:]:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "A").replace("]", "")

    b = b + 1
    print("phase 2 " + str(b) + "/" + str(len(file[1:])))

    if temp[10] == "ifrs_CurrentAssets" and temp[12] != "":
        if temp[9] == "USD":
            data = [temp[7], int(temp[12]) * exchange1]
            sql = "insert into " + code + "(결산기준일, 유동자산) values (?, ?)"
            cursor.execute(sql, data)
            right.append(code)
        elif temp[9] == "CNY":
            data = [temp[7], int(temp[12]) * exchange2]
            sql = "insert into " + code + "(결산기준일, 유동자산) values (?, ?)"
            cursor.execute(sql, data)
            right.append(code)
        else:
            data_insert()

    elif temp[10] == "ifrs_CurrentAssets" and temp[12] == "":
        pass

    elif temp[1] == "[008700]":
        if temp[11] == "      현금및현금성자산":
            anchoring.append(temp[7])
            data1.append(temp[12])
        if temp[11] == "      매출채권 및 기타유동채권":
            data1.append(temp[12])
        if temp[11] == "      재고자산":
            data1.append(temp[12])
        if temp[11] == "      당기법인세자산":
            data1.append(temp[12])
        if temp[11] == "      기타유동금융자산":
            data1.append(temp[12])

    elif temp[1] == "[036260]":
        if temp[11] == "   현금및현금성자산":
            anchoring.append(temp[7])
            data2.append(temp[12])
        if temp[11] == "   단기금융상품":
            data2.append(temp[12])
        if temp[11] == "   매출채권 및 기타채권":
            data2.append(temp[12])
        if temp[11] == "   당기법인세자산":
            data2.append(temp[12])
        if temp[11] == "   재고자산":
            data2.append(temp[12])
        if temp[11] == "   기타유동자산":
            data2.append(temp[12])

exlist = ["A008700", "A036260"]
excurlist = []


def get_total(data):
    total = 0
    for i in data:
        if i == "":
            pass
        else:
            total = total + int(i)
    excurlist.append(total)


get_total(data1)
get_total(data2)

for i in range(2):
    data = [anchoring[i], int(excurlist[i])]
    sql = "insert into " + exlist[i] + "(결산기준일, 유동자산) values (?, ?)"
    cursor.execute(sql, data)
    right.append(exlist[i])

print(len(code_list))
print(len(right))
for i in code_list:
    if i not in right:
        print(i)

con.commit()
