# 2015 사업보고서 당기 유동자산 database화

import sqlite3

con = sqlite3.connect("E:/Database/유동자산.db")
cursor = con.cursor()

PL_2017 = open("E:\\Database\\2015\\2015_사업보고서_01_재무상태표_20160531.txt", "r")
file = PL_2017.readlines()


# database의 table list 만들기
com_list = []
cursor.execute('select name from sqlite_master where type="table"')
qd = cursor.fetchall()

for i in qd:
    com_list.append(i[0])

# 재무상태표의 종목코드list를 만들기
code_list = []
for i in file[1:]:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if code not in code_list:
        code_list.append(code)

# 유동자산 database에 없는 종목 table 만들기
a = 0
for i in code_list:
    if i not in com_list:
        cursor.execute("CREATE TABLE " + i + "(결산기준일 text, 유동자산 int)")
        a = a + 1
        print("phase 1 " + str(a) + "/" + str(len(code_list)))
    else:
        pass

# KRW/USD 환율
exchange = 1177

right = []


def data_insert():
    data = [temp[7], int(temp[12])]
    sql = "insert into " + code + "(결산기준일, 유동자산) values (?, ?)"
    cursor.execute(sql, data)
    right.append(code)


b = 0

anchoring = []
data1 = []
data2 = []
data3 = []
data4 = []
data5 = []

for i in file[1:]:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "A").replace("]", "")

    b = b + 1
    print("phase 2 " + str(b) + "/" + str(len(file[1:])))
    if temp[2] == "레드비씨":
        pass
    elif temp[1] == "[011330]" and temp[7] == "2015-06-30":
        pass
    elif temp[1] == "[007570]" and temp[7] == "2015-03-31":
        pass
    elif temp[1] == "[124500]" and temp[7] == "2015-03-31":
        pass
    elif temp[1] == "[054050]" and temp[7] == "2015-09-30":
        pass
    elif temp[1] == "[040910]" and temp[7] == "2015-09-30":
        pass
    elif temp[1] == "[140890]" and temp[7] == "2015-04-30":
        pass

    elif temp[10] == "ifrs_CurrentAssets" and temp[12] != "":
        if temp[1] == "[900100]":
            data = [temp[7], int(temp[12]) * exchange]
            sql = "insert into " + code + "(결산기준일, 유동자산) values (?, ?)"
            cursor.execute(sql, data)
            right.append(code)
        elif temp[1] == "[950130]":
            data = [temp[7], int(temp[12]) * exchange]
            sql = "insert into " + code + "(결산기준일, 유동자산) values (?, ?)"
            cursor.execute(sql, data)
            right.append(code)
        else:
            data_insert()

    elif temp[10] == "ifrs_CurrentAssets" and temp[12] == "":
        pass

    else:
        if temp[1] == "[025000]" and temp[11] == "   유동자산":
            data_insert()
        if temp[1] == "[000040]" and temp[11] == "   유동자산":
            data_insert()
        if temp[1] == "[065710]" and temp[11] == "   유동자산":
            data_insert()
        if temp[1] == "[115160]" and temp[11] == "   유동자산":
            data_insert()
        if temp[1] == "[004990]" and temp[11] == "   유동 자산":
            data_insert()
        if temp[1] == "[065500]" and temp[11] == "   유동 자산":
            data_insert()

        if temp[1] == "[140910]":
            if temp[11] == "   매출채권 및 기타채권":
                anchoring.append(temp[7])
                data1.append(temp[12])
            if temp[11] == "   현금및현금성자산":
                data1.append(temp[12])
            if temp[11] == "　재고자산":
                data1.append(temp[12])
            if temp[11] == "　기타비유동자산":
                data1.append(temp[12])
        if temp[1] == "[008470]":
            if temp[11] == "   현금및현금성자산":
                anchoring.append(temp[7])
                data2.append(temp[12])
            if temp[11] == "   매출채권 및 기타채권":
                data2.append(temp[12])
            if temp[11] == "   기타금융자산":
                data2.append(temp[12])
            if temp[11] == "   재고자산":
                data2.append(temp[12])
            if temp[11] == "   기타유동자산":
                data2.append(temp[12])
        if temp[1] == "[052190]":
            if temp[11] == "   현금및현금성자산":
                anchoring.append(temp[7])
                data3.append(temp[12])
            if temp[11] == "   기타금융자산":
                data3.append(temp[12])
            if temp[11] == "   매출채권 및 기타채권":
                data3.append(temp[12])
            if temp[11] == "   기타의 유동자산":
                data3.append(temp[12])
        if temp[1] == "[036260]":
            if temp[11] == "   현금및현금성자산":
                anchoring.append(temp[7])
                data4.append(temp[12])
            if temp[11] == "   단기금융상품":
                data4.append(temp[12])
            if temp[11] == "   매출채권 및 기타채권":
                data4.append(temp[12])
            if temp[11] == "   재고자산":
                data4.append(temp[12])
            if temp[11] == "   당기법인세자산":
                data4.append(temp[12])
            if temp[11] == "   기타유동자산":
                data4.append(temp[12])
        if temp[1] == "[008700]":
            if temp[11] == "      현금및현금성자산":
                anchoring.append(temp[7])
                data5.append(temp[12])
            if temp[11] == "      매출채권 및 기타유동채권":
                data5.append(temp[12])
            if temp[11] == "      재고자산":
                data5.append(temp[12])
            if temp[11] == "      당기법인세자산":
                data5.append(temp[12])
            if temp[11] == "      기타유동금융자산":
                data5.append(temp[12])

    if temp[1] == "[008260]" and temp[11] == "   유동자산 합계":
        data_insert()
    if temp[1] == "[008060]" and temp[11] == "      유동자산 합계":
        data_insert()
    if temp[1] == "[033500]" and temp[11] == "      유동자산합계":
        data_insert()
    if temp[1] == "[006040]" and temp[11] == "   유동자산 합계":
        data_insert()
    if temp[1] == "[014820]" and temp[11] == "   유동자산 합계":
        data_insert()
    if temp[1] == "[039670]" and temp[11] == "   유동자산합계":
        data_insert()
    if temp[1] == "[008770]" and temp[11] == "   유동자산 합계":
        data_insert()


exlist = ["A140910", "A008470", "A052190", "A036260", "A008700"]
excurlist = []


def get_total(data):
    total = 0
    for i in data:
        if i == "":
            pass
        else:
            total = total + int(i)
    excurlist.append(total)


get_total(data1)
get_total(data2)
get_total(data3)
get_total(data4)
get_total(data5)

for i in range(5):
    data = [anchoring[i], int(excurlist[i])]
    sql = "insert into " + exlist[i] + "(결산기준일, 유동자산) values (?, ?)"
    cursor.execute(sql, data)
    right.append(exlist[i])

con.commit()

print(len(code_list))
print(len(right))
for i in code_list:
    if i not in right:
        print(i)
