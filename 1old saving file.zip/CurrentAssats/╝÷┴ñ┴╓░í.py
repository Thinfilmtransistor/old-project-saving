import pandas as pd
import sqlite3
import win32com.client
import time


con = sqlite3.connect("E:\\Database\\분기보고서.db")
df = pd.read_sql("SELECT * FROM Y2017Q3", con)
com_list = list(df['index'])
var = len(com_list)
a = 0

for code in com_list:
    instStockChart = win32com.client.Dispatch("CpSysDib.StockChart")

    instStockChart.SetInputValue(0, code)
    instStockChart.SetInputValue(1, ord('1'))
    instStockChart.SetInputValue(3, "20010101")
    # instStockChart.SetInputValue(4, 10)
    instStockChart.SetInputValue(5, (0, 2, 3, 4, 5, 8))
    instStockChart.SetInputValue(6, ord('D'))
    instStockChart.SetInputValue(9, ord('1'))

    instStockChart.BlockRequest()

    numData = instStockChart.GetHeaderValue(3)

    day_list = []
    open_list = []
    high_list = []
    low_list = []
    end_list = []
    volume_list = []

    for i in range(numData):
        day = instStockChart.GetDataValue(0, i)
        open = instStockChart.GetDataValue(1, i)
        high = instStockChart.GetDataValue(2, i)
        low = instStockChart.GetDataValue(3, i)
        end = instStockChart.GetDataValue(4, i)
        volume = instStockChart.GetDataValue(5, i)

        day_list.append(day)
        open_list.append(open)
        high_list.append(high)
        low_list.append(low)
        end_list.append(end)
        volume_list.append(volume)

    df2 = pd.DataFrame({"시가": open_list, "고가": high_list, "저가": low_list, "종가": end_list, "거래량": volume_list}, day_list)

    con2 = sqlite3.connect("E:\\Database\\수정주가.db")
    df2.to_sql(code, con2)
    a = a + 1

    print(str(a) + "/" + str(var))
    time.sleep(1)
