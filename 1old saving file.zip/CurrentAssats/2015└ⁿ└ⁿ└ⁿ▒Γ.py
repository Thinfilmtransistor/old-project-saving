# 2015 사업보고서 전전전기 유동자산 database화

import sqlite3

con = sqlite3.connect("E:/Database/유동자산.db")
cursor = con.cursor()

PL_2017 = open("E:\\Database\\2015\\2015_사업보고서_01_재무상태표_20160531.txt", "r")
file = PL_2017.readlines()

# database의 table list 만들기
com_list = []
cursor.execute('select name from sqlite_master where type="table"')
qd = cursor.fetchall()

for i in qd:
    com_list.append(i[0])

# 재무상태표의 종목코드list를 만들기
code_list = []
for i in file[1:]:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if code not in code_list:
        code_list.append(code)

# 유동자산 database에 없는 종목 table 만들기
a = 0
for i in code_list:
    if i not in com_list:
        cursor.execute("CREATE TABLE " + i + "(결산기준일 text, 유동자산 int)")
        a = a + 1
        print("phase 1 " + str(a) + "/" + str(len(code_list)))
    else:
        pass

# KRW/USD 환율
exchange = 1045

right = []


def data_insert():
    if temp[1] == "[011330]":
        data = ["2013-12-31", int(temp[14])]
        sql = "insert into " + code + "(결산기준일, 유동자산) values (?, ?)"
        cursor.execute(sql, data)
        right.append(code)
    elif temp[1] == "[007570]" or temp[1] == "[124500]" or temp[1] == "[054050]" or temp[1] == "[040910]":
        data = [temp[7].replace("2015", "2013"), int(temp[14])]
        sql = "insert into " + code + "(결산기준일, 유동자산) values (?, ?)"
        cursor.execute(sql, data)
        right.append(code)

    elif temp[1] == "[140890]":
        data = ["2014-04-30", int(temp[14])]
        sql = "insert into " + code + "(결산기준일, 유동자산) values (?, ?)"
        cursor.execute(sql, data)
        right.append(code)

    else:
        pass


b = 0

for i in file[1:]:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    target = temp[14]
    settledate = temp[7].replace("2015", "2013")

    b = b + 1
    print("phase 2 " + str(b) + "/" + str(len(file[1:])))
    if temp[2] == "레드비씨":
        pass
    elif temp[1] == "[011330]" and temp[7] == "2015-12-31":
        pass
    elif temp[1] == "[007570]" and temp[7] == "2015-12-31":
        pass
    elif temp[1] == "[124500]" and temp[7] == "2015-12-31":
        pass
    elif temp[1] == "[054050]" and temp[7] == "2015-12-31":
        pass
    elif temp[1] == "[040910]" and temp[7] == "2015-12-31":
        pass

    elif temp[1] == "[140890]" and temp[7] == "2015-10-31":
        pass

    elif temp[10] == "ifrs_CurrentAssets" and target != "":
        data_insert()

    elif temp[10] == "ifrs_CurrentAssets" and target == "":
        pass






con.commit()


