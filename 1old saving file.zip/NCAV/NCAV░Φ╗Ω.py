import pandas as pd
import sqlite3

con1 = sqlite3.connect("E:\\Database\\연결유동자산.db")

# database의 table명 가져오기
curs = con1.cursor()
table_list1 = []
curs.execute('select name from sqlite_master where type="table"')
qd = curs.fetchall()

for i in qd:
    table_list1.append(i[0])

con2 = sqlite3.connect("E:\\Database\\연결부채총계.db")

con3 = sqlite3.connect("E:\\backtest\\주가.db")


# database의 table명 가져오기
curs = con3.cursor()
table_list2 = []
curs.execute('select name from sqlite_master where type="table"')
qd = curs.fetchall()

for i in qd:
    table_list2.append(i[0])


abolishment = []
for i in table_list1:
    if i not in table_list2:
        abolishment.append(i)


com_list = []
ratio_list = []
price_list = []
maca_list = []
cur_list = []
lia_list = []

a = 0
for j in table_list1:
    df1 = pd.read_sql("SELECT * FROM " + j, con1, index_col='결산기준일')
    df2 = pd.read_sql("SELECT * FROM " + j, con2, index_col='결산기준일')
    settlement_date = df1.index[-1]

    a = a + 1
    print(str(a) + "/" + str(len(table_list1)))

    if settlement_date == "2017-09-30":
        if j not in abolishment:
            df3 = pd.read_sql("SELECT * FROM " + j, con3, index_col='index')
            currentassat = df1.ix["2017-09-30"][0]
            liabilities = df2.ix["2017-09-30"][0]
            marketcapitalism = list(df3['시가총액'])[-1]
            ncav = (currentassat - liabilities) / marketcapitalism

            price = list(df3['종가'])[-1]

            com_list.append(j)
            ratio_list.append(ncav)
            price_list.append(price)
            maca_list.append(marketcapitalism)
            cur_list.append(currentassat)
            lia_list.append(liabilities)


df4 = pd.DataFrame({"ratio": ratio_list, "가격": price_list, "시가총액": maca_list, "유동자산": cur_list, "부채총계":lia_list}, com_list)

print(df4.sort_values(by=['ratio'], ascending=False))
