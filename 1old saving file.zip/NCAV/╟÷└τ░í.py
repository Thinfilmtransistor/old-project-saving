import win32com.client
import time
import pandas as pd
import sqlite3
from datetime import datetime


now = datetime.now()
date = 'Y%sM%sD%s' % (now.year, now.month, now.day)

con = sqlite3.connect("E:\\Value\\분기보고서.db")
df = pd.read_sql("SELECT * FROM Y2017Q3", con)
com_list = list(df['index'])

com_line = []
block = []

var = len(com_list)
a = 0
for i in com_list:

    block.append(i)
    a = a + 1
    if a % 200 == 0:
        com_line.append(block)
        block = []
    elif a == var:
        com_line.append(block)
        block = []

b = 0
price_list = []

for j in com_line:

    inststmarketeye = win32com.client.Dispatch("CpSysDib.MarketEye")
    inststmarketeye.SetInputValue(0, 4)
    inststmarketeye.SetInputValue(1, j)
    time.sleep(0.3)
    inststmarketeye.BlockRequest()
    numStock = inststmarketeye.GetHeaderValue(2)

    for k in range(numStock):
        price = inststmarketeye.GetDataValue(0, k)  # 현재가
        price_list.append(price)
        print(price)

        b = b + 1
        print(str(b) + "/" + str(var))

dataFrame = pd.DataFrame({"현재가": price_list}, com_list)

con1 = sqlite3.connect("E:\\Value\\가격.db")
dataFrame.to_sql(date, con1)

print("end")
