import operator

f1 = open("E:\\Database\\Data_가공\\2017_반기_매출액.txt", "r")
com_code = []
salse = []
lines1 = f1.readlines()
for i in lines1:
    temp1 = i.replace("\n", "")
    temp_list1 = temp1.split("\t")
    salse.append(temp_list1[1])
    com_code.append(temp_list1[0])
f1.close()

f2 = open("E:\\Database\\Data_가공\\20180119시가총액.txt", "r")
capitalism = []
lines2 = f2.readlines()
for j in lines2:
    temp = j.replace("\n", "")
    capitalism.append(temp)
f2.close()

psr_dic = {}
for k in range(len(lines1)):
    if salse[k] == "0":
        psr = 0
        psr_dic[com_code[k]] = psr
    else:
        psr = float(capitalism[k]) / float(salse[k])
        psr_dic[com_code[k]] = psr

psr_sort = sorted(psr_dic.items(),key=operator.itemgetter(1), reverse=True)

psr_rank = []
a = 1
for i in range(len(psr_dic)):
    psr_rank.append(psr_sort[i][0] + "\t" + str(a) + "\n")
    a = a +1


f3 = open("E:\\Database\\psr_rank.txt", "wt")
for j in psr_rank:
    f3.write(j)
f3.close()

print(psr_rank)

