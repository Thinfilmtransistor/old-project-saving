# 자본총계 data 가공

BS_2017 = open("E:\\database\\2017\\2017_반기보고서_01_재무상태표_20171102.txt", "r")

Company_code = []
target_list = []
Company_code1 = []


while True:
    line = BS_2017.readline()
    if not line:
        break
    temp = line.split("\t")
    if temp[1] not in Company_code1:
        Company_code1.append(temp[1])
    if temp[10] == "ifrs_Equity" or temp[11] == "자본총계" or temp[11] == "   자본총계" or temp[11] == "   자본 총계"\
            or temp[11] == "자본 총계" or temp[11] == "   자 본 총 계":
        Company_code.append(temp[1])
        target_list.append(temp[1] + "\t" + temp[12] + "\n")
    elif temp[1] in Company_code:
        pass
BS_2017.close()

print(Company_code)
print(Company_code1[1:])

icl = list(set(Company_code1).intersection(Company_code))   # 교집합
sb1 = list(set(Company_code1)-set(icl))  # 차집합
print(sb1)  # 문제가 되는 종목 코드
print(len(target_list))


Lia_2017 = open("E:\\database\\2017_반기_자본총계.txt", "wt")
for i in target_list:
    Lia_2017.write(i)
Lia_2017.close()


