# import win32com
import pandas as pd
import sqlite3
"""
f1 = open("E:\\Database\\NCAV\\매입종목.txt", "r")
lines1 = f1.readlines()
purchase = 0
for i in lines1[1:]:
    temp = i.replace("\n", "")
    temp_list = temp.split("\t")
    purchase = purchase + int(temp_list[1])*int(temp_list[2])
    print(temp_list)

print("매입가: ", purchase)
"""
con = sqlite3.connect("E:\\Database\\NCAV\\NCAV.db")
df = pd.read_sql("SELECT *FROM NCAV", con, index_col='index')
dfsort = df.sort_values(by='비율', axis=0, ascending=False)

print(dfsort)
