# 매출 총이익 data 가공

PL_2017 = open("E:\\database\\2017\\2017_반기보고서_02_손익계산서_20171102.txt", "r")

Company_code = []
target_list = []
Company_code1 = []  # 기업수
target_list_ch = []

while True:
    line = PL_2017.readline()
    if not line:
        break
    temp = line.split("\t")
    if temp[1] not in Company_code1:
        Company_code1.append(temp[1])
    if temp[10] == "ifrs_GrossProfit" or temp[11] == "매출 총이익" or temp[11] == "III.매출총이익":
        Company_code.append(temp[1])
        target_list.append(temp[1] + "\t" + temp[13] + "\n")
        target_list_ch.append(temp[1])

    elif temp[1] in Company_code:
        pass
PL_2017.close()


"""
PL_2017 = open("E:\\database\\2017\\2017_반기보고서_03_포괄손익계산서_20171102.txt", "r")


while True:
    line = PL_2017.readline()
    if not line:
        break
    temp = line.split("\t")
    if temp[1] not in Company_code1:
        Company_code1.append(temp[1])
    if temp[1] in Company_code:
        pass
    elif temp[10] == "ifrs_GrossProfit":
        Company_code.append(temp[1])
        target_list.append(temp[1] + "\t" + temp[13] + "\n")
        target_list_ch.append(temp[1])

PL_2017.close()
"""
print(Company_code)
print(len(Company_code1[1:]))

icl = list(set(Company_code1).intersection(Company_code))   # 교집합
sb1 = list(set(Company_code1)-set(icl))  # 차집합
print(sb1)  # 문제가 되는 종목 코드


print(len(target_list))

"""
Lia_2017 = open("E:\\database\\2017_반기_매출총이익.txt", "wt")
for i in target_list:
    Lia_2017.write(i)
Lia_2017.close()

"""
