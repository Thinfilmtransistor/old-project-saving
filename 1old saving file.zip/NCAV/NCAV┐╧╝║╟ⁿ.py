import pandas as pd
import sqlite3
import re

file_name = "2018_1분기보고서_01_재무상태표_20180712"

p1 = re.compile('\s*유동자산\s*합계')
p2 = re.compile('\s*비유동자산')
p3 = re.compile('\s*장기금융자산')
p4 = re.compile('\s\s\s\s\s\s')
p5 = re.compile('\s\s\s장기금융상품')
p6 = re.compile('부채총계')

cur_Company_code = []  # 항목코드를 "ifrs_CurrentAssets" 사용하는 종목코드 list
lia_Company_code = []  # 항목코드를 "ifrs_Liabilities" 사용하는 종목코드 list

Company_code1 = []  # 기재된 종목코드 list
temp_current_assats_list = []  # 문제가 된 종목의 유동자산을 합산하기 위한 임시 list
Cureent_assats_list = []  # 유동자산 list

temp_liabilityes_list = []  # 문제가 된 종목의 유동자산을 합산하기 위한 임시 list
liabilities_list = []  # 유동자산 list

cur_data_dic = {}
lia_data_dic = {}


BS_2017 = open("E:\\quant\\database\\2018\\" + file_name + ".txt", "r")

ref_code = []
cur_code = []
lia_code = []

datalist = BS_2017.readlines()

code_dic = {}
code_lis = []
b = 0

for i in datalist[1:]:
    b = b + 1
    code_lis.append(b)
    temp = i.split("\t")
    if temp[1] not in ref_code:
        code_dic[temp[1]] = []
        code_lis = []
        ref_code.append(temp[1])
    code_dic[temp[1]].append(b)

    if (temp[10] == "ifrs_CurrentAssets") or (p1.match(temp[11]) != None):
        if temp[12] != "":
            cur_code.append(temp[1])
            cur_data_dic[temp[1]] = int(temp[12].replace(",", ""))
    elif temp[1] in cur_code:
        pass

    if temp[10] == "ifrs_Liabilities" or (p6.match(temp[11]) != None):
        if temp[12] != "":
            lia_code.append(temp[1])
            lia_data_dic[temp[1]] = int(temp[12].replace(",", ""))
    elif temp[1] in lia_code:
        pass

# print("기재된 종목수", ref_code)
# print(code_dic)

print("기재된 종목수", len(ref_code))

# 유동자산 중복되는 코드 검사
print("유동자산 중복코드")
a = 0
for i in range(len(cur_code)-1):
    if cur_code[i] == cur_code[i+1]:
        print(cur_code[i])
        a = a + 1
print("유동자산 종목수", len(cur_code) - a)
cur_icl = list(set(ref_code).intersection(cur_code))   # 교집합
cur_sb1 = list(set(ref_code)-set(cur_icl))  # 차집합
print("유동자산 문제종목", cur_sb1)  # 문제가 되는 종목 코드


for i in cur_sb1:
    c = -1
    print(i)
    cur_data_dic[i] = int(0)

    for j in code_dic[i]:
        if i == "[008470]":
            m = p4.match(datalist[j].split("\t")[11])

            if m == None:
                temp = datalist[j].split("\t")
                if p5.match(datalist[j].split("\t")[11]) != None:
                    break
                else:
                    print(temp[11], temp[12])
                    if temp[12] != "":
                        cur_data_dic[i] = cur_data_dic[i] + int(temp[12].replace(",", ""))

        else:
            c = c + 1
            m = p2.match(datalist[j].split("\t")[11])
            if m != None:
                for k in range(c):
                    temp = datalist[code_dic[i][k]].split("\t")
                    print(temp[11], temp[12])
                    if temp[12] != "":
                        cur_data_dic[i] = cur_data_dic[i] + int(temp[12].replace(",", ""))

            m = p3.match(datalist[j].split("\t")[11])
            if m != None:
                for k in range(c):
                    temp = datalist[code_dic[i][k]].split("\t")
                    print(temp[11], temp[12])
                    if temp[12] != "":
                        cur_data_dic[i] = cur_data_dic[i] + int(temp[12].replace(",", ""))


# 부채총계중복되는 코드 검사
print("부채총계 중복코드")
a = 0
for i in range(len(lia_code) - 1):
    if lia_code[i] == lia_code[i + 1]:
        print(lia_code[i])
        # print(code_dic[lia_code[i]])
        a = a + 1
print("부채총계 종목수", len(lia_code) - a)

lia_icl = list(set(ref_code).intersection(lia_code))  # 교집합
lia_sb1 = list(set(ref_code) - set(lia_icl))  # 차집합
print("부채총계 문제종목", lia_sb1)  # 문제가 되는 종목 코드

BS_2017.close()


print("기재된 종목수", len(ref_code))
print("유동자산 종목", len(cur_data_dic))
print("부채총계 종목", len(lia_data_dic))


con1 = sqlite3.connect("E:\\quant\\backtest\\주가.db")

# database의 table명 가져오기
curs = con1.cursor()
table_list = []
curs.execute('select name from sqlite_master where type="table"')
qd = curs.fetchall()

co_list = []
ra_list = []
li_list = []
a = 0
for i in ref_code:

    code = i.replace("[", "A").replace("]", "")
    df = pd.read_sql("SELECT 시가총액 FROM " + code, con1)
    ratio = (cur_data_dic[i] - lia_data_dic[i]) / df["시가총액"][df.shape[0] - 1]
    if ratio >= 1.0:
        a = a + 1
        print(a)
        # co_list.append(code)
        # ra_list.append(ratio)
        # li_list.append("http://companyinfo.stock.naver.com/v1/company/c1010001.aspx?cmp_cd={0}&target=finsum_more".format(i.replace("[", "").replace("]", "")))



        print("종목코드", i)
        print("비율", ratio)
        print("http://companyinfo.stock.naver.com/v1/company/c1010001.aspx?cmp_cd={0}&target=finsum_more".format(i.replace("[", "").replace("]", "")))
# result_df = pd.DataFrame({"종목코드": co_list, "비율": ra_list, "주소": li_list})
# print(result_df)
