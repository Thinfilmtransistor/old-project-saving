import win32com.client
import time
import pandas as pd
import sqlite3

f1 = open("E:\\Database\\Data_가공\\2017_반기_유동자산.txt", "r")
f2 = open("E:\\Database\\Data_가공\\2017_반기_부채총계.txt", "r")

f1_lines = f1.readlines()
f2_lines = f2.readlines()

com_code = []
cur_assats = []
liability = []
ncav_list = []
maca_list = []
maca_ratio = []

inststockchart = win32com.client.Dispatch("CpSysDib.StockChart")

for i in range(len(f1_lines)):
    temp1 = f1_lines[i].replace("\n", "")
    temp2 = f2_lines[i].replace("\n", "")

    temp_list1 = temp1.split("\t")
    temp_list2 = temp2.split("\t")

    com_code.append(temp_list1[0])
    cur_assats.append(temp_list1[1])
    liability.append(temp_list2[1])
    ncav = int(temp_list1[1]) - int(temp_list2[1])
    ncav_list.append(ncav)

    inststockchart.SetInputValue(0, "A" + temp_list1[0])
    inststockchart.SetInputValue(1, ord('2'))
    inststockchart.SetInputValue(4, 1)
    inststockchart.SetInputValue(5, 13)
    inststockchart.SetInputValue(6, ord('D'))
    inststockchart.SetInputValue(9, ord('1'))
    inststockchart.BlockRequest()
    market_capitalization = inststockchart.GetDataValue(0, 0)
    maca_list.append(market_capitalization)

    maca_ratio.append(float(ncav) / float(market_capitalization))

    time.sleep(0.3)

    a = len(f1_lines)
    print(str(i) + "/" + str(a))


print(com_code)
print(cur_assats)
print(liability)
print(ncav_list)
print(maca_list)

dataFrame1 = pd.DataFrame({"비율": maca_ratio, "시가총액": maca_list, "유동자산": cur_assats,
                           "NCAV": ncav_list, "부채총계": liability}, com_code)


print(dataFrame1)

con = sqlite3.connect("E:\\Database\\NCAV\\NCAV.db")
dataFrame1.to_sql('NCAV', con, )
