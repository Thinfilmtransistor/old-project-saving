PL1 = open("E:\\Database\\2017\\2017_3분기보고서_02_손익계산서_20180131.txt", "r")
file1 = PL1.readlines()

PL1_list = []
for i in file1[1:]:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "").replace("]", "")
    if code not in PL1_list:
        PL1_list.append(code)
print("손익계산서 종목수 ", len(PL1_list))

PL2 = open("E:\\Database\\2017\\2017_3분기보고서_03_포괄손익계산서_20180131.txt", "r")
file2 = PL2.readlines()

PL2_list = []
for i in file2[1:]:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "").replace("]", "")
    if code not in PL1_list:
        if code not in PL2_list:
            PL2_list.append(code)
print("포괄손익계산서 종목수 ", len(PL2_list))


# 통화종류 확인
def curruncy_type():
    print("화폐종류")
    code_list = []
    day = []
    cur_type = []
    for i in file1[1:]:
        temp = i.replace("\n", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if temp[9] != "KRW":
            if code not in code_list:
                code_list.append(code)
                day.append(temp[7])
                cur_type.append(temp[9])
    for i in range(len(code_list)):
        print("일반 ", code_list[i], day[i], cur_type[i])

    code_list = []
    day = []
    cur_type = []
    for j in file2[1:]:
        temp = j.replace("\n", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if temp[9] != "KRW":
            if code not in code_list:
                code_list.append(code)
                day.append(temp[7])
                cur_type.append(temp[9])
    for i in range(len(code_list)):
        print("포괄 ", code_list[i], day[i], cur_type[i])


# 코드명이 "ifrs_Revenue"이지만 값이 비어있는 line 확인
def check1():
    print("코드명이 'ifrs_Revenue'이지만 값이 비어있는 line")
    for i in file1[1:]:
        temp = i.replace("\n", "").replace(",", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if temp[10] == "ifrs_Revenue" and temp[12] == "":
            print("일반 ", code)

    for j in file2[1:]:
        temp = j.replace("\n", "").replace(",", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if temp[10] == "ifrs_Revenue" and temp[12] == "":
            print("포괄 ", code)


# "ifrs_Revenue"를 사용하지 않는 종목 확인
def check2():
    print("'ifrs_Revenue'를 사용하지 않는 종목")
    com_line = []
    right = []
    for i in file1[1:]:
        temp = i.replace("\n", "").replace(",", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if code not in com_line:
            com_line.append(code)
        if temp[10] == "ifrs_Revenue":
            right.append(code)
    for i in com_line:
        if i not in right:
            print("일반 ", i)

    com_line = []
    right = []
    for j in file1[1:]:
        temp = j.replace("\n", "").replace(",", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if code not in com_line:
            com_line.append(code)
        if temp[10] == "ifrs_Revenue":
            right.append(code)
    for j in com_line:
        if j not in right:
            print("포괄 ", j)


# 예외 항목 유무 검사
def check3():

    PL_2017 = open(path, "r")
    file = PL_2017.readlines()

    # 재무상태표의 종목코드list를 만들기
    code_list = []
    for i in file[1:]:
        temp = i.replace("\n", "").replace(",", "").split("\t")
        code = temp[1].replace("[", "A").replace("]", "")
        if code not in code_list:
            code_list.append(code)

    right = []

    def data_insert():
        right.append(code)

    b = 0

    for i in file[1:]:
        temp = i.replace("\n", "").replace(",", "").split("\t")
        code = temp[1].replace("[", "A").replace("]", "")

        b = b + 1
        print("phase 2 " + str(b) + "/" + str(len(file[1:])))

        if temp[10] == "ifrs_Liabilities" and temp[12] != "":
            data_insert()

        elif temp[10] == "ifrs_Liabilities" and temp[12] == "":
            pass

        elif temp[1] == "[067290]":
            if temp[11] == "부채총계":
                data_insert()
        elif temp[1] == "[083470]":
            if temp[11] == "부채총계":
                data_insert()
        elif temp[1] == "[025000]":
            if temp[11] == "부채총계":
                data_insert()
        elif temp[1] == "[004990]":
            if temp[11] == "부채 총계":
                data_insert()
        elif temp[1] == "[145210]":
            if temp[11] == "   부채 총계":
                data_insert()
        elif temp[1] == "[225330]":
            if temp[11] == "부채총계":
                data_insert()
        elif temp[1] == "[065500]":
            if temp[11] == "부채총계":
                data_insert()
        elif temp[1] == "[065060]":
            if temp[11] == "   부 채 총 계":
                data_insert()
        elif temp[1] == "[053300]":
            if temp[11] == "부채총계":
                data_insert()
        elif temp[1] == "[143210]":
            if temp[11] == "부채총계":
                data_insert()

    print(len(code_list))
    print(len(right))
    for i in code_list:
        if i not in right:
            print(i)

    if len(right) > len(code_list):
        for i in range(len(right) - 1):
            if right[i] == right[i + 1]:
                print(right[i])
                if right[i] == "A140890":
                    print("A140890은 트러스제7호로 3개월마다 사업보고서와 반기보고서를 교대로 제출하고 있다.")


curruncy_type()
check1()
check2()
# check3()
