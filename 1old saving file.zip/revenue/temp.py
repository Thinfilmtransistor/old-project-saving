PL1 = open("E:\\Database\\2017\\2017_3분기보고서_03_포괄손익계산서_20180131.txt", "r")
file = PL1.readlines()

PL1_list = []
for i in file[:10]:
    print(i.split("\t"))

