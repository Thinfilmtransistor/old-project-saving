
BS = open("E:\\Database\\2017\\2017_3분기보고서_01_재무상태표_20180131.txt", "r")
file = BS.readlines()

BS_list = []
for i in file[1:]:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "").replace("]", "")
    if code not in BS_list:
        BS_list.append(code)
print("재무상태표 종목수 ", len(BS_list))

PL1 = open("E:\\Database\\2017\\2017_3분기보고서_02_손익계산서_20180131.txt", "r")
file1 = PL1.readlines()

PL1_list = []
for i in file1[1:]:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "").replace("]", "")
    if code not in PL1_list:
        PL1_list.append(code)
print("손익계산서 종목수 ", len(PL1_list))

PL2 = open("E:\\Database\\2017\\2017_3분기보고서_03_포괄손익계산서_20180131.txt", "r")
file2 = PL2.readlines()

PL2_list = []
for i in file2[1:]:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "").replace("]", "")
    if code not in PL1_list:
        if code not in PL2_list:
            PL2_list.append(code)
print("포괄손익계산서 종목수 ", len(PL2_list))
print("합 ", len(PL1_list) + len(PL2_list))
# 통화종류 확인
def curruncy_type():
    print("화폐종류")
    code_list = []
    day = []
    cur_type = []
    for i in file1[1:]:
        temp = i.replace("\n", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if temp[9] != "KRW":
            if code not in code_list:
                day.append(temp[7])
                cur_type.append(temp[9])
                code_list.append("일반 " + code)

    for i in file2[1:]:
        temp = i.replace("\n", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if code in PL1_list:
            pass
        elif temp[9] != "KRW":
            if "포괄 " + code not in code_list:
                day.append(temp[7])
                cur_type.append(temp[9])
                code_list.append("포괄 " + code)

    for j in range(len(code_list)):
        print(code_list[j], day[j], cur_type[j])


# 코드명이 "ifrs_Revenue"이지만 값이 비어있는 line 확인
def check1():
    print("코드명이 'ifrs_Revenue'이지만 값이 비어있는 line")
    for i in file1[1:]:
        temp = i.replace("\n", "").replace(",", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if temp[10] == "ifrs_Revenue" and temp[12] == "":
            print("일반 ", code)

    for j in file2[1:]:
        temp = j.replace("\n", "").replace(",", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if code in PL1_list:
            pass
        elif temp[10] == "ifrs_Revenue" and temp[12] == "":
            print("포괄 ", code)

# "ifrs_Revenue"를 사용하지 않는 종목 확인
def check2():
    print("'ifrs_Revenue'를 사용하지 않는 종목")
    right = []
    for i in file1[1:]:
        temp = i.replace("\n", "").replace(",", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if temp[10] == "ifrs_Revenue":
            right.append(code)
    for i in PL1_list:
        if i not in right:
            print("일반 ", i)

    right = []
    for j in file2[1:]:
        temp = j.replace("\n", "").replace(",", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if code in PL1_list:
            pass
        elif temp[10] == "ifrs_Revenue":
            right.append(code)
    for j in PL2_list:
        if j not in right:
            print("포괄 ", j)
curruncy_type()
check1()
check2()