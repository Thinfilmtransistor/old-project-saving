import sqlite3
import pandas as pd

f = open("E:\\backtest\\주가update날짜.txt", "r")
date = int(f.readline())
f.close()
f = open("E:\\Value\\konex.txt", "r")
konex = f.readlines()
konex_list = []
for i in konex:
    code = "A" + i.replace("\n", "")
    konex_list.append(code)

f.close()
con = sqlite3.connect("E:\\backtest\\주가.db")

# database의 table명 가져오기
curs = con.cursor()
table_list = []
curs.execute('select name from sqlite_master where type="table"')
qd = curs.fetchall()
for i in qd:
    if i[0] in konex_list:
        pass
    elif i[0][0] == "A":
        table_list.append(i[0])

index_list = []
maca_list = []

length = len(table_list)
for i in table_list:

    df = pd.read_sql("SELECT * FROM " + i, con, index_col='index')
    index_list.append(i)
    maca_list.append(df.ix[date][4])


maca_series = pd.Series(maca_list, index=index_list)

target = maca_series.sort_values()[:int(length * 0.2)]

print("phase1 done")
# -------------------------------------------

f1 = open("E:\\Database\\2017\\2017_3분기보고서_01_재무상태표_연결_20180131.txt", "r")
file1 = f1.readlines()

bs_code_list = []
for i in file1[1:]:
    temp = i.split("\t")
    code = temp[1]
    if code not in bs_code_list:
        bs_code_list.append(code)
f1.close()

f2 = open("E:\\Database\\2017\\2017_3분기보고서_02_손익계산서_연결_20180131.txt", "r")
file2 = f2.readlines()

pl_code_list = []
for i in file2[1:]:
    temp = i.split("\t")
    code = temp[1]
    if code not in pl_code_list:
        pl_code_list.append(code)
f2.close()

f3 = open("E:\\Database\\2017\\2017_3분기보고서_03_포괄손익계산서_연결_20180131.txt", "r")
file3 = f3.readlines()

pl_code_list = []
for i in file3[1:]:
    temp = i.split("\t")
    code = temp[1]
    if code not in pl_code_list:
        pl_code_list.append(code)
f3.close()

f4 = open("E:\\Database\\2017\\2017_3분기보고서_04_현금흐름표_연결_20180131.txt", "r")
file4 = f4.readlines()

cf_code_list = []
for i in file4[1:]:
    temp = i.split("\t")
    code = temp[1]
    if code not in cf_code_list:
        cf_code_list.append(code)
f3.close()

print("phase2 done")
# ------------------------------------------


for i in target.index:
    if i not in bs_code_list:
        print(i, "재무상태표")
    if i not in pl_code_list:
        print(i, "손익계산서")
    if i not in cf_code_list:
        print(i, "현금흐름표")
print("phase 3 done")

