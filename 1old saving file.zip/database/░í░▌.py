import sqlite3
import pandas as pd

con = sqlite3.connect("E:\\backtest\\주가.db")

# database의 table명 가져오기
curs = con.cursor()
table_list = []
curs.execute('select name from sqlite_master where type="table"')
qd = curs.fetchall()

for i in qd:
    table_list.append(i[0])

con2 = sqlite3.connect("E:\\backtest\\주가(20060818 ~ 20180305).db")

# con2 data를 con에 넣음
a = 0
for i in table_list:
    a = a + 1

    df = pd.read_sql("SELECT * FROM " + i, con2, index_col='index')
    df.to_sql(i, con, if_exists='append')
    print(str(a) + "/" + str(len(table_list)))
