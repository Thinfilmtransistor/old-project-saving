import sqlite3
import pandas as pd

con1 = sqlite3.connect("E:\\Database\\연결유동자산.db")
con2 = sqlite3.connect("E:\\Database\\연결부채총계.db")

# database의 table명 가져오기
curs = con1.cursor()
table_list = []
curs.execute('select name from sqlite_master where type="table"')
qd = curs.fetchall()

for i in qd:
    table_list.append(i[0])

# con2 data와 con1 data를 합침
a = 0
for i in table_list:
    a = a + 1
    df1 = pd.read_sql("SELECT * FROM " + i, con1, index_col='결산기준일')
    df2 = pd.read_sql("SELECT * FROM " + i, con2, index_col='결산기준일')
    df3 = pd.concat([df1, df2], axis=1)
    print(df3)
