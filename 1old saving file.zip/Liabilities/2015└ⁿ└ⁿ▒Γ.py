# 2015 사업보고서 전전기 부채총계 database화

import sqlite3

con = sqlite3.connect("E:/Database/부채총계.db")
cursor = con.cursor()

PL_2015 = open("E:\\Database\\2015\\2015_사업보고서_01_재무상태표_20160531.txt", "r")
file = PL_2015.readlines()

# database의 table list 만들기
com_list = []
cursor.execute('select name from sqlite_master where type="table"')
qd = cursor.fetchall()
for i in qd:
    com_list.append(i[0])

# 재무상태표의 종목코드list를 만들기
code_list = []
for i in file[1:]:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if code not in code_list:
        code_list.append(code)

# 유동자산 database에 없는 종목 table 만들기
a = 0
for i in code_list:
    if i not in com_list:
        cursor.execute("CREATE TABLE " + i + "(결산기준일 text, 부채총계 int)")
        a = a + 1
        print("phase 1 " + str(a) + "/" + str(len(code_list)))
    else:
        pass

# KRW/USD 환율
exchange = 1045

right = []


def data_insert():
    if temp[1] == "[011330]" or temp[1] == "[054050]" or temp[1] == "[040910]" or temp[1] == "[124500]" or temp[1] == "[007570]":
        data = [temp[7].replace("2015", "2014"), int(temp[13])]
        sql = "insert into " + code + "(결산기준일, 부채총계) values (?, ?)"
        cursor.execute(sql, data)
        right.append(code)
    elif temp[1] == "[140890]":
        data = ["2014-10-31", int(temp[13])]
        sql = "insert into " + code + "(결산기준일, 부채총계) values (?, ?)"
        cursor.execute(sql, data)
        right.append(code)
    else:
        data = [settledate, int(temp[14])]
        sql = "insert into " + code + "(결산기준일, 부채총계) values (?, ?)"
        cursor.execute(sql, data)
        right.append(code)


b = 0

anchoring = []
data1 = []


for i in file[1:]:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    settledate = temp[7].replace("2015", "2013")

    b = b + 1
    print("phase 2 " + str(b) + "/" + str(len(file[1:])))
    if temp[2] == "레드비씨":
        pass
    elif temp[1] == "[011330]" and temp[7] == "2015-12-31":
        pass
    elif temp[1] == "[054050]" and temp[7] == "2015-12-31":
        pass
    elif temp[1] == "[040910]" and temp[7] == "2015-12-31":
        pass
    elif temp[1] == "[124500]" and temp[7] == "2015-12-31":
        pass
    elif temp[1] == "[007570]" and temp[7] == "2015-12-31":
        pass
    elif temp[1] == "[140890]" and temp[7] == "2015-10-31":
        pass

    elif temp[10] == "ifrs_Liabilities" and temp[14] != "":
        if temp[1] == "[900100]":
            data = [settledate, int(temp[14]) * exchange]
            sql = "insert into " + code + "(결산기준일, 부채총계) values (?, ?)"
            cursor.execute(sql, data)
            right.append(code)
        elif temp[1] == "[950130]":
            data = [settledate, int(temp[14]) * exchange]
            sql = "insert into " + code + "(결산기준일, 부채총계) values (?, ?)"
            cursor.execute(sql, data)
            right.append(code)
        else:
            data_insert()

    elif temp[10] == "ifrs_Liabilities" and temp[14] == "":
        pass

    else:
        if temp[1] == "[114090]" and temp[11] == "부채총계":
            data_insert()
        if temp[1] == "[067290]" and temp[11] == "부채총계":
            data_insert()
        if temp[1] == "[083470]" and temp[11] == "부채총계":
            data_insert()
        if temp[1] == "[025000]" and temp[11] == "부채":
            data_insert()
        if temp[1] == "[004990]" and temp[11] == "부채 총계":
            data_insert()
        if temp[1] == "[065500]" and temp[11] == "부채총계":
            data_insert()
        if temp[1] == "[053300]" and temp[11] == "부채총계":
            data_insert()
        if temp[1] == "[011330]" and temp[11] == "부채총계":
            data_insert()

        if temp[1] == "[145210]":
            if temp[10] == "ifrs_CurrentLiabilities":
                anchoring.append(settledate)
                data1.append(temp[14])
            if temp[10] == "ifrs_NoncurrentLiabilities":
                data1.append(temp[14])


exlist = ["A145210"]
excurlist = []

def get_total(data):
    total = 0
    for i in data:
        if i == "":
            pass
        else:
            total = total + int(i)
    excurlist.append(total)


get_total(data1)

for i in range(1):
    data = [anchoring[i], int(excurlist[i])]
    sql = "insert into " + exlist[i] + "(결산기준일, 부채총계) values (?, ?)"
    cursor.execute(sql, data)
    right.append(exlist[i])


con.commit()

print(len(code_list))
print(len(right))
for i in code_list:
    if i not in right:
        print(i)
