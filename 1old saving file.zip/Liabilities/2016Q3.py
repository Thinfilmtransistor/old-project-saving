# 2016 Q3보고서 당기 부채총계 database화
import sqlite3

con = sqlite3.connect("E:/Database/부채총계.db")
cursor = con.cursor()

PL_2017 = open("E:\\Database\\2016\\2016_3분기보고서_01_재무상태표_20170223.txt", "r")
file = PL_2017.readlines()

# database의 table list 만들기
com_list = []
cursor.execute('select name from sqlite_master where type="table"')
qd = cursor.fetchall()
for i in qd:
    com_list.append(i[0])

# 재무상태표의 종목코드list를 만들기
code_list = []
for i in file[1:]:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if code not in code_list:
        code_list.append(code)

# 부채총계 database에 없는 종목 table 만들기
a = 0
for i in code_list:
    if i not in com_list:
        cursor.execute("CREATE TABLE " + i + "(결산기준일 text, 부채총계 int)")
        a = a + 1
        print("phase 1 " + str(a) + "/" + str(len(code_list)-len(com_list)))
    else:
        pass

# KRW/USD 환율
exchange = 1104

right = []


def data_insert():
    data = [temp[7], int(temp[12])]
    sql = "insert into " + code + "(결산기준일, 부채총계) values (?, ?)"
    cursor.execute(sql, data)
    right.append(code)


b = 0

for i in file[1:]:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "A").replace("]", "")

    b = b + 1
    print("phase 2 " + str(b) + "/" + str(len(file[1:])))

    if temp[10] == "ifrs_Liabilities" and temp[12] != "":
        data_insert()

    elif temp[10] == "ifrs_Liabilities" and temp[12] == "":
        pass

    elif temp[1] == "[067290]":
        if temp[11] == "부채총계":
            data_insert()
    elif temp[1] == "[083470]":
        if temp[11] == "부채총계":
            data_insert()
    elif temp[1] == "[025000]":
        if temp[11] == "부채총계":
            data_insert()
    elif temp[1] == "[004990]":
        if temp[11] == "부채 총계":
            data_insert()
    elif temp[1] == "[145210]":
        if temp[11] == "   부채 총계":
            data_insert()
    elif temp[1] == "[065500]":
        if temp[11] == "부채총계":
            data_insert()
    elif temp[1] == "[053300]":
        if temp[11] == "부채총계":
            data_insert()

con.commit()

print(len(code_list))
print(len(right))
for i in code_list:
    if i not in right:
        print(i)
