from win32com.client import constants, Dispatch

xlapp = Dispatch("Excel.Application")
xlapp.Visible = 1

xlapp.Workbooks.Add()
xlapp.Cells(1,2).Value = "a"
xlapp.Cells(1,3).Value = "b"
xlapp.Cells(2,1).Value = "x"
xlapp.Cells(2,2).Value = 3
xlapp.Cells(2,3).Value = 5
xlapp.Cells(3,1).Value = "y"
xlapp.Cells(3,2).Value = 4
xlapp.Cells(3,3).Value = 6

xlapp.Charts.Add()
xlapp.ActiveChart.ChartType = 4
xlapp.ActiveChart.SetSourceData(Source=xlapp.Sheets("Sheet1").Range("A1:C3"), PlotBy=1)
xlapp.ActiveChart.Location(Where=2, Name="Sheet1")