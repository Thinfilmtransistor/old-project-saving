import win32com.client

excel = win32com.client.Dispatch("Excel.Application")
excel.Visible = True
wb = excel.Workbooks.Open('E:\\#18-062\\측정\\180\\180828\\4.xls')
ws = wb.Sheets("Data")
ws.Select()
excel.Range("C2:C403,G2:G403").Select()
excel.Selection.Copy()

wb3 = excel.Workbooks.Add()
ws3 = wb3.Worksheets["Sheet1"]
ws3.Range("B18").Select()
excel.ActiveSheet.Paste()
ws3.Range("A1").Select()
excel.Selection.Copy()
wb.Close()


# wb.Close()


# excel.Quit()  # 일일이 excel을 안닫고 workbook만 닫을 수 있지 않을까?