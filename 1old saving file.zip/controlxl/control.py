import win32com.client
"""
excel = win32com.client.Dispatch("Excel.Application")
wb1 = excel.Workbooks.Open('E:\\#18-062\\측정\\180\\180828\\4.xls')
excel.Workbooks.Open('E:\\test.xlsm')
excel.Visible = True
excel.Application.Run("매크로2")
excel.Application.Copy()

# print(res)

"""
"""
excel = win32com.client.Dispatch("Excel.Application")
excel.Visible = True
wb1 = excel.Workbooks.Open('E:\\#18-062\\측정\\180\\180828\\4.xls')
ws1 = wb1.Worksheets["Data"]
wb2 = excel.Workbooks.Open('E:\\#18-062\\측정\\180\\180828\\6.xls')
ws2 = wb2.Worksheets["Data"]
ws1.Range("C2:C403").Copy()

wb3 = excel.Workbooks.Add()
ws3 = wb3.Worksheets["Sheet1"]
ws3.Range("A1").Paste()


drain_current1 = ws1.Range("C2:C403").Copy
print(drain_current1)

wb3 = excel.Workbooks.Add()
ws3 = wb3.Worksheets["Sheet1"]
ws3.Range("A1").Paste
"""

