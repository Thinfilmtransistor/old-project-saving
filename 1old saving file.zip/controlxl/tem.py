import win32com.client
import os.path

raw_list = [3,4,5,6,7,8,9]

excel = win32com.client.Dispatch("Excel.Application")
excel.Visible = True



for i in raw_list:
    wb = excel.Workbooks.Open('E:\\#18-062\\측정\\180\\180828\\'+ str(i) +'.xls')
    ws = wb.Sheets("Data")
    ws.Select()
    excel.Range("C2:C403,G2:G403").Select()
    excel.Selection.Copy()

    wb3 = excel.Workbooks.Open('E:\\parameter calc.xlsx')
    ws3 = wb3.Worksheets["Sheet1"]
    ws3.Range("B18").Select()
    excel.ActiveSheet.Paste()
    ws3.Range("A1").Select()
    excel.Selection.Copy()
    wb.Close()
    wb3.SaveAs('E:\\'+ str(i) +'.xlsx')
    excel.Quit()







# wb.Close()


# excel.Quit()  # 일일이 excel을 안닫고 workbook만 닫을 수 있지 않을까?