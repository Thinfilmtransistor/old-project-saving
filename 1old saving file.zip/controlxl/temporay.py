import win32com.client


excel = win32com.client.Dispatch("Excel.Application")
excel.Visible = True
wb = excel.Workbooks.Open('E:\\#18-062\\측정\\180\\180828\\4.xls')
ws = wb.Worksheets["Data"]
# ws.Range("A1:B1").Value = ("A", "B")
# print(ws.Cells(4,1).Value)

gate_voltage = ws.Range('B2:B403')
# print(gate_voltage)
drain_current1 = ws.Range('C2:C403')
drain_current2 = ws.Range('G2:G403')

wb1 = excel.Workbooks.Add()
ws1 = wb1.Worksheets["Sheet1"]

# print(list)
# print(gate_voltage)

ws1.Cells(18, 1).Value = gate_voltage[0]
ws1.Cells(18, 2).Value = drain_current1[0]
ws1.Cells(18, 3).Value = drain_current2[0]
for i in range(200):
    # print(i)
    # print(gate_voltage[i])
    ws1.Cells(19+i, 1).Value = gate_voltage[i]
    ws1.Cells(19 + i, 2).Value = drain_current1[i]
    ws1.Cells(19 + i, 3).Value = drain_current2[i]

# ==========FRAME=================================================
ws1.Cells(4,1).Value = "Device Structure"
ws1.Cells(5,1).Value = "GI"
ws1.Cells(6,1).Value = "W/L"
ws1.Cells(7,1).Value = "Cox(Geo)"
ws1.Cells(8,1).Value = "Cox(meas)"
ws1.Cells(9,1).Value = "Measurement Condition"
ws1.Cells(10,1).Value = "VD(lin)"
ws1.Cells(11,1).Value = "VD(sat)"
ws1.Cells(12,1).Value = "VD(sat)"

ws1.Cells(5,2).Value = 0.000011
ws1.Cells(6,2).Value = 2
ws1.Cells(7,2).Value = "=(8.85*10^-14)*7.6/B5"
ws1.Cells(10,2).Value = 0.5
ws1.Cells(11,2).Value = 5.5
ws1.Cells(12,2).Value = 0.2

ws1.Cells(5,3).Value = "cm"
ws1.Cells(7,3).Value = "F/cm2"
ws1.Cells(10,3).Value = "V"
ws1.Cells(11,3).Value = "V"
ws1.Cells(12,3).Value = "V"

ws1.Cells(4,5).Value = "calc process"
ws1.Cells(5,5).Value = "slope(ID)"
ws1.Cells(7,5).Value = "slope(SQRT ID)"
ws1.Cells(9,5).Value = "slope(gm)"
ws1.Cells(11,5).Value = "slope(SS)"

ws1.Cells(5,6).Value = "Intercept"
ws1.Cells(7,6).Value = "Intercept(SQRT)"
ws1.Cells(9,6).Value = "Intercept(gm)"
ws1.Cells(11,6).Value = "Intercept(SS)"

ws1.Cells(4,9).Value = "device parameter"
ws1.Cells(5,9).Value = "VT"
ws1.Cells(6,9).Value = "μ(sat)"
ws1.Cells(7,9).Value = "μ(lin)"
ws1.Cells(8,9).Value = "SS"

ws1.Cells(16,1).Value = "raw data"
ws1.Cells(17,1).Value = "VG"
ws1.Cells(17,2).Value = "ID(0.5)"
ws1.Cells(17,3).Value = "ID(5.5)"
ws1.Cells(17,4).Value = "ID(0.5)근사"
ws1.Cells(17,5).Value = "gm0.5"
ws1.Cells(17,6).Value = "ID sqrt"
ws1.Cells(17,7).Value = "slop sqrt"
ws1.Cells(17,8).Value = "tangent sqrt"
ws1.Cells(17,9).Value = "slope gm"
ws1.Cells(17,10).Value = "log ID"
ws1.Cells(17,11).Value = "slope SS"
ws1.Cells(17,12).Value = "tangent logID"

# ==============gm0.5==================================================
ws1.Cells(12, 2).Value = 0.2
for i in range(201):
    ws1.Cells(18 + i, 5).Value = "=(B" + str(19 + i) + "-B" + str(18 + i) + ")/$B$12"

# ==============slop, intercept =============

ws1.Cells(6, 5).Value = "=SLOPE(B170:B214,A170:A214)"
ws1.Cells(6, 6).Value = "=INTERCEPT(B170:B214,A170:A214)"

# =============ID 0.5 근사 ==================

for i in range(201):
    ws1.Cells(18 + i, 4).Value = "=$E$6*A" + str(18 + i) + "+$F$6"

# =============ID sqrt ===================

for i in range(201):
    ws1.Cells(18 + i, 6).Value = "=SQRT(C" + str(18 + i) + ")"

# ============= sqrt tangent =============

sqrt_list = []
for i in range(201):
    ws1.Cells(18 + i, 8).Value = "=(F" + str(19 + i) + "-F" + str(18 + i) + ")/$B$12"
    sqrt_list.append(ws1.Cells(18+i,8).Value)


ws1.Cells(423, 7).Value = "최대기울기"
ws1.Cells(423, 8).Value = max(sqrt_list)
ws1.Cells(424, 7).Value = "최대기울기 행"
sqrt_row = sqrt_list.index(max(sqrt_list)) + 18
ws1.Cells(424, 8).Value = sqrt_row


# ============ sqrt ID, intercept ========

ws1.Cells(8, 5).Value = "=SLOPE(F" + str(sqrt_row - 15) + ":F" + str(sqrt_row) + ",A" + str(sqrt_row - 15) + ":A" + str(sqrt_row) +")"
ws1.Cells(8, 6).Value = "=INTERCEPT(F" + str(sqrt_row - 15) + ":F" + str(sqrt_row) + ",A" + str(sqrt_row - 15) + ":A" + str(sqrt_row) +")"

# =====slope SQRT =========================
for i in range(201):
    ws1.Cells(18 + i, 7).Value = "=$E$8*A" + str(18 + i) + "+$F$8"

# ======= log ID ========================
for i in range(201):
    ws1.Cells(18 + i, 10).Value = "=LOG10(B" + str(18 + i) + ")"

# ======= tangent log ID


for i in range(201):
    ws1.Cells(18 + i, 12).Value = "=(J" + str(19 + i) + "-J" + str(18 + i) + ")/$B$12"

log_list1 = []
log_list2 = []
for i in range(200):
    log_list2.append(ws1.Cells(18 + i, 12).Value)
    if ws1.Cells(18+i,12).Value > 0:
        log_list1.append(ws1.Cells(18+i,12).Value)
    elif ws1.Cells(18+i,12).Value < 0:
        log_list1 = []

# print(log_list)

ws1.Cells(423, 11).Value = "최대기울기"
ws1.Cells(423, 12).Value = max(log_list1)
ws1.Cells(424, 11).Value = "최대기울기 행"
log_row = log_list2.index(max(log_list1)) + 18
ws1.Cells(424, 12).Value = log_row

# ============ slopeLOG ID, intercept ========

ws1.Cells(12, 5).Value = "=SLOPE(J" + str(log_row) + ":J" + str(log_row + 4) + ",A" + str(log_row) + ":A" + str(log_row + 4) +")"
ws1.Cells(12, 6).Value = "=INTERCEPT(J" + str(log_row) + ":J" + str(log_row + 4) + ",A" + str(log_row) + ":A" + str(log_row + 4) +")"

# =====slope SS =========================
for i in range(201):
    ws1.Cells(18 + i, 11).Value = "=$E$12*A" + str(18 + i) + "+$F$12"


# =======VT=========
ws1.Cells(5,10).Value = "=-E6/F6"
# =======VT=========
ws1.Cells(6,10).Value = "=2*(E8^2)/(B6*B7)"
# =======VT=========
ws1.Cells(7,10).Value = "=E6/(B6*B7*B10)"
# =======VT=========
ws1.Cells(8,10).Value = "=1/E12"

excel.Charts.Add()
excel.ActiveChart.ChartType = 4
excel.ActiveChart.SetSourceData(Source=excel.Sheets("Sheet1").Range("A18:C218"), PlotBy=1)
excel.ActiveChart.Location(Where=2, Name="Sheet1")