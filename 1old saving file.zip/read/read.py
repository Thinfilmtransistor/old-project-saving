from pandas import DataFrame


def load_data(path):
    f = open(path, 'rt')
    lines = f.readlines()
    company_list = []
    company_code_list = []

    for i in range(len(lines)):
        company = lines[i]
        company_split = company.split('\t')
        company_name = company_split[0]
        company_code = company_split[1]
        company_code = company_code[:6]
        company_list.append(company_name)
        company_code_list.append(company_code)

    raw_data = {'company_name': company_list, 'company_code': company_code_list}
    data = DataFrame(raw_data)
    return data


if __name__ == "__main__":
    load_data('d:\\company_list.txt')
