import requests
import pandas as pd
import re


def get_date(s):
    date_str = ''
    r = re.search("\d{4}/\d{2}", s)
    if r:
        date_str = r.group()
    return date_str


def get_financial_statements(code, quarter, year):
    url_tmpl = "http://companyinfo.stock.naver.com/v1/company/ajax/cF1001.aspx?cmp_cd={0}&fin_typ={1}&freq_typ={2}"
    url = url_tmpl.format(code, quarter, year)
    html = requests.get(url).text

    dfs = pd.read_html(html)
    df = dfs[0]
    columns_name = list(df.columns)
    columns_name.insert(0, '주요재무정보')
    del columns_name[-1]

    df.columns = columns_name

    for i in columns_name:
        if pd.isna(df[i][0]):
            df = df.drop(i, 1)

    columns_name = list(df.columns)

    date_list = ['주요재무정보']

    for i in columns_name:
        temp = get_date(i[1])
        if temp == '':
            pass
        else:
            date_list.append(temp)

    df.columns = date_list
    df.set_index('주요재무정보')

    return df


if __name__ == "__main__":
    get_financial_statements('035720', '4', 'Y')
