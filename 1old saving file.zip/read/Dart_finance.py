from finance_url import get_finance_url
import requests
import pandas as pd
import read
import re


company_code = list(read.load_data('d:\\company_list.txt')['company_code'])
gp = None
ebit = None
df_list = ''
for code in company_code[100:]:
    url = get_finance_url(code, "A003")

    if url == '':
        print(code, "nul")
    else:
        print(code)
        html = requests.get(url).text
        df_list = pd.read_html(html)

        df = df_list[1]  # 재무상태표 DataFrame
        df_index = df.index
        for i in range(len(df_index)):
            if df.ix[df_index[i]][0] == "자산총계":
                asset = float(df.ix[df_index[i]][1])
        print("재무상태표 자산총계", asset)

        for j in (2, 4, 6):
            df = df_list[j]
            df_index = df.index
            df_name = df.ix[df_index[0]][0]

            if df_name == '손익계산서':
                df = df_list[j + 1]  # 손익계산서 DataFrame
                df_index = df.index
                for k in range(len(df_index)):
                    if df.ix[df_index[k]][0] == "매출총이익":
                        gp = df.ix[df_index[k]][1]
                        print("손익계산서 매출 총이익", gp)
                    elif df.ix[df_index[k]][0] == "영업이익(손실)":
                        ebit = df.ix[df_index[k]][1]
                        print("영업이익(손실)", ebit)
                    else:
                        pass

            elif df_name == '포괄손익계산서':
                df = df_list[j + 1]  # 포괄손익계산서 DataFrame
                df_index = df.index

                for l in range(len(df_index)):
                    text = df.ix[df_index[l]][0]

                    regex = re.compile("매출총이익")
                    regex1 = re.compile("영업이익[(]손실[)]")
                    mo = regex.search(text)
                    if mo != None:
                        mo = mo.group()
                        gp = df.ix[df_index[l]][1]
                        print(mo, gp)

                    mo = regex1.search(text)
                    if mo != None:
                        mo = mo.group()
                        ebit = df.ix[df_index[l]][1]
                        print(mo, ebit)


        if gp != None:
            gp = str(gp)
            if gp.count('(') == 0:
                gp = float(gp)
                gp_a = round(gp / asset * 100, 2)
                print("GP_A", gp_a)
            elif gp.count('(') != 0:
                gp = re.sub('[(,)]', '', gp)
                gp = -float(gp)
                gp_a = round(gp / asset * 100, 2)
                print("GP_A", gp_a)

        if ebit != None:
            print("ebit", ebit)

