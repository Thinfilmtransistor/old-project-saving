import requests
import pandas as pd

# 목표: column 명과 index 명을 깔끔하게 정리하기

url_tmpl = "http://companyinfo.stock.naver.com/v1/company/ajax/cF1001.aspx?cmp_cd={0}&fin_typ={1}&freq_typ={2}"
url = url_tmpl.format('005930', '4', 'Y')
html = requests.get(url).text
dfs = pd.read_html(html)    # 1개의 값이 들어있는 list다
df = dfs[0]                # multiindex를 사용하는 DataFrame이다.

print(df.columns)