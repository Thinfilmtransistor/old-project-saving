import read
from webreader import get_financial_statements
import sqlite3
import pandas as pd


company_code = list(read.load_data('d:\\company_list.txt')['company_code'])
con = sqlite3.connect("d:/Database/kospi.db")

for i in company_code:
    df = get_financial_statements(i, '4', 'Y')
    df.to_sql(i, con, if_exists='replace')
    print(i)


print('end')

# naver의 재무재표로 database를 만든다.
