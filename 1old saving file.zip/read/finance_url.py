from urllib.request import urlopen
import pandas as pd
from bs4 import BeautifulSoup
import requests
import re


def get_finance_url(company_code, report_format, null=None):
    apikey = "5bd76b4d67d72be629ea556219bd5931f507d7a8"
    urlformat = "http://dart.fss.or.kr/api/search.xml?auth={0}&crp_cd={1}&start_dt=19990101&bsn_tp={2}"
    url = urlformat.format(apikey, company_code, report_format)



    resultXML = urlopen(url)
    result = resultXML.read()

    xmlsoup = BeautifulSoup(result, 'html.parser')

    data = pd.DataFrame()
    te = xmlsoup.findAll("list")

    if te ==[]:
        te = ''
        print(te)
        return te

    for t in te:
        temp = pd.DataFrame(([[t.crp_cls.string, t.crp_nm.string, t.crp_cd.string, t.rpt_nm.string, t.rcp_no.string, t.flr_nm.string, t.rcp_dt.string, t.rmk.string]]),
                            columns=["crp_cls", "crp_nm", "crp_cd", "rpt_nm", "rcp_no", "flr_nm", "rcp_dt", "rmk"])
        data = pd.concat([data, temp])

    data = data.reset_index(drop=True)

    # print(data.ix[0])


    url2 = "http://dart.fss.or.kr/dsaf001/main.do?rcpNo=" + data['rcp_no'][0]

    req = requests.get(url2)
    html_source = req.text

# html 소스중 javascript 문장에서 url data 추출

    url_val = re.findall("viewDoc[(].*[)]", html_source)
    # print(url_val)
    url_val = url_val[15]


    url_val2 = re.findall("\d+", url_val)

    finance_url_format = "http://dart.fss.or.kr/report/viewer.do?rcpNo={0}&dcmNo={1}&eleId={2}&offset={3}&length={4}&dtd=dart3.xsd"
    finance_url = finance_url_format.format(url_val2[0], url_val2[1], url_val2[2], url_val2[3], url_val2[4])   # dart 재무제표 url

    finance_url_format2 = "http://dart.fss.or.kr/pdf/download/excel.do?lang=ko&rcp_no={0}&dcm_no={1}"
    finance_url2 = finance_url_format2.format(url_val2[0],url_val2[1])

    print(finance_url2)

    return finance_url2


if __name__ == "__main__":
    print("사업보고서 = A001, 반기보고서 = A002, 분기보고서 = A003")
    get_finance_url("140910", "A003")
