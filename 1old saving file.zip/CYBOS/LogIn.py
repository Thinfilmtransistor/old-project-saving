import pywinauto
import pyautogui
import win32api
import win32con
import time

# login 정보
password = 'cru161'

# 실행

app1 = pywinauto.Application()
app1.start(r'C:\DAISHIN\STARTER\ncStarter.exe /prj:cp')
print('cp load done')


time.sleep(60)


# 마우스 조종
def click(x, y):
    win32api.SetCursorPos((x, y))
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, x, y, 0, 0)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, x, y, 0, 0)


click(1050, 490)

pyautogui.typewrite(password, interval=0.01)

# 연결
app = pywinauto.Application()
app.connect(title_re='CYBOS Starter')
print('cp connect done')

dlg = app.window()

# pass edit
pass_edit = dlg.Edit2
pass_edit.SetFocus()
pass_edit.TypeKeys(password)
print('done pw')

# login
btn = dlg.Button
btn.Click()
print('done login click')
