import win32com.client
import time
import pandas as pd
import sqlite3
import datetime

f1 = open("E:\\Value\\종목코드.txt", "r")
lines1 = f1.readlines()

com_line = []
block = []
com_code = []
var = len(lines1)
a = 0
for i in lines1:
    temp = "A" + i.replace("\n", "")
    block.append(temp)
    com_code.append(temp)
    a = a + 1
    if a % 200 == 0:
        com_line.append(block)
        block = []
    elif a == var:
        com_line.append(block)
        block = []

b = 0

now = datetime.datetime.now()
date = "D" + str(now)[:10].replace("-", "")

stocknum_list = []
bps_list = []
salse_delta_list = []
opincome_delta_list = []
net_income_delta_list = []
orprofit_delta_list = []
salse_list = []
opincome_list = []
orprofit_list = []
net_income_list = []
roe_list = []
icr_list = []
reserveration_list = []
lia_list = []
day_list = []

# con = sqlite3.connect("E:\Value\시가총액.db")
# df = pd.read_sql("SELECT * FROM Y2018M01", con, index_col='index')

for j in com_line:

    inststmarketeye = win32com.client.Dispatch("CpSysDib.MarketEye")
    inststmarketeye.SetInputValue(0, (20, 96, 97, 98, 99, 100, 101, 102, 103, 104, 107, 108, 109, 110, 111))
    inststmarketeye.SetInputValue(1, j)
    time.sleep(0.3)
    inststmarketeye.BlockRequest()
    numStock = inststmarketeye.GetHeaderValue(2)

    for k in range(numStock):

        stocknum = inststmarketeye.GetDataValue(0, k)  # 총상장주식수
        bps = inststmarketeye.GetDataValue(1, k)  # 분기주당순자산
        salse_delta = inststmarketeye.GetDataValue(2, k)  # 분기매출액증가율
        opincome_delta = inststmarketeye.GetDataValue(3, k)  # 분기영업이익증가율
        orprofit_delta = inststmarketeye.GetDataValue(4, k)  # 분기경상이익증가율
        net_income_delta = inststmarketeye.GetDataValue(5, k)  # 분기순이익증가율
        salse = inststmarketeye.GetDataValue(6, k)  # 분기매출액
        opincome = inststmarketeye.GetDataValue(7, k)  # 분기영업이익
        orprofit = inststmarketeye.GetDataValue(8, k)  # 분기경상이익
        net_income = inststmarketeye.GetDataValue(9, k)  # 분기당기순이익
        roe = inststmarketeye.GetDataValue(10, k)  # 분기ROE
        icr = inststmarketeye.GetDataValue(11, k)  # 분기이자보상비율
        reserveration = inststmarketeye.GetDataValue(12, k)  # 분기유보율
        lia_ratio = inststmarketeye.GetDataValue(13, k)  # 분기부채비율
        day = inststmarketeye.GetDataValue(14, k)  # 최근분기년월

        stocknum_list.append(stocknum)
        bps_list.append(bps)
        salse_delta_list.append(salse_delta)
        opincome_delta_list.append(opincome_delta)
        net_income_delta_list.append(net_income_delta)
        orprofit_delta_list.append(orprofit_delta)
        salse_list.append(salse)
        opincome_list.append(opincome)
        orprofit_list.append(orprofit)
        net_income_list.append(net_income)
        roe_list.append(roe)
        icr_list.append(icr)
        reserveration_list.append(reserveration)
        lia_list.append(lia_ratio)
        day_list.append(day)

        b = b + 1
        print(str(b) + "/" + str(var))


dataFrame = pd.DataFrame({"총상장주식수": stocknum_list, "분기BPS": bps_list, "분기매출액증가율": salse_delta_list,
                          "분기영업이익증가율": opincome_delta_list, "분기경상이익증가율": orprofit_delta_list,
                          "분기당기순이익증가율": net_income_delta_list, "분기매출액": salse_list, "분기영업이익": opincome_list,
                          "분기경상이익": orprofit_list, "분기당기순이익": net_income_list, "분기ROE": roe_list, "분기이자보상비율": icr_list,
                          "분기유보율": reserveration_list, "분기부채비율": lia_list, "최근분기년월": day_list}, com_code)


con = sqlite3.connect("E:\\Value\\분기보고서.db")
dataFrame.to_sql(date, con)

print("end")
