import pandas as pd
import sqlite3
import win32com.client
import time
import datetime

# 시장 개폐시간 모듈
inCpCodeMgr = win32com.client.Dispatch("CpUtil.CpCodeMgr")

# 종목코드관련 모듈
inCpStockCode = win32com.client.Dispatch("CpUtil.CpStockCode")

# 종목코드 갯수
length = inCpStockCode.GetCount()

#  CYBOS의 각종 상태를 확인
inCpCybos = win32com.client.Dispatch("CpUtil.CpCybos")

# 종목 가격 모듈
instStockChart = win32com.client.Dispatch("CpSysDib.StockChart")


class Cybos:

    # 가격 database 구축
    def make_price_database(self, start, end, name):
        a = 0
        for j in range(length):

            code = inCpStockCode.GetData(0, j)

            instStockChart.SetInputValue(0, code)
            instStockChart.SetInputValue(1, ord('1'))
            instStockChart.SetInputValue(2, end)
            instStockChart.SetInputValue(3, start)
            instStockChart.SetInputValue(5, (0, 2, 3, 4, 5, 8, 12, 13))
            instStockChart.SetInputValue(6, ord('D'))
            # instStockChart.SetInputValue(9, ord('1'))  # 수정주가

            instStockChart.BlockRequest()

            numdata = instStockChart.GetHeaderValue(3)

            day_list = []
            open_list = []
            high_list = []
            low_list = []
            end_list = []
            volume_list = []
            stock_list = []
            maca_list = []

            for i in range(numdata):
                day = instStockChart.GetDataValue(0, i)
                openprice = instStockChart.GetDataValue(1, i)
                highprice = instStockChart.GetDataValue(2, i)
                lowprice = instStockChart.GetDataValue(3, i)
                endprice = instStockChart.GetDataValue(4, i)
                volume = instStockChart.GetDataValue(5, i)
                stock = instStockChart.GetDataValue(6, i)
                maca = instStockChart.GetDataValue(7, i)

                day_list.insert(0, day)
                open_list.insert(0, openprice)
                high_list.insert(0, highprice)
                low_list.insert(0, lowprice)
                end_list.insert(0, endprice)
                volume_list.insert(0, volume)
                stock_list.insert(0, stock)
                maca_list.insert(0, maca)

            df2 = pd.DataFrame({"시가": open_list, "고가": high_list, "저가": low_list, "종가": end_list,
                                "거래량": volume_list, "상장주식수": stock_list, "시가총액": maca_list}, day_list)

            con2 = sqlite3.connect("E:\\quant\\backtest\\" + name + ".db")
            df2.to_sql(code, con2, if_exists='append')
            a = a + 1

            print(str(a) + "/" + str(length))
            time.sleep(0.25)

    # 가격 database update
    def price_database_update(self):

        now = datetime.datetime.now()
        time_now = int(str(now)[11:16].replace(":", ""))
        closetime = inCpCodeMgr.GetMarketEndTime()
        if time_now > closetime:
            end = str(now)[:10].replace("-", "")
        else:
            yesterday = now - datetime.timedelta(days=1)
            end = str(yesterday)[:10].replace("-", "")

        a = 0

        file = open("E:\\quant\\backtest\\주가update날짜.txt", 'rt')
        date = file.readline()
        file.close()
        for j in range(length):

            code = inCpStockCode.GetData(0, j)

            instStockChart.SetInputValue(0, code)
            instStockChart.SetInputValue(1, ord('1'))
            instStockChart.SetInputValue(2, end)
            instStockChart.SetInputValue(3, date)
            instStockChart.SetInputValue(5, (0, 2, 3, 4, 5, 8, 12, 13))
            instStockChart.SetInputValue(6, ord('D'))
            # instStockChart.SetInputValue(9, ord('1'))  # 수정주가

            instStockChart.BlockRequest()

            numdata = instStockChart.GetHeaderValue(3)

            day_list = []
            open_list = []
            high_list = []
            low_list = []
            end_list = []
            volume_list = []
            stock_list = []
            maca_list = []

            for i in range(numdata):
                day = instStockChart.GetDataValue(0, i)
                openprice = instStockChart.GetDataValue(1, i)
                highprice = instStockChart.GetDataValue(2, i)
                lowprice = instStockChart.GetDataValue(3, i)
                endprice = instStockChart.GetDataValue(4, i)
                volume = instStockChart.GetDataValue(5, i)
                stock = instStockChart.GetDataValue(6, i)
                maca = instStockChart.GetDataValue(7, i)

                day_list.insert(0, day)
                open_list.insert(0, openprice)
                high_list.insert(0, highprice)
                low_list.insert(0, lowprice)
                end_list.insert(0, endprice)
                volume_list.insert(0, volume)
                stock_list.insert(0, stock)
                maca_list.insert(0, maca)

            df2 = pd.DataFrame({"시가": open_list[1:], "고가": high_list[1:], "저가": low_list[1:], "종가": end_list[1:],
                                "거래량": volume_list[1:], "상장주식수": stock_list[1:], "시가총액": maca_list[1:]}, day_list[1:])

            con2 = sqlite3.connect("E:\\quant\\backtest\\주가.db")
            df2.to_sql(code, con2, if_exists='append')
            a = a + 1

            print(str(a) + "/" + str(length))
            time.sleep(0.25)

        file1 = open("E:\\quant\\backtest\\주가update날짜.txt", 'w')

        file1.write(end)
        file1.close()


inst = Cybos()
# inst.make_price_database("20000101", "20180310", "주가")
inst.price_database_update()

