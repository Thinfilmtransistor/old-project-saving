import datetime
import pandas as pd
import sqlite3
now = datetime.datetime.now()

tomorrow = now - datetime.timedelta(days=1)
print(str(tomorrow)[:10].replace("-", ""))
con = sqlite3.connect("E:\\backtest\\주가.db")
df = pd.read_sql("SELECT * FROM A000020", con)

date = list(df['index'])
recent_date = date[len(date)-1]
print("가장최근일자", date[len(date)-1])