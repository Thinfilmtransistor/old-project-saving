from pywinauto import application
from pywinauto import timings
import time
import os


app = application.Application().start("C:/DAISHIN/STARTER/ncStarter.exe")

# title = "u'CYBOS Starter'"
# dlg = timings.WaitUntilPasses(180, 0.5, lambda: app.window_(title=title))

pass_ctrl = app.ONECLIKEdit2
pass_ctrl.SetFocus()
pass_ctrl.TypeKeys('cru161')
