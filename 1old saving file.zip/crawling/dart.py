from urllib.request import urlopen
import pandas as pd
import webbrowser
from bs4 import BeautifulSoup
import requests
import lxml.html
import re

apikey = "5bd76b4d67d72be629ea556219bd5931f507d7a8"
company_code = "000020"

# url_search = "http://dart.fss.or.kr/api/search.xml?auth={0}&crp_cd={1}&start_dt=19990101&bsn_tp=A001&bsn_tp=A002&bsn_tp=A003"
url_search = "http://dart.fss.or.kr/api/search.xml?auth={0}&crp_cd={1}&start_dt=20080101&fin_rpt=Y&bsn_tp=A001&page_set=100"

url = url_search.format(apikey, company_code)
resultXML = urlopen(url)
result = resultXML.read()

xmlsoup = BeautifulSoup(result, 'html.parser')


data = pd.DataFrame()

te = xmlsoup.findAll("list")

# [corporation class, corporation name, corporation code, report name, reception number, 공시제출인 명, reception date, remark]
for t in te:
    temp = pd.DataFrame(([[t.crp_cls.string, t.crp_nm.string, t.crp_cd.string, t.rpt_nm.string, t.rcp_no.string, t.flr_nm.string, t.rcp_dt.string, t.rmk.string]]),
                      columns = ["crp_cls", "crp_nm", "crp_cd", "rpt_nm", "rcp_no", "flr_nm", "rcp_dt", "rmk"])
    data = pd.concat([data, temp])

data = data.reset_index(drop=True)

print(data)
user_num = int(input("몇 번째 보고서를 확인하시겠습니까?"))

crp_no = data['rcp_no'][user_num]
url2 = "http://dart.fss.or.kr/dsaf001/main.do?rcpNo=" + crp_no

webbrowser.open(url2)

# ==================== 이어서 =====================================================================================

req = requests.get(url2)
tree = lxml.html.fromstring(req.text)
onclick = tree.xpath('//*[@id="north"]/div[2]/ul/li[1]/a')[0].attrib['onclick']
pattern = re.compile("^openPdfDownload\('\d+',\s*'(\d+)'\)")
dcm_no = pattern.search(onclick).group(1)

url_downlowd = "http://dart.fss.or.kr/pdf/download/excel.do?rcp_no={0}&dcm_no={1}&lang=ko"
download = url_downlowd.format(crp_no,dcm_no)
webbrowser.open(download)

"""
# url_parsing = "http://dart.fss.or.kr/report/viewer.do?rcpNo=" + data['rcp_no'][user_num] + "&dcmNo=" + dcm_no + "&eleId=15&offset=1489233&length=105206&dtd=dart3.xsd"

#STEP 2
report = urlopen(url_parsing)
r = report.read()

#STEP 3
xmlsoup_another = BeautifulSoup(r, 'html.parser')
body = xmlsoup_another.find("body")
table = body.find_all("table")
p = pd.parser.make2d(table[3])

sheet = pd.DataFrame(p[2:], columns=["구분","38기반기_3개월","38기반기_누적","37기반기_3개월","37기반기_누적"])

#STEP 4
sheet["38기반기_3개월"]=sheet["38기반기_3개월"].str.replace(",","")
sheet["temp"]=sheet["38기반기_3개월"].str[0]

sheet.ix[sheet["temp"]=="(","38기반기_3개월"]=sheet["38기반기_3개월"].str.replace("(","-")
sheet["38기반기_3개월"]=sheet["38기반기_3개월"].str.split(")").str[0]
sheet.ix[sheet["38기반기_3개월"]=="","38기반기_3개월"]="0"
sheet["38기반기_3개월"]=sheet["38기반기_3개월"].astype(int)

#STEP 5
sale = sheet[sheet["구분"]=="매출액"].iloc[0,1]
sale_cost = sheet[sheet["구분"]=="매출원가"].iloc[0,1]
sale_profit_ratio=(sale-sale_cost)/sale*100

# round는 반올림
sale_profit_ratio=round(sale_profit_ratio,1)
print("매출총이익률은 "+str(sale_profit_ratio)+"% 입니다")
"""