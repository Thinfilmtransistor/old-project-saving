import pandas as pd
import time

def get_finstate_naver(code, fin_type='0', freq_type='Q'):

    # code: 종목코드
    # fin_type = '0': 재무제표 종류(0: 주재무제표, 1: GAAP개별, 2: GAAP연결, 3: IFRS별도, 4: IFRS연결)
    # freq_type = 'Y': 기간(Y: 년, Q: 분기)
    url = 'http://companyinfo.stock.naver.com/v1/company/ajax/cF1001.aspx?cmp_cd={0}&fin_typ={1}&freq_typ={2}'.format(code, fin_type, freq_type)

    dfs = pd.read_html(url)
    df = dfs[0]
    df = df.set_index('주요재무정보')

    indexlist = []
    for i in df.index:
        indexlist.append(i[0])
    df.index = indexlist

    cols = df.columns
    collist = list(cols.levels[1])
    col = []
    for i in collist[:-1]:
        temp = i.replace("\n", "").replace("\t", "")
        if temp == "":
            pass
        else:
            col.append(temp)
    while len(cols) > len(col):
        col.insert(0, "")
    df.columns = col

    df1 = df.dropna(axis=1, how='all')
    dft = df1.T
    dft.rename(columns={'주요재무정보': 'date'}, inplace=True)
    print(dft)
    dft.to_csv("E:\\backtest\\naver\\20180621\\" + code + '.csv')
    time.sleep(0.3)

# get_finstate_naver("005930")







