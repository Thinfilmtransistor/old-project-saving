from naver import get_finstate_naver

f = open("E:\\backtest\\naver\\20180621.txt", "r")
data = f.readlines()
a = 0
for i in data:
    a = a + 1
    code = i.replace("\n", "")
    get_finstate_naver(code)
    print(a, "/", len(data))
