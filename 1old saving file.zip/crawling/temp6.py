f = open("C:\\Users\\home\\Downloads\\20180618000261_ifrs\\ifrs_for_00119195\\dimensions_ifrs_for_00119195\\cal_ifrs_for_00119195_2018-03-24.xml", "r")

lines = f.readlines()
for i in lines:
    print(i)