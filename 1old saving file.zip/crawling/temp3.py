from urllib.request import urlopen
import pandas as pd
import webbrowser
from bs4 import BeautifulSoup
import requests
import lxml.html
import re

p1 = re.compile("재무")
p2 = re.compile("[(],+[)]")


apikey = "5bd76b4d67d72be629ea556219bd5931f507d7a8"
company_code = "000020"

url = "http://dart.fss.or.kr/dsaf001/main.do?rcpNo=20080630000283"

# resultXML = urlopen(url)
# result = resultXML.read()
# print(result)

resultXML = requests.get(url)
resp = resultXML.text
a = -1
temp = resp.split("\n")
for i in temp:
    a = a + 1
    m = p1.search(i)
    if m:
        print(i)
        print(temp[a + 1])
        print(temp[a + 4])
        # stg1 = temp[a + 4].lstrip()
        stg = temp[a + 4].replace("\t","").replace("click: function() {viewDoc(","").replace(");}","").replace("'","").replace("\r", "").replace(" ","")
        st_list = stg.split(",")
        print(st_list)
        url_parsing = "http://dart.fss.or.kr/report/viewer.do?rcpNo=" + st_list[0] + \
                      "&dcmNo=" + st_list[1] + \
                      "&eleId=" + st_list[2] + \
                      "&offset=" + st_list[3] + \
                      "&length=" + st_list[4] + \
                      "&dtd=" + st_list[5]
        print(url_parsing)
        crp_cata = requests.get(url_parsing)
        # xmlsoup_another = BeautifulSoup(crp_cata.text, 'html.parser')
        # print(xmlsoup_another)
        dfs = pd.read_html(url_parsing)
        for j in range(len(dfs)):
            if j in [18,19,20,21,24,25]:
                print(dfs[j])
                print("================================================================")
        break

