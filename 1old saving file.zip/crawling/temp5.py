from urllib.request import urlopen
import pandas as pd
import webbrowser
from bs4 import BeautifulSoup
import requests
import lxml.html
import re
import time


# dcm_no 구하기
def get_dcm(url2):
    req = requests.get(url2)
    tree = lxml.html.fromstring(req.text)
    onclick = tree.xpath('//*[@id="north"]/div[2]/ul/li[1]/a')[0].attrib['onclick']
    pattern = re.compile("^openPdfDownload\('\d+',\s*'(\d+)'\)")
    dcm_no = pattern.search(onclick).group(1)
    return dcm_no

# 제무재표 exel download
def exel_dl(crp_no, dcm_no):
    url_downlowd = "http://dart.fss.or.kr/pdf/download/excel.do?rcp_no={0}&dcm_no={1}&lang=ko"
    download = url_downlowd.format(crp_no, dcm_no)
    webbrowser.open(download)


def get_finance_exel(company_code):
    apikey = "5bd76b4d67d72be629ea556219bd5931f507d7a8"

    url_search = "http://dart.fss.or.kr/api/search.xml?auth={0}&crp_cd={1}&start_dt=20180101&fin_rpt=Y&bsn_tp=A003&page_set=10"

    url = url_search.format(apikey, company_code)
    resultXML = urlopen(url)
    result = resultXML.read()

    xmlsoup = BeautifulSoup(result, 'html.parser')

    data = pd.DataFrame()

    te = xmlsoup.findAll("list")

# [corporation class, corporation name, corporation code, report name, reception number, 공시제출인 명, reception date, remark]
    for t in te:
        temp = pd.DataFrame(([[t.crp_cls.string, t.crp_nm.string, t.crp_cd.string, t.rpt_nm.string, t.rcp_no.string, t.flr_nm.string, t.rcp_dt.string, t.rmk.string]]),
                            columns = ["crp_cls", "crp_nm", "crp_cd", "rpt_nm", "rcp_no", "flr_nm", "rcp_dt", "rmk"])
        data = pd.concat([data, temp])

    data = data.reset_index(drop=True)
    print(data)

    for i in range(len(data)):
        crp_no = data['rcp_no'][i]
        url2 = "http://dart.fss.or.kr/dsaf001/main.do?rcpNo=" + crp_no
        dcm_no = get_dcm(url2)
        exel_dl(crp_no, dcm_no)
        time.sleep(1)





