# 전략 backup


import sqlite3
import pandas as pd

f = open("E:\\quant\\backtest\\naver\\20180621.txt", "r")
data = f.readlines()

con1 = sqlite3.connect("E:\\quant\\backtest\\주가.db")


# 단위 억원
many = {}

sum_pbr = 0
sum_pcr = 0
sum_psr = 0
sum_por = 0
for i in data:
    code = i.replace("\n", "")
    # print(code)
    rawdata = pd.read_csv("E:\\quant\\backtest\\naver\\20180621\\" + code + ".csv", index_col="Unnamed: 0")

    if not rawdata.empty:

        if rawdata['영업이익'][-1] > 0:
            # if rawdata['영업이익'][-1] > rawdata['영업이익'][0]:
                if rawdata['영업활동현금흐름'][-1] > 0:

                    df1 = pd.read_sql("SELECT * FROM A" + code, con1)
                    maca = df1.ix[df1.shape[0] - 1][5]
                    pbr = maca/(rawdata['자본총계(지배)'][-1]*100000000)

                    if (pbr > 0.4) and (pbr < 1):
                        pcr = maca / (rawdata['영업활동현금흐름'][-1] * 100000000)
                        if pcr < 10:
                            psr = maca / (rawdata['매출액'][-1] * 100000000)
                            por = maca / (rawdata['영업이익'][-1] * 100000000)
                            if por < 40:
                                if psr < 10:
                                    many[code] = [pbr, pcr, psr, por]
                                    sum_pbr = sum_pbr + pbr
                                    sum_pcr = sum_pcr + pcr
                                    sum_psr = sum_psr + psr
                                    sum_por = sum_por + por

frame = pd.DataFrame(many, index=["pbr", "pcr", "psr", "por"])
frameT = frame.T
print(frameT.sort_values(by=['pbr']))
print(frameT.shape[0])
print("avg pbr",sum_pbr/frameT.shape[0])
print("avg pcr",sum_pcr/frameT.shape[0])
print("avg psr",sum_psr/frameT.shape[0])
print("avg por",sum_por/frameT.shape[0])
