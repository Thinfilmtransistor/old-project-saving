import os
f = open("E:\\quant\\유가증권목록.txt","r")
lines = f.readlines()
f.close()

def make_foler(folder_name):
    if not os.path.isdir(folder_name):
        os.mkdir(folder_name)

for i in lines:
    code = i.replace("\n","")
    # input("press enter to process")
    directory = "E:\\quant\\backtest\\" + code
    make_foler(directory)
    print(code)