import sqlite3
import pandas as pd
import re

f = open("E:\\quant\\backtest\\naver\\20180621.txt", "r")
data = f.readlines()

con1 = sqlite3.connect("E:\\quant\\backtest\\주가.db")


def isnan(num):
    return num == num


def sum_4quater(state):
    # print(code)
    var = 0
    a = 0
    if len(rawdata.index) > 4:
        for k in [-4, -3, -2, -1]:
            if isnan(rawdata[state][k]):
                var = var + rawdata[state][k]
                a = a + 1
    else:
        for k in rawdata.index:
            if isnan(rawdata[state][k]):
                var = var + rawdata[state][k]
                a = a + 1
    return var * (4 / a)


p1 = re.compile('[(]E[)]')

# 단위 억원
many = {}
b = 0
sum_pbr = 0
sum_pcr = 0
sum_psr = 0
sum_por = 0
dic_ca = {}
for i in data:
    b = b + 1
    print(b, len(data))
    code = i.replace("\n", "")
    rawdata = pd.read_csv("E:\\quant\\backtest\\naver\\20180621\\" + code + ".csv", index_col="Unnamed: 0")

    df1 = pd.read_sql("SELECT * FROM A" + code, con1)
    maca = df1.ix[df1.shape[0] - 1][5]
    dic_ca[code] = maca

    if not rawdata.empty:
        for j in rawdata.index:
            m = p1.search(j)
            if m:
                rawdata = rawdata.drop(j)
        if rawdata['영업이익'][-1] > 0:
            if rawdata['영업활동현금흐름'][-1] > 0:


                if isnan(rawdata["자본총계(지배)"][-1]):
                    pbr = maca / (rawdata['자본총계(지배)'][-1] * 100000000)

                if (pbr >=0.4) and (pbr < 1):
                    pcr = maca / (sum_4quater('영업활동현금흐름') * 100000000)
                    if (pcr < 8.46) and (pcr > 0):
                        psr = maca / (sum_4quater('매출액') * 100000000)
                        por = maca / (sum_4quater('영업이익') * 100000000)
                        if (por < 8.40) and (por > 0):
                            if psr < 0.69:
                                many[code] = [pbr, pcr, psr, por]
                                sum_pbr = sum_pbr + pbr
                                sum_pcr = sum_pcr + pcr
                                sum_psr = sum_psr + psr
                                sum_por = sum_por + por

se = pd.Series(dic_ca, name="capital")
se = se.sort_values(ascending=False).rank(ascending=False)

frame = pd.DataFrame(many, index=["pbr", "pcr", "psr", "por"])
frameT = frame.T
df2 = frameT.sort_values(by=['pbr'])
df3 = pd.concat([df2, se], axis=1)
df3 = df3.dropna(axis=0)
print(df3[df3['capital'] > 1000])

print(frameT.shape[0])
print("avg pbr",sum_pbr/frameT.shape[0])
print("avg pcr",sum_pcr/frameT.shape[0])
print("avg psr",sum_psr/frameT.shape[0])
print("avg por",sum_por/frameT.shape[0])
for i in frameT.sort_values(by=['pbr']).index:
    print(i)



