"""
import DartModule

f = open("E:\\quant\\유가증권목록.txt","r")
lines = f.readlines()
f.close()

for i in lines:
    code = i.replace("\n","")
    print(code)
    input("press enter to process")
    DartModule.get_finance_exel(code)
"""

import temp5
import time
f = open("E:\\quant\\유가증권목록.txt","r")
lines = f.readlines()
f.close()
t = 0
for i in lines:
    t = t + 1
    code = i.replace("\n","")
    print(code)
    temp5.get_finance_exel(code)
    if t % 60 == 0:
        time.sleep(5)


