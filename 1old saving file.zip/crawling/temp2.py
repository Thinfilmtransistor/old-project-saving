import requests
import pandas as pd
import re
# url = "http://companyinfo.stock.naver.com/v1/company/ajax/cF1001.aspx?cmp_cd=000660&fin_typ=0&freq_typ=Y"
# html = requests.get(url).text
# df = pd.read_html(html, index_col='주요재무정보')[0]
# print(df.index)
# print(df.columns)

"""
html = html.replace('<th class="bg r01c02 endLine line-bottom"colspan="8">연간</th>', "")
html = html.replace("<span class='span-sub'>(IFRS연결)</span>", "")
html = html.replace("<span class='span-sub'>(IFRS별도)</span>", "")
html = html.replace("<span class='span-sub'>(GAAP개별)</span>", "")

html = html.replace('\t', '')
html = html.replace('\n', '')
html = html.replace('\r', '')

df = pd.read_html(html, index_col='주요재무정보')[0]
print(df.head())
"""


def isNaN(num):
    return num == num
# x=float('nan')
# print(isNaN(x))


p1 = re.compile('[(]E[)]')

rawdata = pd.read_csv("E:\\quant\\backtest\\naver\\20180621\\016790.csv", index_col="Unnamed: 0")
print(rawdata['영업활동현금흐름'])
var = 0
a = 0
if not rawdata.empty:
    for j in rawdata.index:

        m = p1.search(j)
        if m:
            rawdata = rawdata.drop(j)
    # if len(rawdata.index) > 4:
    #     for k in [-4,-3,-2,-1]:
    #         print(rawdata['매출액'][k])
    #         print(isNaN(rawdata['매출액'][k]))
    #         if isNaN(rawdata['매출액'][k]):

                # var = var + rawdata['매출액'][k]
                # a = a + 1
# print(var * (4/a))



        # print(rawdata['매출액'][-4], rawdata['매출액'][-3], rawdata['매출액'][-2], rawdata['매출액'][-1])