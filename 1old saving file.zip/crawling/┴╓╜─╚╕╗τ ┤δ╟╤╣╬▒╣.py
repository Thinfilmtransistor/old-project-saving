import sqlite3
import pandas as pd
import re


def isnan(num):
    return num == num


f = open("E:\\quant\\backtest\\naver\\20180621.txt", "r")
data = f.readlines()
f.close()

con1 = sqlite3.connect("E:\\quant\\backtest\\주가.db")
p1 = re.compile('[(]E[)]')

"""
자본총계(지배)
영업활동현금흐름
매출액
영업이익
"""


def avgmarket(target): # PBR, PCR, PSR, POR
    if target =="PBR":
        state = "자본총계(지배)"
    if target =="PCR":
        state = "영업활동현금흐름"
    if target =="PSR":
        state = "매출액"
    if target =="POR":
        state = "영업이익"

    var1 = 0
    maca = 0

    for i in data:
        code = i.replace("\n", "")
        print(code)
        rawdata = pd.read_csv("E:\\quant\\backtest\\naver\\20180621\\" + code + ".csv", index_col="Unnamed: 0")
        var = 0
        a = 0

        if not rawdata.empty:
            for j in rawdata.index:
                m = p1.search(j)
                if m:
                    rawdata = rawdata.drop(j)

            if target == "PBR":
                if isnan(rawdata[state][-1]):
                    var1 = var1 + rawdata[state][-1]

            elif len(rawdata.index) > 4:
                for k in [-4, -3, -2, -1]:
                    # print(rawdata[state][k])
                    if isnan(rawdata[state][k]):
                        var = var + rawdata[state][k]
                        # print(a, var)
                        a = a + 1
                if a != 0:
                    var1 = var1 + var * (4 / a)

            df1 = pd.read_sql("SELECT * FROM A" + code, con1)
            maca = maca + df1.ix[df1.shape[0] - 1][5]
            print(code, var1)
    result = maca / (var1 * 100000000)
    print(result)


avgmarket("POR")
