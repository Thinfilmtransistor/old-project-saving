import pandas as pd
import sqlite3
import time
import matplotlib.pyplot as plt
start_time = time.time()
f = open("E:\\backtest\\naver\\20180314\\20180314.txt", "r")
file = f.readlines()
f.close()
code = []
for i in file:
    code.append(i.replace("\n", ""))

target = []
equity = []
revenue = []
netprofit = []
cfo = []
stocknum = []

for i in code[:40]:
    rawdata = pd.read_csv("E:\\backtest\\naver\\20180314\\" + i + ".csv" , index_col="Unnamed: 0")
    # print(rawdata)

    for j in rawdata.index:
        if j == "2017/09(IFRS별도)":
            data = rawdata.ix['2017/09(IFRS별도)']
            if (data['매출액'] > 0) & (data['영업활동현금흐름'] > 0) & (data['발행주식수(보통주)'] > 0):
                if "당기순이익(지배)" in rawdata.columns:
                    if (data['당기순이익(지배)'] > 0) & (data['자본총계(지배)'] > 0):
                        target.append(i)
                        equity.append((data['자본총계(지배)']))
                        revenue.append(data['매출액'])
                        netprofit.append(data['당기순이익(지배)'])
                        cfo.append(data['영업활동현금흐름'])
                        stocknum.append(data['발행주식수(보통주)'])
                elif "당기순이익" in rawdata.columns:
                    if (data['당기순이익'] > 0) & (data['자본총계'] > 0):
                        target.append(i)
                        equity.append((data['자본총계']))
                        revenue.append(data['매출액'])
                        netprofit.append(data['당기순이익'])
                        cfo.append(data['영업활동현금흐름'])
                        stocknum.append(data['발행주식수(보통주)'])
        elif j == "2017/09(IFRS연결)":
            data = rawdata.ix['2017/09(IFRS연결)']
            if (data['매출액'] > 0) & (data['영업활동현금흐름'] > 0) & (data['발행주식수(보통주)'] > 0):
                if "당기순이익(지배)" in rawdata.columns:
                    if (data['당기순이익(지배)'] > 0) & (data['자본총계(지배)'] > 0):
                        target.append(i)
                        equity.append((data['자본총계(지배)']))
                        revenue.append(data['매출액'])
                        netprofit.append(data['당기순이익(지배)'])
                        cfo.append(data['영업활동현금흐름'])
                        stocknum.append(data['발행주식수(보통주)'])
                elif "당기순이익" in rawdata.columns:
                    if (data['당기순이익'] > 0) & (data['자본총계'] > 0):
                        target.append(i)
                        equity.append((data['자본총계']))
                        revenue.append(data['매출액'])
                        netprofit.append(data['당기순이익'])
                        cfo.append(data['영업활동현금흐름'])
                        stocknum.append(data['발행주식수(보통주)'])


df = pd.DataFrame({'자본총계': equity, '매출액': revenue, "당기순이익(지배)": netprofit, "영업활동현금흐름": cfo, "발행주식수(보통주)": stocknum}, target)
# print(df)
"""
for i in target:
    url = 'http://finance.naver.com/item/main.nhn?code={}'.format(i)
    print(url)
"""
con1 = sqlite3.connect("E:\\backtest\\주가.db")


per = []
psr = []
pcr = []
pbr = []
maca_list = []

for i in target:
    # print(i)
    df1 = pd.read_sql("SELECT * FROM A" + i, con1)
    maca = df1.ix[df1.shape[0] - 1][5]
    per.append(maca / (df.ix[i][0] * 100000000))
    psr.append(maca / (df.ix[i][1] * 100000000))
    pcr.append(maca / (df.ix[i][3] * 100000000))
    pbr.append(maca / (df.ix[i][4] * 100000000))
    maca_list.append(maca)

# print(df)
df2 = pd.DataFrame({'PER': per, 'PSR': psr, "PCR": pcr, "PBR": pbr, "시가총액": maca_list}, target)
df3 = df2.sort_values(by=['시가총액'])[:int(df2.shape[0]*0.2)]
# print(df3)

per_rank = df3['PER'].rank()  # per 오름차순 rank
pbr_rank = df3['PBR'].rank()  # pbr 오름차순 rank
psr_rank = df3['PSR'].rank()  # psr 오름차순 rank
pcr_rank = df3['PCR'].rank()  # pcr 오름차순 rank

total_rank = (per_rank + pbr_rank + psr_rank + pcr_rank).rank()
result = pd.concat([per_rank, pbr_rank, psr_rank, pcr_rank, total_rank], axis=1)

result2 = pd.concat([df3, result], axis=1).sort_values(by=[0])
for i in result2.index:
    df4 = pd.read_sql("SELECT * FROM A" + i, con1)
    df4['종가'].plot()
    print(plt.show())
# print(result2.index)


print("--- %s seconds ---" % (time.time() - start_time))