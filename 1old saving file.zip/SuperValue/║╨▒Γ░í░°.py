# 시가총액 하위 20% 기업의 PER PBR PCR PSR 의 순위를 구해서 더한뒤 통합 순위를 매긴다

import pandas as pd
import sqlite3


con = sqlite3.connect("E:\Database\시가총액.db")
df = pd.read_sql("SELECT * FROM Y2018M01", con, index_col='index')

maca_rank = df['시가총액'].rank()  # 시가총액 오름차순 rank
maca_df = maca_rank.to_frame()
maca_sort = maca_df.sort_values(by='시가총액')
maca = list(maca_sort[:int(len(maca_sort)*0.2)].index)  # 시가총액 하위 20% list


f1 = open("E:\\Database\\2017_Q3_영업현금흐름_연결.txt", "r")
lines = f1.readlines()
cfo_com = []
cfo_value = []
for i in lines:
    temp = i.replace("\n", "")
    temp_list = temp.split("\t")
    cfo_com.append(temp_list[0])
    cfo_value.append(temp_list[1])

cfo_df = pd.DataFrame({"CFO": cfo_value}, cfo_com)

con1 = sqlite3.connect("E:\Database\분기보고서.db")
df1 = pd.read_sql("SELECT * FROM Y2017Q3", con1, index_col='index')

con2 = sqlite3.connect("E:\Value\가격.db")
df2 = pd.read_sql("SELECT * FROM Y2018M01D31", con2, index_col='index')

netincome = df1['분기당기순이익']
bps = df1['분기BPS']
salse = df1['분기매출액']
stocknum = df1['총상장주식수']

per_list = []
pbr_list = []
psr_list = []
pcr_list = []

for i in maca:
    eps = netincome.ix[i] / stocknum.ix[i]  # 분기주당순이익
    if eps > 0:
        per = df2.ix[i][0] / eps
        per_list.append(round(per, 6))
    else:
        per_list.append(99999)
    if bps.ix[i] == 0:
        pbr_list.append(99999)
    else:
        pbr = df2.ix[i][0] / bps.ix[i]
        pbr_list.append(round(pbr, 6))
    sps = salse.ix[i] / stocknum.ix[i]  # 분기주당매출액
    if sps > 0:
        psr = df2.ix[i][0] / sps
        psr_list.append(round(psr, 6))
    else:
        psr_list.append(99999)
    if i not in cfo_com:
        pcr_list.append(99999)
    elif float(cfo_df.ix[i][0]) < 0:
        pcr_list.append(99999)
    else:
        ratio2 = float(cfo_df.ix[i][0]) / stocknum.ix[i]  # 분기주당영업현금흐름
        pcr = df2.ix[i][0] / ratio2
        pcr_list.append(round(pcr, 6))

tempdata = pd.DataFrame({"PER": per_list, "PBR": pbr_list, "PSR": psr_list, "PCR": pcr_list}, maca)

per_rank = tempdata['PER'].rank()  # per 오름차순 rank
pbr_rank = tempdata['PBR'].rank()  # pbr 오름차순 rank
psr_rank = tempdata['PSR'].rank()  # psr 오름차순 rank
pcr_rank = tempdata['PCR'].rank()  # pcr 오름차순 rank


total = per_rank + pbr_rank + psr_rank + pcr_rank
total_df = total.to_frame()

total_sort = total_df.sort_values(by=0)
reference = list(total_sort.index)

df_total_rank_list = []
df_per_rank_list = []
df_pbr_rank_list = []
df_psr_rank_list = []
df_pcr_rank_list = []

for k in reference:
    df_total_rank_list.append(total[k])
    df_per_rank_list.append(per_rank[k])
    df_pbr_rank_list.append(pbr_rank[k])
    df_psr_rank_list.append(psr_rank[k])
    df_pcr_rank_list.append(pcr_rank[k])

reference_df = pd.DataFrame({"total_rank": df_total_rank_list, "per_rank": df_per_rank_list,
                             "pbr_rank": df_pbr_rank_list, "psr_rank": df_psr_rank_list, "pcr_rank": df_pcr_rank_list
                             }, reference)
result = reference_df.join(tempdata, how='left')
print(result)

con2 = sqlite3.connect("E:\\Value\\분기가공.db")
result.to_sql("Y2018M2", con2)
