import pandas as pd
import sqlite3

con1 = sqlite3.connect("E:\Value\분기가공.db")
df1 = pd.read_sql("SELECT * FROM Y2018M2", con1, index_col='index')

com_list = list(df1.index)

con2 = sqlite3.connect("E:\Database\사업보고서.db")
df2 = pd.read_sql("SELECT * FROM Y2016", con2, index_col='index')
net_income = df2['당기순이익']
allocation = df2['배당률']
income = df2['영업이익']
lia = df2['부채비율']

con3 = sqlite3.connect("E:\Database\분기보고서.db")
df3 = pd.read_sql("SELECT * FROM Y2017Q3", con3, index_col='index')

salse_q3 = df3['분기매출액']
salse_delta_q3 = df3['분기매출액증가율']
opincome_q3 = df3['분기영업이익']
opincome_delta_q3 = df3['분기영업이익증가율']
net_income_q3 = df3['분기당기순이익']
net_income_delta_q3 = df3['분기당기순이익증가율']


f1 = open("E:\\Value\\결과1.txt", "wt")
f2 = open("E:\\Value\\결과2.txt", "wt")
f3 = open("E:\\Value\\결과3.txt", "wt")
for i in com_list:
    if net_income.ix[i] > 0 and allocation.ix[i] > 0 and income.ix[i] > 0:
        f1.write(i + "\n")
    if net_income.ix[i] > 0 and allocation.ix[i] > 0 and income.ix[i] > 0 and\
        salse_q3.ix[i] > 0 and salse_delta_q3.ix[i] > 0 and opincome_q3.ix[i] > 0 and opincome_delta_q3.ix[i] > 0 and \
            net_income_q3.ix[i] > 0 and net_income_delta_q3.ix[i] > 0:
        f2.write(i + "\n")
    if net_income.ix[i] > 0 and allocation.ix[i] > 0 and income.ix[i] > 0 and\
        salse_q3.ix[i] > 0 and salse_delta_q3.ix[i] > 0 and opincome_q3.ix[i] > 0 and opincome_delta_q3.ix[i] > 0 and \
            net_income_q3.ix[i] > 0 and net_income_delta_q3.ix[i] > 0 and lia.ix[i] < 50:
        f3.write(i + "\n")

f1.close()
f2.close()
f3.close()
