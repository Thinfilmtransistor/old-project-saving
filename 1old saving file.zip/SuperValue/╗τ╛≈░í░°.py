# 시가총액 하위 20% 기업의 PER PBR PCR PSR 의 순위를 구해서 더한뒤 통합 순위를 매긴다

import pandas as pd
import sqlite3


con = sqlite3.connect("E:\Database\시가총액.db")
df = pd.read_sql("SELECT * FROM Y2018M01", con, index_col='index')

maca_rank = df['시가총액'].rank()  # 시가총액 오름차순 rank
maca_df = maca_rank.to_frame()
maca_sort = maca_df.sort_values(by='시가총액')
maca = list(maca_sort[:int(len(maca_sort)*0.2)].index)  # 시가총액 하위 20% list


f1 = open("E:\\Database\\2017_Q3_영업현금흐름_연결.txt", "r")
lines = f1.readlines()
cfo_com = []
cfo_value = []
for i in lines:
    temp = i.replace("\n", "")
    temp_list = temp.split("\t")
    cfo_com.append(temp_list[0])
    cfo_value.append(temp_list[1])

cfo_df = pd.DataFrame({"CFO": cfo_value}, cfo_com)

con1 = sqlite3.connect("E:\Database\사업보고서.db")
df1 = pd.read_sql("SELECT * FROM Y2016", con1, index_col='index')

con2 = sqlite3.connect("E:\Value\가격.db")
df2 = pd.read_sql("SELECT * FROM Y2018M01D31", con2, index_col='index')

netincome = df1['당기순이익']
bps = df1['BPS']
salse = df1['매출액']
stocknum = df1['총상장주식수']

per_list = []
pbr_list = []
psr_list = []
pcr_list = []

for i in maca:
    eps = netincome.ix[i] / stocknum.ix[i]  # 주당순이익
    if eps > 0:
        per = df2.ix[i][0] / eps
        per_list.append(round(per, 6))
    else:
        per_list.append(99999)
    if bps.ix[i] == 0:
        pbr_list.append(99999)
    else:
        pbr = df2.ix[i][0] / bps.ix[i]
        pbr_list.append(round(pbr, 6))
    sps = salse.ix[i] / stocknum.ix[i]  # 주당매출액
    if sps > 0:
        psr = df2.ix[i][0] / sps
        psr_list.append(round(psr, 6))
    else:
        psr_list.append(99999)
    if i not in cfo_com:
        pcr_list.append(99999)
    elif float(cfo_df.ix[i][0]) < 0:
        pcr_list.append(99999)
    else:
        ratio2 = float(cfo_df.ix[i][0]) / stocknum.ix[i]  # 주당영업현금흐름
        pcr = df2.ix[i][0] / ratio2
        pcr_list.append(round(pcr, 6))

tempdata = pd.DataFrame({"PER": per_list, "PBR": pbr_list, "PSR": psr_list, "PCR": pcr_list}, maca)

per_rank = tempdata['PER'].rank()  # per 오름차순 rank
pbr_rank = tempdata['PBR'].rank()  # pbr 오름차순 rank
psr_rank = tempdata['PSR'].rank()  # psr 오름차순 rank
pcr_rank = tempdata['PCR'].rank()  # pcr 오름차순 rank


total = per_rank + pbr_rank + psr_rank + pcr_rank
total_df = total.to_frame()

total_sort = total_df.sort_values(by=0)
reference = list(total_sort.index)

df_total_rank_list = []
df_per_rank_list = []
df_pbr_rank_list = []
df_psr_rank_list = []
df_pcr_rank_list = []

for k in reference:
    df_total_rank_list.append(total[k])
    df_per_rank_list.append(per_rank[k])
    df_pbr_rank_list.append(pbr_rank[k])
    df_psr_rank_list.append(psr_rank[k])
    df_pcr_rank_list.append(pcr_rank[k])

reference_df = pd.DataFrame({"total_rank": df_total_rank_list, "per_rank": df_per_rank_list,
                             "pbr_rank": df_pbr_rank_list, "psr_rank": df_psr_rank_list, "pcr_rank": df_pcr_rank_list
                             }, reference)
result = reference_df.join(tempdata, how='left')
print(result)


"""
con2 = sqlite3.connect("E:\Value\사업보고서.db")
df2 = pd.read_sql("SELECT * FROM Y2016", con2, index_col='index')
net_income = df2['당기순이익']
allocation = df2['배당률']
income = df2['영업이익']
lia = df2['부채비율']

con3 = sqlite3.connect("E:\Value\분기보고서.db")
df3 = pd.read_sql("SELECT * FROM Y2017Q3", con3, index_col='index')

salse_q3 = df3['분기매출액']
salse_delta_q3 = df3['분기매출액증가율']
opincome_q3 = df3['분기영업이익']
opincome_delta_q3 = df3['분기영업이익증가율']
net_income_q3 = df3['분기당기순이익']
net_income_delta_q3 = df3['분기당기순이익증가율']


f1 = open("E:\\Value\\결과1.txt", "wt")
f2 = open("E:\\Value\\결과2.txt", "wt")
f3 = open("E:\\Value\\결과3.txt", "wt")
for i in total_sort.index:
    if maca_sort.ix[i][0] <= 408 and net_income.ix[i] > 0 and allocation.ix[i] > 0 and income.ix[i] > 0:
        f1.write(i + "\n")
    if maca_sort.ix[i][0] <= 408 and net_income.ix[i] > 0 and allocation.ix[i] > 0 and income.ix[i] > 0 and\
        salse_q3.ix[i] > 0 and salse_delta_q3.ix[i] > 0 and opincome_q3.ix[i] > 0 and opincome_delta_q3.ix[i] > 0 and \
            net_income_q3.ix[i] > 0 and net_income_delta_q3.ix[i] > 0:
        f2.write(i + "\n")
    if maca_sort.ix[i][0] <= 408 and net_income.ix[i] > 0 and allocation.ix[i] > 0 and income.ix[i] > 0 and\
        salse_q3.ix[i] > 0 and salse_delta_q3.ix[i] > 0 and opincome_q3.ix[i] > 0 and opincome_delta_q3.ix[i] > 0 and \
            net_income_q3.ix[i] > 0 and net_income_delta_q3.ix[i] > 0 and lia.ix[i] < 50:
        f3.write(i + "\n")

f1.close()
f2.close()
f3.close()
"""