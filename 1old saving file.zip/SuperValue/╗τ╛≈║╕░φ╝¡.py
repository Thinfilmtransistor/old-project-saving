# CYBOS 사업보고서 가져오기

import win32com.client
import time
import pandas as pd
import sqlite3
import datetime

f1 = open("E:\\Value\\종목코드.txt", "r")
lines1 = f1.readlines()

com_line = []
block = []
com_code = []
var = len(lines1)
a = 0
for i in lines1:
    temp = "A" + i.replace("\n", "")
    block.append(temp)
    com_code.append(temp)
    a = a + 1
    if a % 200 == 0:
        com_line.append(block)
        block = []
    elif a == var:
        com_line.append(block)
        block = []

b = 0

now = datetime.datetime.now()
date = "D" + str(now)[:10].replace("-", "")

stocknum_list = []
per_list = []
eps_list = []
capital_list = []
parvalue_list = []
allocation_list = []
lia_list = []
reserveration_list = []
roe_list = []
salse_delta_list = []
orprofit_delta_list = []
net_income_delta_list = []
salse_list = []
orprofit_list = []
net_income_list = []
bps_list = []
income_delta_list = []
income_list = []
icr_list = []
day_list = []

for j in com_line:

    inststmarketeye = win32com.client.Dispatch("CpSysDib.MarketEye")
    inststmarketeye.SetInputValue(0, (20, 67, 70, 71, 72, 73, 75, 76, 77, 78, 79, 80, 86, 87, 88, 89, 90, 91, 94, 95))
    inststmarketeye.SetInputValue(1, j)
    time.sleep(0.3)
    inststmarketeye.BlockRequest()
    numStock = inststmarketeye.GetHeaderValue(2)

    for k in range(numStock):
        stocknum = inststmarketeye.GetDataValue(0, k)  # 총상장주식수
        per = inststmarketeye.GetDataValue(1, k)  # PER
        eps = inststmarketeye.GetDataValue(2, k)  # EPS
        capital = inststmarketeye.GetDataValue(3, k) * 1000000  # 자본금 (백만)
        parvalue = inststmarketeye.GetDataValue(4, k)  # 액면가
        allocation = inststmarketeye.GetDataValue(5, k)  # 배당률
        lia_ratio = inststmarketeye.GetDataValue(6, k)  # 부채비율
        reserveration = inststmarketeye.GetDataValue(7, k)  # 유보율
        roe = inststmarketeye.GetDataValue(8, k)  # ROE
        salse_delta = inststmarketeye.GetDataValue(9, k)  # 매출액 증가율
        orprofit_delta = inststmarketeye.GetDataValue(10, k)  # 경상이익 증가율
        net_income_delta = inststmarketeye.GetDataValue(11, k)  # 순이익 증가율
        salse = inststmarketeye.GetDataValue(12, k) * 1000000  # 매출액 (백만)
        orprofit = inststmarketeye.GetDataValue(13, k)  # 경상이익
        net_income = inststmarketeye.GetDataValue(14, k)  # 당기순이익
        bps = inststmarketeye.GetDataValue(15, k)  # BPS
        income_delta = inststmarketeye.GetDataValue(16, k)  # 영업이익 증가율
        income = inststmarketeye.GetDataValue(17, k)  # 영업이익
        icr = inststmarketeye.GetDataValue(18, k)  # 이자보상비율
        day = inststmarketeye.GetDataValue(19, k)  # 결산년월

        stocknum_list.append(stocknum)
        per_list.append(per)
        eps_list.append(eps)
        capital_list.append(capital)
        parvalue_list.append(parvalue)
        allocation_list.append(allocation)
        lia_list.append(lia_ratio)
        reserveration_list.append(reserveration)
        roe_list.append(roe)
        salse_delta_list.append(salse_delta)
        orprofit_delta_list.append(orprofit_delta)
        net_income_delta_list.append(net_income_delta)
        salse_list.append(salse)
        orprofit_list.append(orprofit)
        net_income_list.append(net_income)
        bps_list.append(bps)
        income_delta_list.append(income_delta)
        income_list.append(income)
        icr_list.append(icr)
        day_list.append(day)

        b = b + 1
        print(str(b) + "/" + str(var))


dataFrame = pd.DataFrame({"총상장주식수": stocknum_list, "PER": per_list, "EPS": eps_list, "자본금": capital_list,
                          "액면가": parvalue_list, "배당률": allocation_list, "부채비율": lia_list, "유보율": reserveration_list,
                          "ROE": roe_list, "매출액증가율": salse_delta_list, "경상이익증가률": orprofit_delta_list,
                          "순이익증가률": net_income_delta_list, "매출액": salse_list, "경상이익": orprofit_list,
                          "당기순이익": net_income_list, "BPS": bps_list, "영업이익증가률": orprofit_delta_list,
                          "영업이익": income_list, "이자보상비율": icr_list, "결산년월": day_list}, com_code)

con = sqlite3.connect("E:\\Value\\사업보고서.db")
dataFrame.to_sql(date, con)

print("end")
