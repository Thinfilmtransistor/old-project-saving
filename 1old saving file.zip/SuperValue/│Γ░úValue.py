import win32com.client
import time
import pandas as pd
import sqlite3


con1 = sqlite3.connect("E:\Value\사업보고서.db")
df1 = pd.read_sql("SELECT * FROM Y2016", con1, index_col='index')

con2 = sqlite3.connect("E:\Value\시가총액.db")
df2 = pd.read_sql("SELECT * FROM Y2018M01", con2, index_col='index')

con3 = sqlite3.connect("E:\Value\가격.db")
df3 = pd.read_sql("SELECT * FROM Y2018M01D31", con3, index_col='index')



print(df3)


# dataFrame = pd.DataFrame({"PER": per_list, "PBR": pbr_list, "PSR": psr_list, "EPS": eps_list, "BPS": bps_list,
#                            "가격": price_list}, com_code)
#
#
#
# con = sqlite3.connect("E:\\Value\\사업보고서Value.db")
# dataFrame.to_sql('Y2016', con)
#
# print("end")
