import sqlite3
import pandas as pd

con = sqlite3.connect("E:\\Value\\시가총액.db")

# database의 table명 가져오기
curs = con.cursor()
table_list = []
curs.execute('select name from sqlite_master where type="table"')
qd = curs.fetchall()
for i in qd:
    table_list.append(i[0])
print(table_list[-1])
df = pd.read_sql("SELECT * FROM " + table_list[-1], con, index_col='index')
length = int(df.shape[0]*0.2)
target = df.sort_values(by=['시가총액'])[:length]

print("phase 1 done")

# -------------------------------------------

f1_1 = open("E:\\Database\\2017\\2017_3분기보고서_01_재무상태표_연결_20180131.txt", "r")
file1_1 = f1_1.readlines()[1:]

bs_code_list = []
for i in file1_1:
    temp = i.split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if code not in bs_code_list:
        bs_code_list.append(code)
f1_1.close()

f1_2 = open("E:\\Database\\2017\\2017_3분기보고서_01_재무상태표_20180131.txt", "r")
file1_2 = f1_2.readlines()[1:]

for i in file1_2:
    temp = i.split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if code not in bs_code_list:
        bs_code_list.append(code)
f1_2.close()



f2_1 = open("E:\\Database\\2017\\2017_3분기보고서_02_손익계산서_연결_20180131.txt", "r")
file2_1 = f2_1.readlines()[1:]

pl_code_list = []
for i in file2_1:
    temp = i.split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if code not in pl_code_list:
        pl_code_list.append(code)
f2_1.close()

f2_2 = open("E:\\Database\\2017\\2017_3분기보고서_03_포괄손익계산서_연결_20180131.txt", "r")
file2_2 = f2_2.readlines()[1:]

for i in file2_2:
    temp = i.split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if code not in pl_code_list:
        pl_code_list.append(code)
f2_2.close()

f3_1 = open("E:\\Database\\2017\\2017_3분기보고서_02_손익계산서_20180131.txt", "r")
file3_1 = f3_1.readlines()[1:]


for i in file3_1:
    temp = i.split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if code not in pl_code_list:
        pl_code_list.append(code)
f3_1.close()

f3_2 = open("E:\\Database\\2017\\2017_3분기보고서_03_포괄손익계산서_20180131.txt", "r")
file3_2 = f3_2.readlines()[1:]

for i in file3_2:
    temp = i.split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if code not in pl_code_list:
        pl_code_list.append(code)
f3_2.close()


f4_1 = open("E:\\Database\\2017\\2017_3분기보고서_04_현금흐름표_연결_20180131.txt", "r")
file4_1 = f4_1.readlines()[1:]

cf_code_list = []
for i in file4_1:
    temp = i.split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if code not in cf_code_list:
        cf_code_list.append(code)
f4_1.close()

f4_2 = open("E:\\Database\\2017\\2017_3분기보고서_04_현금흐름표_20180131.txt", "r")
file4_2 = f4_2.readlines()[1:]

for i in file4_2:
    temp = i.split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if code not in cf_code_list:
        cf_code_list.append(code)
f4_2.close()

print("phase2 done")
# ------------------------------------------
for i in target.index:
    if i not in bs_code_list:
        print(i)

print("phase 3 done")
# for i in target.index:
#
#     if i not in bs_code_list:
#         print(i, "재무상태표")
#     if i not in pl_code_list:
#         print(i, "손익계산서")
#     if i not in cf_code_list:
#         print(i, "현금흐름표")
# print("phase 3 done")