# CYBOS 현제가, 총상장주식수 가져오기

import pandas as pd
from datetime import datetime
import win32com.client
import time
import sqlite3

# 종목 가격 모듈
instStockChart = win32com.client.Dispatch("CpSysDib.StockChart")

now = datetime.now()
date = 'Y%sM%sD%s' % (now.year, now.month, now.day)

f = open("E:\\Value\\종목코드.txt", "r")
lines1 = f.readlines()[1:]

com_line = []
block = []
com_code = []
var = len(lines1)
a = 0
for i in lines1:
    temp = "A" + i.replace("\n", "")
    block.append(temp)
    com_code.append(temp)
    a = a + 1
    if a % 200 == 0:
        com_line.append(block)
        block = []
    elif a == var:
        com_line.append(block)
        block = []

b = 0

price_list = []
stocknum_list = []
maca_list = []

for j in com_line:
    inststmarketeye = win32com.client.Dispatch("CpSysDib.MarketEye")
    inststmarketeye.SetInputValue(0, (4, 20))
    inststmarketeye.SetInputValue(1, j)
    time.sleep(0.26)
    inststmarketeye.BlockRequest()
    numStock = inststmarketeye.GetHeaderValue(2)

    for k in range(numStock):
        price = inststmarketeye.GetDataValue(0, k)  # 현제가
        stocknum = inststmarketeye.GetDataValue(1, k)  # 총상장주식수
        market_capital = price * stocknum
        price_list.append(price)
        stocknum_list.append(stocknum)
        maca_list.append(market_capital)
        b = b + 1
        print(str(b) + "/" + str(var))

dataFrame = pd.DataFrame({"현제가": price_list, "총상장주식수": stocknum_list, "시가총액": maca_list}, com_code)
con = sqlite3.connect("E:\\Value\\시가총액.db")
dataFrame.to_sql(date, con)
print("end")

