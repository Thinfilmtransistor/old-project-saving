import win32com.client
import time
import pandas as pd
import sqlite3
import datetime


# 종목 list 만들기
f1 = open("E:\\Value\\20180504data\\상장법인목록.txt", "r")
line1 = f1.readlines()

list1 = []
for i in line1:
    temp = i.replace("\n", "")
    list1.append(temp)
f1.close()

f2 = open("E:\\Value\\20180504data\\관리종목.txt", "r")
line2 = f2.readlines()
for i in line2:
    temp = i.replace("\n", "")
    if temp in list1:
        list1.remove(temp)
f2.close()

f3 = open("E:\\Value\\20180504data\\불성실공시법인.txt", "r")
line3 = f3.readlines()
for i in line3:
    temp = i.replace("\n", "")
    if temp in list1:
        list1.remove(temp)
f3.close()

f4 = open("E:\\Value\\20180504data\\종목list.txt", "w")
for i in list1:
    f4.write("A" + i+",")
f4.close()

f5 = open("E:\\Value\\20180504data\\종목list.txt", "r")
codes = f5.read().split(",")[:-1]
f5.close()


# 시가총액 하위 20% 오름차순 list 만들기
con1 = sqlite3.connect("E:\\backtest\\주가.db")

macalist = []
for i in codes:
    df1 = pd.read_sql("SELECT 시가총액 FROM " + i, con1)
    macalist.append(int(df1.iloc[-1][0]))

df2 = pd.DataFrame({"시가총액": macalist}, codes)
df3 = df2.sort_values(by=['시가총액'], axis=0)[:int(df2.shape[0] * 0.2)]
for i in df3.index:
    print(i)







