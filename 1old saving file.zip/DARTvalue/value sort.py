import pandas as pd
import sqlite3

a = 0  # 시가총액 하위 20%적용시 a = 0 아닐시 a = 1
b = 0  # 강한조건시 0, 아닐시 1

con2 = sqlite3.connect("E:\\Value\\2017Q3.db")

# database의 table명 가져오기
curs = con2.cursor()
table_list = []
curs.execute('select name from sqlite_master where type="table"')
qd = curs.fetchall()

for i in qd:
    table_list.append(i[0])

if a == 0:
    df = pd.read_sql("SELECT * FROM 정리", con2, index_col='index')
    df1 = df.sort_values(by=['시가총액'], ascending=True)
    df2 = df1[:int(df.shape[0] * 0.2)]
elif a == 1:
    df2 = pd.read_sql("SELECT * FROM 정리", con2, index_col='index')

if b == 0:
    df3 = df2[(df2["분기매출액"] > 0) & (df2["분기매출액증가율"] > 0) & (df2["분기영업이익"] > 0) & (df2["분기영업이익증가율"] > 0) & (df2["분기부채비율"] < 50)]
elif a ==1:
    df3 = df2


code = []
per_list = []
pbr_list = []
psr_list = []
pcr_list = []

for i in df3.index:
    if df3.ix[i][4] == 0:
        per = 0
    else:
        per = df3.ix[i][13] / df3.ix[i][4]
    pbr = df3.ix[i][13] / df3.ix[i][17]
    psr = df3.ix[i][13] / df3.ix[i][18]
    pcr = df3.ix[i][13] / df3.ix[i][20]
    code.append(i)

    per_list.append(per)
    pbr_list.append(pbr)
    psr_list.append(psr)
    pcr_list.append(pcr)

df3 = pd.DataFrame({"PER": per_list, "PBR": pbr_list, "PSR": psr_list, "PCR": pcr_list}, code)
sourcedata = df3[(df3["PER"] > 0) & (df3["PBR"] > 0) & (df3["PSR"] > 0) & (df3["PCR"] > 0)]
# print(sourcedata["PBR"])
# print(sourcedata.sort_values(by=['PSR']))

per_rank = sourcedata['PER'].rank()  # per 오름차순 rank
pbr_rank = sourcedata['PBR'].rank()  # pbr 오름차순 rank
psr_rank = sourcedata['PSR'].rank()  # psr 오름차순 rank
pcr_rank = sourcedata['PCR'].rank()  # pcr 오름차순 rank

total_rank = (per_rank + pbr_rank + psr_rank + pcr_rank).rank()

result = pd.concat([per_rank, pbr_rank, psr_rank, pcr_rank, total_rank], axis=1)
result2 = result.sort_values(by=[0]).head(50)
for i in result2.index:
    print(i)
a = 0
for i in result2.index:
    a = a + 1
    print(a, "http://companyinfo.stock.naver.com/v1/company/c1010001.aspx?cmp_cd={0}&target=finsum_more".format(i.replace("A", "")))

