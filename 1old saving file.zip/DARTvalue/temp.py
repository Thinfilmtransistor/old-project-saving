import pandas as pd
import sqlite3

f5 = open("E:\\Value\\20180504data\\종목list.txt", "r")
codes = f5.read().split(",")[:-1]
f5.close()


# 시가총액 df 만들기
con1 = sqlite3.connect("E:\\backtest\\주가.db")
macalist = []
pricelist = []
a = 0
for i in codes:
    a = a + 1
    df1 = pd.read_sql("SELECT * FROM " + i, con1)
    print(a, "/", len(codes))
    macalist.append(int(df1["시가총액"][df1.shape[0]-1]))
    pricelist.append((df1["종가"][df1.shape[0]-1]))
df2 = pd.DataFrame({"시가총액": macalist, "종가": pricelist}, codes)


con2 = sqlite3.connect("E:\\Value\\사업보고서.db")

# database의 table명 가져오기
curs = con2.cursor()
table_list = []
curs.execute('select name from sqlite_master where type="table"')
qd = curs.fetchall()
for i in qd:
    table_list.append(i[0])

df3 = pd.read_sql("SELECT * FROM " + table_list[-1], con2, index_col='index')
df4 = pd.concat([df2, df3], axis=1)

# 결산년월 201712, 시가총액 오름차순정렬 상위 20% df
df5 = df4[(df4["결산년월"] == 201712) & (df4["영업이익"] > 0)].sort_values(by=['시가총액'], axis=0)[:int(df2.shape[0] * 0.2)]

# print(df5.head(50))

code = []
per_list = []
pbr_list = []
psr_list = []
pcr_list = []

for i in df5.index:
    if df5.ix[i][4] == 0:
        per = 0
    else:
        per = df5.ix[i][4]
    pbr = df5.ix[i][1] / df5.ix[i][2]
    psr = df5.ix[i][1] / df5.ix[i][10]

    code.append(i)

    per_list.append(per)
    pbr_list.append(pbr)
    psr_list.append(psr)

df6 = pd.DataFrame({"PER": per_list, "PBR": pbr_list, "PSR": psr_list}, code)
sourcedata = df6[(df6["PER"] > 0) & (df6["PBR"] > 0) & (df6["PSR"] > 0)]


per_rank = sourcedata['PER'].rank()  # per 오름차순 rank
pbr_rank = sourcedata['PBR'].rank()  # pbr 오름차순 rank
psr_rank = sourcedata['PSR'].rank()  # psr 오름차순 rank

total_rank = (per_rank + pbr_rank + psr_rank).rank()

result = pd.concat([per_rank, pbr_rank, psr_rank, total_rank], axis=1)
result2 = result.sort_values(by=[0]).head(50)
print(result2)
for i in result2.index:
    print(i)
a = 0
for i in result2.index:
    a = a + 1
    print(a, "http://companyinfo.stock.naver.com/v1/company/c1010001.aspx?cmp_cd={0}&target=finsum_more".format(i.replace("A", "")))


