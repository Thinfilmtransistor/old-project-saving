import  sqlite3
import pandas as pd


con = sqlite3.connect("E:\\Value\\2017Q3.db")

exchange1 = 1146.50  # KRW/USD
exchange2 = 172.64  # KRW/CNY

b = 0  # 자본총계, 매출액, 영업으로 인한 현금흐름 status


def data_insert():
    if b == 1:
        BS_right.append(code)
        if temp[9] == "USD":
            equity_list.append(int(temp[12].replace(",", "")) * exchange1)
        elif temp[9] == "CNY":
            equity_list.append(int(temp[12].replace(",", "")) * exchange2)
        else:
            equity_list.append(int(temp[12].replace(",", "")))
    elif b == 2:
        PL_right.append(code)
        if temp[9] == "USD":
            revenue_list.append(int(temp[12].replace(",", "")) * exchange1)
            accrevenue_list.append(int(temp[13].replace(",", "")) * exchange1)
        elif temp[9] == "CNY":
            revenue_list.append(int(temp[12].replace(",", "")) * exchange2)
            accrevenue_list.append(int(temp[13].replace(",", "")) * exchange2)
        else:
            revenue_list.append(int(temp[12].replace(",", "")))
            accrevenue_list.append(int(temp[13].replace(",", "")))
    elif b == 3:
        CF_right.append(code)
        if temp[9] == "USD":
            cash_list.append(int(temp[12].replace(",", "")) * exchange1)
        elif temp[9] == "CNY":
            cash_list.append(int(temp[12].replace(",", "")) * exchange2)
        else:
            cash_list.append(int(temp[12].replace(",", "")))




# 자본총계 추출
BS_2017 = open("E:\\Database\\2017\\2017_3분기보고서_01_재무상태표_연결_20180131.txt", "r")
BS_line = BS_2017.readlines()[1:]
BS_right = []
b = b + 1

equity_list = []
for i in BS_line:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if temp[10] == "ifrs_Equity" and temp[12] != "":
        data_insert()
    elif temp[1] == "[028050]" or temp[1] == "[225330]" or temp[1] == "[036000]" or temp[1] == "[020000]":
        if temp[11] == "자본총계":
            data_insert()

df1 = pd.DataFrame({"자본총계": equity_list}, BS_right)

# -----------------------------------------------------------------------------------------------------------

# 매출액 추출
PL_2017 = open("E:\\Database\\2017\\2017_3분기보고서_02_손익계산서_연결_20180131.txt", "r")
PL_lines1 = PL_2017.readlines()[1:]
PL_2017.close()
PL_right = []
b = b + 1

code_list = []
ncompre_code = []
revenue_list = []
accrevenue_list = []
for i in PL_lines1:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if code not in code_list:
        ncompre_code.append(code)
        code_list.append(code)

    if temp[10] == "ifrs_Revenue" and temp[12] != "":
        data_insert()

    elif temp[1] == "[089600]" or temp[1] == "[053210]":
        if temp[11] == "영업수익":
            data_insert()

PL_2017 = open("E:\\Database\\2017\\2017_3분기보고서_03_포괄손익계산서_연결_20180131.txt", "r")
PL_lines2 = PL_2017.readlines()[1:]
PL_2017.close()

for i in PL_lines2:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if code in ncompre_code:
        pass
    else:
        if code not in code_list:
            code_list.append(code)

        if temp[10] == "ifrs_Revenue" and temp[12] != "":
            data_insert()

        elif temp[1] == "[009440]" or temp[1] == "[034310]" or temp[1] == "[003090]" or temp[1] == "[192080]" or temp[1] == "[194480]" or temp[1] == "[016170]" or temp[1] == "[140410]":
            if temp[11] == "영업수익":
                data_insert()
        elif temp[1] == "[080160]":
            if temp[11] == "수익":
                data_insert()
        elif temp[1] == "[207760]" or temp[1] == "[155900]" or temp[1] == "[225330]":
            if temp[11] == "영업수익":
                data_insert()
        elif temp[1] == "[085810]":
            if temp[11] == "영업수익(매출액)":
                data_insert()
        elif temp[1] == "[067920]":
            if temp[11] == "영업수익":
                data_insert()
        elif temp[1] == "[041020]":
            if temp[11] == "영업수익(매출액)":
                data_insert()
        elif temp[1] == "[067000]" or temp[1] == "[035720]" or temp[1] == "[194510]" or temp[1] == "[172580]":
            if temp[11] == "영업수익":
                data_insert()
        elif temp[1] == "[039340]":
            if temp[11] == "매출총이익":
                data_insert()
        elif temp[1] == "[041460]":
            if temp[11] == "Ⅰ. 영업수익":
                data_insert()

df2 = pd.DataFrame({"매출액(당기)": revenue_list, "매출액(누적)": accrevenue_list}, PL_right)


# -------------------------------------------------------------------------------------


# 영업으로인한 현금흐름 추출
CF_2017 = open("E:\\Database\\2017\\2017_3분기보고서_04_현금흐름표_연결_20180131.txt", "r")
CF_lines = CF_2017.readlines()[1:]
CF_right = []
b = b + 1


cash_list = []
for i in CF_lines:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "A").replace("]", "")

    if temp[10] == "ifrs_CashFlowsFromUsedInOperatingActivities" and temp[12] != "":
        data_insert()

    elif temp[1] == "[900290]" and temp[11] == "   영업활동으로 인한 순현금흐름":
        data_insert()
    elif temp[1] == "[049770]" and temp[11] == "영업활동으로인한 순 현금흐름":
        data_insert()
    elif temp[1] == "[006040]" and temp[10] == "ifrs_CashFlowsFromUsedInOperatingActivities":
        CF_right.append(code)
        cash_list.append(170306877426)
    elif temp[1] == "[009150]" and temp[11] == "영업활동으로 인한 순현금흐름":
        data_insert()
    elif temp[1] == "[036810]" and temp[11] == "영업으로부터의 순현금유입":
        data_insert()
    elif temp[1] == "[900300]" and temp[11] == "   영업활동으로 인한 순현금흐름액":
        data_insert()
    elif temp[1] == "[900180]" and temp[11] == "   영업활동으로 인한 현금흐름":
        data_insert()
    elif temp[1] == "[139480]" and temp[11] == "영업활동으로부터의 순현금유입":
        data_insert()
    elif temp[1] == "[141020]" and temp[10] == "ifrs_CashFlowsFromUsedInOperatingActivities":
        CF_right.append(code)
        cash_list.append(153254436130)
    elif temp[1] == "[086280]" and temp[11] == "   영업활동으로 인한 순현금흐름":
        data_insert()
    elif temp[1] == "[048410]" and temp[11] == "영업활동으로 인한 순현금흐름":
        data_insert()

    elif temp[1] == "[151910]" and temp[11] == "영업활동으로 인한 현금흐름":
        data_insert()
    elif temp[1] == "[095910]" and temp[11] == "영업활동으로 인한 현금흐름":
        data_insert()
    elif temp[1] == "[103140]" and temp[11] == "영업활동순현금흐름":
        data_insert()
    elif temp[1] == "[041460]" and temp[11] == "Ⅰ.영업활동 현금흐름":
        data_insert()

df3 = pd.DataFrame({"영업활동으로인한_현금흐름": cash_list}, CF_right)

df_13_axis1 = pd.concat([df1, df2, df3], axis=1)
print(df_13_axis1)

df_13_axis1.to_sql("Y2017Q3", con, if_exists='append')
