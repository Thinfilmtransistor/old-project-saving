import pandas as pd

# 매출액 추출
PL_2017 = open("E:\\Database\\2017\\2017_3분기보고서_02_손익계산서_연결_20180131.txt", "r")
lines1 = PL_2017.readlines()[1:]
PL_2017.close()
right = []

exchange1 = 1146.50  # KRW/USD
exchange2 = 172.64  # KRW/CNY

def data_insert():
    right.append(code)
    if temp[9] == "USD":
        target_list.append(int(temp[12].replace(",", "")) * exchange1)
        acctarget_list.append(int(temp[13].replace(",", "")) * exchange1)
    elif temp[9] == "CNY":
        target_list.append(int(temp[12].replace(",", "")) * exchange2)
        acctarget_list.append(int(temp[13].replace(",", "")) * exchange2)
    else:
        target_list.append(int(temp[12].replace(",", "")))
        acctarget_list.append(int(temp[13].replace(",", "")))


a = 0
code_list = []
ncompre_code = []
target_list = []
acctarget_list = []
for i in lines1:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if code not in code_list:
        ncompre_code.append(code)
        code_list.append(code)
    a = a + 1
    print(a, "/", len(lines1))

    if temp[10] == "ifrs_Revenue" and temp[12] != "":
        data_insert()

    elif temp[1] == "[089600]" or temp[1] == "[053210]":
        if temp[11] == "영업수익":
            data_insert()

PL_2017 = open("E:\\Database\\2017\\2017_3분기보고서_03_포괄손익계산서_연결_20180131.txt", "r")
lines2 = PL_2017.readlines()[1:]
PL_2017.close()

a = 0
for i in lines2:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if code in ncompre_code:
        pass
    else:
        if code not in code_list:
            code_list.append(code)
        a = a + 1
        print(a, "/", len(lines2))

        if temp[10] == "ifrs_Revenue" and temp[12] != "":
            data_insert()

        elif temp[1] == "[009440]" or temp[1] == "[034310]" or temp[1] == "[003090]" or temp[1] == "[192080]" or temp[1] == "[194480]" or temp[1] == "[016170]" or temp[1] == "[140410]":
            if temp[11] == "영업수익":
                data_insert()
        elif temp[1] == "[080160]":
            if temp[11] == "수익":
                data_insert()
        elif temp[1] == "[207760]" or temp[1] == "[155900]" or temp[1] == "[225330]":
            if temp[11] == "영업수익":
                data_insert()
        elif temp[1] == "[085810]":
            if temp[11] == "영업수익(매출액)":
                data_insert()
        elif temp[1] == "[067920]":
            if temp[11] == "영업수익":
                data_insert()
        elif temp[1] == "[041020]":
            if temp[11] == "영업수익(매출액)":
                data_insert()
        elif temp[1] == "[067000]" or temp[1] == "[035720]" or temp[1] == "[194510]" or temp[1] == "[172580]":
            if temp[11] == "영업수익":
                data_insert()
        elif temp[1] == "[039340]":
            if temp[11] == "매출총이익":
                data_insert()
        elif temp[1] == "[041460]":
            if temp[11] == "Ⅰ. 영업수익":
                data_insert()

df = pd.DataFrame({"매출액(당기)": target_list, "매출액(누적)": acctarget_list}, right)

print(df)