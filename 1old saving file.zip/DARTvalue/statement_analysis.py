path1 = "E:\\Database\\2017\\2017_3분기보고서_03_포괄손익계산서_연결_20180131.txt"

codename = "ifrs_Revenue"

file1 = open(path1, "r")
lines1 = file1.readlines()[1:]

# 종목수 확인
def stocknum():
    print("종목수 확인")
    code_list = []
    link_code = []
    for i in lines1:
        temp = i.replace("\n", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if code not in code_list:
            code_list.append(code)
            link_code.append(code)
    print("연결", len(code_list))

# 통화종류 확인
def curruncy_type():
    print("화폐종류")
    link_code_list = []
    link_day = []
    link_cur_type = []

    for i in lines1:
        temp = i.replace("\n", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if temp[9] != "KRW":
            if code not in link_code_list:
                link_code_list.append(code)
                link_day.append(temp[7])
                link_cur_type.append(temp[9])
    print("연결")
    for i in range(len(link_code_list)):
        print(link_code_list[i], link_day[i], link_cur_type[i])


# codename 값이 비어있는 line 확인
def check1():
    print("코드명이 '" + codename + "'이지만 값이 비어있는 line")
    for i in lines1:
        temp = i.replace("\n", "").replace(",", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if temp[10] == codename and temp[12] == "":
            print(code)


# codename 사용하지 않는 종목 확인
def check2():
    print("'" + codename + "'를 사용하지 않는 종목")
    com_line = []
    right = []
    for i in lines1:
        temp = i.replace("\n", "").replace(",", "").split("\t")
        code = temp[1].replace("[", "").replace("]", "")
        if code not in com_line:
            com_line.append(code)
        if temp[10] == codename:
            right.append(code)
    for i in com_line:
        if i not in right:
            print(i)


# 예외 항목 유무 검사
def check3():
    # 자본총계 추출
    PL_2017 = open("E:\\Database\\2017\\2017_3분기보고서_01_재무상태표_연결_20180131.txt", "r")
    file = PL_2017.readlines()[1:]

    right = []

    exchange1 = 1146.50  # KRW/USD
    exchange2 = 172.64  # KRW/CNY

    def data_insert():
        right.append(code)

    a = 0
    code_list = []
    equity_list = []
    for i in file:
        temp = i.replace("\n", "").replace(",", "").split("\t")
        code = temp[1].replace("[", "A").replace("]", "")
        if code not in code_list:
            code_list.append(code)
        a = a + 1
        print(a, "/", len(file))

        if temp[10] == "ifrs_Equity" and temp[12] != "":
            data_insert()

        elif temp[1] == "[028050]" or temp[1] == "[225330]" or temp[1] == "[036000]" or temp[1] == "[020000]":
            if temp[11] == "자본총계":
                data_insert()


    print(len(code_list))
    print(len(right))
    for i in code_list:
        if i not in right:
            print(i)

    if len(right) > len(code_list):
        for i in range(len(right) - 1):
            if right[i] == right[i + 1]:
                print(right[i])
                print("140890은 트러스제7호로 3개월마다 사업보고서와 반기보고서를 교대로 제출하고 있다.")

stocknum()
curruncy_type()
check1()
check2()
# check3()