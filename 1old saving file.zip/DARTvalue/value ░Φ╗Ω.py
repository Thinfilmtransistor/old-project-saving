import  pandas as pd
import sqlite3

con1 = sqlite3.connect("E:\\Value\\cybos.db")

# database의 table명 가져오기
curs = con1.cursor()
table_list = []
curs.execute('select name from sqlite_master where type="table"')
qd = curs.fetchall()

for i in qd:
    table_list.append(i[0])


df1 = pd.read_sql("SELECT * FROM " + table_list[-1], con1, index_col='index')
# print(df1)



con2 = sqlite3.connect("E:\\Value\\2017Q3.db")

# database의 table명 가져오기
curs = con2.cursor()
table_list = []
curs.execute('select name from sqlite_master where type="table"')
qd = curs.fetchall()

for i in qd:
    table_list.append(i[0])


df2 = pd.read_sql("SELECT * FROM " + table_list[-1], con2, index_col='index')
# print(df2)

df_13_axis1 = pd.concat([df1, df2['분기당기순이익']], axis=1)
# print(df_13_axis1)

source = df_13_axis1.dropna(axis=0)

source.to_sql("정리", con2, if_exists='append')