import pandas as pd

# 자본총계 추출
PL_2017 = open("E:\\Database\\2017\\2017_3분기보고서_04_현금흐름표_연결_20180131.txt", "r")
file = PL_2017.readlines()[1:]

right = []

exchange1 = 1146.50  # KRW/USD
exchange2 = 172.64  # KRW/CNY

def data_insert():
    right.append(code)
    if temp[9] == "USD":
        target_list.append(int(temp[12].replace(",", "")) * exchange1)
    elif temp[9] == "CNY":
        target_list.append(int(temp[12].replace(",", "")) * exchange2)
    else:
        target_list.append(int(temp[12].replace(",", "")))


a = 0
code_list = []
target_list = []
for i in file:
    temp = i.replace("\n", "").replace(",", "").split("\t")
    code = temp[1].replace("[", "A").replace("]", "")
    if code not in code_list:
        code_list.append(code)
    a = a + 1
    print(a, "/", len(file))

    if temp[10] == "ifrs_CashFlowsFromUsedInOperatingActivities" and temp[12] != "":
        data_insert()

    elif temp[1] == "[900290]" and temp[11] == "   영업활동으로 인한 순현금흐름":
        data_insert()
    elif temp[1] == "[049770]" and temp[11] == "영업활동으로인한 순 현금흐름":
        data_insert()
    elif temp[1] == "[006040]" and temp[10] == "ifrs_CashFlowsFromUsedInOperatingActivities":
        right.append(code)
        target_list.append(170306877426)
    elif temp[1] == "[009150]" and temp[11] == "영업활동으로 인한 순현금흐름":
        data_insert()
    elif temp[1] == "[036810]" and temp[11] == "영업으로부터의 순현금유입":
        data_insert()
    elif temp[1] == "[900300]" and temp[11] == "   영업활동으로 인한 순현금흐름액":
        data_insert()
    elif temp[1] == "[900180]" and temp[11] == "   영업활동으로 인한 현금흐름":
        data_insert()
    elif temp[1] == "[139480]" and temp[11] == "영업활동으로부터의 순현금유입":
        data_insert()
    elif temp[1] == "[141020]" and temp[10] == "ifrs_CashFlowsFromUsedInOperatingActivities":
        right.append(code)
        target_list.append(153254436130)
    elif temp[1] == "[086280]" and temp[11] == "   영업활동으로 인한 순현금흐름":
        data_insert()
    elif temp[1] == "[048410]" and temp[11] == "영업활동으로 인한 순현금흐름":
        data_insert()

    elif temp[1] == "[151910]" and temp[11] == "영업활동으로 인한 현금흐름":
        data_insert()
    elif temp[1] == "[095910]" and temp[11] == "영업활동으로 인한 현금흐름":
        data_insert()
    elif temp[1] == "[103140]" and temp[11] == "영업활동순현금흐름":
        data_insert()
    elif temp[1] == "[041460]" and temp[11] == "Ⅰ.영업활동 현금흐름":
        data_insert()


print(len(code_list))
print(len(right))
for i in code_list:
    if i not in right:
        print(i)

if len(right) > len(code_list):
    for i in range(len(right) - 1):
        if right[i] == right[i + 1]:
            print(right[i])
            print("140890은 트러스제7호로 3개월마다 사업보고서와 반기보고서를 교대로 제출하고 있다.")
df = pd.DataFrame({"영업활동으로인한 현금흐름": target_list}, right)

print(df)