import win32com.client

excel = win32com.client.Dispatch("Excel.Application")
excel.Visible = True
wb = excel.Workbooks.Open('e:\\test.xlsx')
ws = wb.Worksheets("Open")


print(ws.Cells(1, 1).Value)
excel.Quit()