import glob
import os.path
import temp2

"""
files = glob.glob('E:\\연습용\\*.xls')  # 특정확장자를 가진 목록뽑기
print(files)

for x in files:
    if not os.path.isdir(x):  # 파일만 걸러내기
        filename = os.path.split(x)  # 확장자와 순수파일명 구분하기
        fl_nm = filename[1].replace(".xls","")
        print(filename)
        # print(fl_nm)  # 확인 주석
        os.rename(x, filename[0] + fl_nm + '.xlsx')  # 순수파일명에 xlsx확장자 붙이기

"""




files = glob.glob('E:\\연습용\\*.xls')  # 특정확장자를 가진 목록뽑기
for x in files[:1]:
    if not os.path.isdir(x):  # 파일만 걸러내기
        print(temp2.reg_data(x))
