import pandas as pd
import re


# ================================================재무상태표

def bal_st(var1):
    p7 = re.compile(r"\s*[I.]*유동자산|\s*자산총계|\s*부채총계|\s*자본총계")
    for po1 in range(len(data[var1])):
        m7 = p7.match(data[var1].iat[po1, 0])
        if m7:
            print(data[var1].iloc[po1, :])

# =================================================손익계산서


def inc_st(var2):
    e = 0
    p7 = re.compile(r"영업수익|[Ⅰ.]*수익.*|[ⅠI.]*매출[액]*[^원가]|매출$|[ⅤIV.]*영업이익[(손실)]*|I. 매출액|III. 매출총이익|V. 영업이익[(]손실[)]|Ⅶ.영업이익")
    p8 = re.compile(r"[ⅢIII.]*매출총이익|[XⅡXⅢVI.]*당기순이익[^귀속]*|분기순이익[(손실)]*")
    print(data[var2].iat[0, 0])
    print(data[var2].iloc[0, :])
    for po1 in range(len(data[var2])):
        det = data[var2].iat[po1, 0] == data[var2].iat[po1, 0]
        if det:
            m7 = p7.match(data[var2].iat[po1, 0])
            m8 = p8.fullmatch(data[var2].iat[po1, 0])
            if m7 or m8:
                e = e + 1
                # print(data[var2].iloc[po1, :])
    if e != 4:
        print(e)
        input("press enter to process")

# ================================================= 현금흐름표


def st_cf(var3):
    # print(data[sheet_name[4]])
    p9 = re.compile("영업활동현금흐름|투자활동현금흐름|재무활동현금흐름")
    for po1 in range(len(data[var3])):
        m9 = p9.match(data[var3].iat[po1, 0])
        if m9:
            print(data[var3].iloc[po1, :])
# ===================================================


kospi_list = pd.read_excel('E:\\유가증권목록.xlsx')

p1 = re.compile("보고서")
p2 = re.compile("법인명")
p3 = re.compile('통화')
p4 = re.compile('단위')


data = pd.read_excel('E:\\연습용\\20180214000552_ko.xls', sheet_name=None)
sheet_name = [i for i in data]
if len(sheet_name) > 11:
    sheet_name = sheet_name[:11]
print(sheet_name)

df = data[sheet_name[0]]
clm_nm = data[sheet_name[0]].columns[0]

for i in df[clm_nm]:
    if i == i:
        m1 = p1.search(i)
        if m1:
            doc_type = i.replace("보고서 유형 : ", "")
            # print(doc_type)
        m2 = p2.search(i)
        if m2:
            crp_name = i.replace("법인명 : ", "").replace("주식회사", "").replace("(주)", "").replace(" ", "").replace("자기관리부동산투자회사","리츠")
            print(crp_name)
            if crp_name == "와이지플러스":
                crp_name = "YG PLUS"
            if crp_name == "디에스알제강":
                crp_name = "DSR제강"
            crp_data = kospi_list[kospi_list['회사명'] == crp_name]
            crp_code = str(crp_data.iat[0, 1]).rjust(6, "0")

                # print(crp_name, crp_code)
        m3 = p3.search(i)
        if m3:
            cash_code = i.replace("통화ISO코드 : ", "")
            # print(cash_code)
        m4 = p4.search(i)
        if m4:
            unit = i.replace("단위정보(주석제외) : ", "")
            # print(unit)

p5 = re.compile("자본")
p6 = re.compile('손익')


for j in range(1, len(sheet_name)):
    m5 = p5.search(sheet_name[j])
    m6 = p6.search(sheet_name[j])
    if m5:
        pass
    elif m6:
        df1 = data[sheet_name[j]]
        clm_nm1 = data[sheet_name[j]].columns[0]
        a = 0
        for k in df1[clm_nm1]:
            m4 = p4.search(k)
            if m4:
                break
            a = a + 1
        df = pd.DataFrame(data[sheet_name[j]][a + 3:])
        new_list = list(data[sheet_name[j]].iloc[a + 1])
        new_list[0] = df.columns[0]
        b = -1
        for i in new_list:
            b = b + 1
            if i != i:
                # print(i)
                new_list[b] = new_list[b - 1].replace(new_list[b - 1][-3:], "누적")
                # print(new_list[b])
        df = df.reset_index(drop=True)
        df.columns = new_list
        data[sheet_name[j]] = df

    else:
        df1 = data[sheet_name[j]]
        clm_nm1 = data[sheet_name[j]].columns[0]
        a = 0
        for k in df1[clm_nm1]:
            m4 = p4.search(k)
            if m4:
                break
            a = a + 1

        df = pd.DataFrame(data[sheet_name[j]][a + 2:])
        new_list = list(data[sheet_name[j]].iloc[a + 1])
        new_list.remove(" ")
        new_list.insert(0, df.columns[0])
        df = df.reset_index(drop=True)
        df.columns = new_list
        data[sheet_name[j]] = df


"""
p10 = re.compile("재무")
for i in sheet_name[1:]:
    m10 = p10.search(i)
    if m10:
        bal_st(i)
"""

item1 = 0
item2 = 0
item3 = 0
item4 = 0
for i in sheet_name:
    if "연결" in i:
        if "포괄손익" in i:
            item2 = i
        elif "손익" in i:
            item1 = i
    else:
        if "포괄손익" in i:
            item4 = i
        elif "손익" in i:
            item3 = i


if item1 != 0:
    inc_st(item1)
elif item2 != 0:
    inc_st(item2)
if item3 != 0:
    inc_st(item3)
elif item4 != 0:
    inc_st(item4)

"""
p12 = re.compile("현금")
for i in sheet_name:
    m12 = p12.search(i)
    if m12:
        st_cf(i)
"""
