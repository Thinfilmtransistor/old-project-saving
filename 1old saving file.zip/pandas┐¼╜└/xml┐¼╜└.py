import openpyxl
import pandas as pd
import re
import numpy

kospi_list = pd.read_excel('E:\\유가증권목록.xlsx')

p1 = re.compile("연결")
p2 = re.compile("법인명")


excel_document = openpyxl.load_workbook('E:\\20180515001488_ko.xlsx')
sheet_name = excel_document.get_sheet_names()
sheet = excel_document.get_sheet_by_name(sheet_name[0])

data = pd.read_excel('E:\\20180515001488_ko.xlsx', sheet_name=sheet_name)

# link = {}
# idpt = {}
# 연결 sheet name
# a = 1
# for i in sheet_name[1:]:
#     m1 = p1.search(i)
#     if m1:
#         link[i] = a
#     else:
#         idpt[i] = a

    # a = a + 1
# print(type(data[sheet_name[1]]))
# print(link)
# print(idpt)

df = data[sheet_name[0]]
clm_nm = data[sheet_name[0]].columns[0]

for i in df[clm_nm]:
    if i == i:
        m2 = p2.search(i)
        if m2:
            crp_name = i.replace("법인명 : ", "").replace("주식회사", "").replace("(주)", "")
            crp_data = kospi_list[kospi_list['회사명'] == crp_name]
            crp_code = str(crp_data.iat[0, 1]).rjust(6, "0")
            print(crp_name, crp_code)


# ================================================재무상태표
def bal_st(var1):
    p3 = re.compile("\s*유동자산")
    p4 = re.compile("자산총계")
    p5 = re.compile("부채총계")
    p6 = re.compile("\s*자본총계")

    for po1 in range(len(data[var1])):
        m3 = p3.match(data[var1].iat[po1, 0])
        m4 = p4.search(data[var1].iat[po1, 0])
        m5 = p5.search(data[var1].iat[po1, 0])
        m6 = p6.match(data[var1].iat[po1, 0])
        if (m3 or m4 or m5 or m6):
            print(data[var1].iloc[po1, :])


# =================================================손익계산서
def inc_st(var2):
    p7 = re.compile("매출액")
    p8 = re.compile("매출총이익")
    p9 = re.compile("영업이익")
    p10 = re.compile("당기순이익[^귀속]*")
    p11 = re.compile("\s*지배지주 지분순이익")

    for i in range(len(data[var2])):
        det = data[var2].iat[i, 0] == data[var2].iat[i, 0]

        if det:
            m7 = p7.match(data[var2].iat[i, 0])
            m8 = p8.match(data[var2].iat[i, 0])
            m9 = p9.match(data[var2].iat[i, 0])
            m10 = p10.fullmatch(data[var2].iat[i, 0])
            m11 = p11.match(data[var2].iat[i, 0])
            if (m7 or m8 or m9 or m10 or m11):
                print(data[var2].iloc[i, :])

# ================================================= 현금흐름표

def st_cf(var3):
    # print(data[sheet_name[4]])
    p12 = re.compile("영업활동현금흐름")
    p13 = re.compile("영업활동으로인한")
    p14 = re.compile("투자활동현금흐름")
    p15 = re.compile("재무활동현금흐름")

    for i in range(len(data[var3])):
        m12 = p12.match(data[var3].iat[i, 0])
        m13 = p13.search(data[var3].iat[i, 0])
        m14 = p14.match(data[var3].iat[i, 0])
        m15 = p15.fullmatch(data[var3].iat[i, 0])

        if (m12 or m13 or m14 or m15):
            print(data[var3].iloc[i, :])
# ===================================================


p16 = re.compile("재무")
for i in sheet_name[1:]:
    m16 = p16.search(i)
    if m16:
        bal_st(i)

p17 = re.compile("손익")
for i in sheet_name:
    m17 = p17.search(i)
    if m17:
        inc_st(i)


p18 = re.compile("현금")
for i in sheet_name:
    m18 = p18.search(i)
    if m18:
        st_cf(i)

