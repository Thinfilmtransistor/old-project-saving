import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

dates = pd.date_range('20130101', periods=6)
"""
df = pd.DataFrame(np.random.rand(6,4), index=dates, columns=list('ABCD'))


df2 = pd.DataFrame({'A' : 1.,
                    'B' : pd.Timestamp('20130102'),
                    'C' : pd.Series(1, index=list(range(4)),dtype='float32'),
                    'D' : np.array([3]*4,dtype='int32'),
                    'E' : pd.Categorical(["test", "train", "test", "train"]),
                    "F" : 'foo'})


df2['E'] = ['one','one','two','three','four','three']
# print(df2)
# print(df2[df2['E'].isin(['two','four'])])

s1 = pd.Series([1,2,3,4,5,6], index=pd.date_range('20130102', periods=6))
# print(s1)
df['F'] = s1
df.at[dates[0],'A'] = 0
df.iat[0,1] = 0
df.loc[:,'D'] = np.array([5] * len(df))
print(df)
print(len(df))
print(df.shape)

df2 = df.copy()
df2[df2 > 0] = -df2
print(df2)


df1 = df.reindex(index=dates[0:4], columns=list(df.columns) + ['E'])
df1.loc[dates[0]:dates[1], 'E'] = 1

s = pd.Series(['A','B','C','Aaba','Baca',np.nan,'CABA','dog','cat'])
s1 = pd.Series([1,3,5,np,6,8], index=dates)


print(df)
pieces = [df[:3], df[3:7], df[7:]]
# print(pieces)
print(pd.concat(pieces))

df = pd.DataFrame(np.random.randn(8,4), columns=['A','B','C','D'])
s = df.iloc[3]
# left = pd.DataFrame({'key':['foo','bar'], 'lval': [1,2]})
# right = pd.DataFrame({'key':['foo','bar'], 'rval': [4,5]})

print(df)
print(df.append(s, ignore_index=True))
# print(s)
# print(right)
# print(pd.merge(left, right, on='key'))

# print(df.apply(lambda x: x.max() - x.min()))

df = pd.DataFrame({'A' : ['foo', 'bar', 'foo', 'bar',
                          'foo', 'bar', 'foo', 'foo'],
                   'B' : ['one', 'one', 'two', 'tree',
                          'two', 'two', 'one', 'three'],
                   'C': np.random.randn(8),
                   'D': np.random.randn(8)})
# print(df)
# print(df.groupby('A').sum())

tuples = list(zip(*[['bar', 'bar', 'baz', 'baz',
                     'foo', 'foo', 'qux', 'qux'],
                    ['one', 'two', 'one', 'two',
                     'one', 'two', 'one', 'two']]))
index = pd.MultiIndex.from_tuples(tuples, names=['first', 'second'])
df = pd.DataFrame(np.random.randn(8,2), index=index, columns=['A', 'B'])
df2 = df[:4]
print(df2)
print(df2.stack())
print(df2.stack().unstack(2))

df = pd.DataFrame({'A' : ['one', 'one', 'two', 'three'] * 3,
                   'B' : ['A', 'B', 'C'] * 4,
                   'C' : ['foo', 'foo', 'foo', 'bar', 'bar', 'bar'] * 2,
                   'D' : np.random.randn(12),
                   'E' : np.random.randn(12)})
print(df.pivot_table(df, values='D', index=['A', 'B'], columns=['C']))
"""

ts = pd.Series(np.random.randn(1000), index=pd.date_range('1/1/2000', periods=1000))
print(ts.cumsum())
ts.plot()
plt.figure()