import pandas as pd
import re
import glob
import os.path

# ================================================재무상태표

def bal_st(var1):
    p7 = re.compile(r"\s*[I.]*유동자산|\s*자산총계|\s*부채총계|\s*자본총계")
    for po1 in range(len(data[var1])):
        m7 = p7.match(data[var1].iat[po1, 0])
        if m7:
            print(data[var1].iloc[po1, :])


# =================================================손익계산서
# 002070의 경우 지배기업의 소유주 지분 문장이 당기순이익과 당기 총포괄이익이 서로 같아서 구별할 방도를 모르겠다.
# 따라서 지배지분은 일단 무시하도록 하자

def inc_st(var2):
    e = 0
    p7 = re.compile(r"영업수익|[Ⅰ.]*수익.*|")
    p8 = re.compile(r"[ⅠI.]*매출[액]*[^원가]|매출$|I. 매출액|매출액")
    p9 = re.compile(r"III. 매출총이익|Ⅲ.매출총이익|[ⅢIII.]*매출총이익|")
    p10 = re.compile(r"[ⅤIV.]*영업이익[(손실)]*||V. 영업이익[(]손실[)]|Ⅶ.영업이익")
    p11 = re.compile(r"[XⅡXⅢVI.]*당기순이익[^귀속]*|분기순이익[(손실)]*|Ⅸ.당기순이익[(]손실[)]|XI.당1분기순이익")
    for po1 in range(len(data[var2])):
        det = data[var2].iat[po1, 0] == data[var2].iat[po1, 0]
        m7 = p7.fullmatch(data[var2].iat[po1, 0])
        m8 = p8.match(data[var2].iat[po1, 0])
        m9 = p9.fullmatch(data[var2].iat[po1, 0])
        m10 = p10.fullmatch(data[var2].iat[po1, 0])
        m11 = p11.fullmatch(data[var2].iat[po1, 0])
        if m7:
            e = e + 1
            print(data[var2].iloc[po1, :])
        if m8:
            e = e + 1
            print(data[var2].iloc[po1, :])
        if m9:
            e = e + 1
            print(data[var2].iloc[po1, :])
        if m10:
            e = e + 1
            print(data[var2].iloc[po1, :])
        if m11:
            e = e + 1
            print(data[var2].iloc[po1, :])
        # if det:
            # m7 = p7.fullmatch(data[var2].iat[po1, 0])
            # m8 = p8.match(data[var2].iat[po1, 0])
            # m9 = p9.fullmatch(data[var2].iat[po1, 0])
            # m10 = p10.fullmatch(data[var2].iat[po1, 0])
            # m11 = p11.fullmatch(data[var2].iat[po1, 0])
            # if m7:
            #     e = e + 1
            #     print(data[var2].iloc[po1, :])
            # if m8:
            #     e = e + 1
            #     print(data[var2].iloc[po1, :])
            # if m9:
            #     e = e + 1
            #     print(data[var2].iloc[po1, :])
            # if m10:
            #     e = e + 1
            #     print(data[var2].iloc[po1, :])
            # if m11:
            #     e = e + 1
            #     print(data[var2].iloc[po1, :])
    if e != 4:
        print(e)
        # input("press enter to process")


# ================================================= 현금흐름표


def st_cf(var3):
    # print(data[sheet_name[4]])
    p9 = re.compile("[IⅠ.]*영업활동.*현금흐름|[IIⅡ.]*투자활동.*현금흐름|[IIIⅢ.]*재무활동.*현금흐름")
    for po1 in range(len(data[var3])):
        m9 = p9.match(data[var3].iat[po1, 0])
        if m9:
            print(data[var3].iloc[po1, :])
# ===================================================


kospi_list = pd.read_excel('E:\\유가증권목록.xlsx')

p1 = re.compile("보고서")
p2 = re.compile("법인명")
p3 = re.compile('통화')
p4 = re.compile('단위')
p5 = re.compile("자본")
p6 = re.compile('손익')

p10 = re.compile("재무")
p11 = re.compile("손익")
p12 = re.compile("현금")

files = glob.glob('E:\\연습용\\*.xls')  # 특정확장자를 가진 목록뽑기


for x in files:
    if not os.path.isdir(x):  # 파일만 걸러내기
        print(x)
        data = pd.read_excel(x, sheet_name=None)
        sheet_name = [i for i in data]
        if len(sheet_name) > 11:
            sheet_name = sheet_name[:11]

        df = data[sheet_name[0]]
        clm_nm = data[sheet_name[0]].columns[0]

        for i in df[clm_nm]:
            if i == i:
                m1 = p1.search(i)
                if m1:
                    doc_type = i.replace("보고서 유형 : ", "")
                    print(doc_type)
                m2 = p2.search(i)
                if m2:
                    crp_name = i.replace("법인명 : ", "").replace("주식회사", "").replace("(주)", "").replace(" ","").replace("자기관리부동산투자회사","리츠")
                    if crp_name == "와이지플러스":
                        crp_name = "YG PLUS"
                    if crp_name == "TBHGLOBAL":
                        crp_name = "티비에이치글로벌"
                    if crp_name == "디에스알제강":
                        crp_name = "DSR제강"
                    if crp_name == "위스컴":
                        crp_name = "WISCOM"
                    if crp_name == "한국유나이티드제약":
                        crp_name = "유나이티드"
                    if crp_name == "대우전자부품":
                        crp_name = "대우부품"
                    if crp_name == "일진디스플레이":
                        crp_name = "일진디스플"
                    if crp_name == "한국지역난방공사":
                        crp_name = "지역난방공사"
                    if crp_name == "제일연마공업":
                        crp_name = "제일연마"
                    if crp_name == "에이제이렌터카":
                        crp_name = "AJ렌터카"
                    if crp_name == "하이골드오션8호국제선박투자회사":
                        crp_name = "하이골드8호"
                    if crp_name == "에프앤에프":
                        crp_name = "F&F"
                    if crp_name == "그랜드코리아레저":
                        crp_name = "GKL"
                    if crp_name == "엔아이스틸":
                        crp_name = "NI스틸"
                    if crp_name == "Shinhung":
                        crp_name = "신흥"
                    if crp_name == "미원스페셜티케미칼":
                        crp_name = "미원에스씨"
                    if crp_name == "한전케이피에스":
                        crp_name = "한전KPS"
                    if crp_name == "일진다이아몬드":
                        crp_name = "일진다이아"
                    if crp_name == "세이브존아이앤씨":
                        crp_name = "세이브존I&C"
                    if crp_name == "케이티씨에스":
                        crp_name = "KTcs"
                    if crp_name == "에이프로젠케이아이씨":
                        crp_name = "에이프로젠 KIC"
                    if crp_name == "디알비동일":
                        crp_name = "DRB동일"
                    if crp_name == "한전산업개발":
                        crp_name = "한전산업"
                    if crp_name == "DBInc.":
                        crp_name = "DB"
                    if crp_name == "에이치디씨아이콘트롤스":
                        crp_name = "HDC아이콘트롤스"
                    if crp_name == "키스코홀딩스":
                        crp_name = "KISCO홀딩스"
                    if crp_name == "두산엔진":
                        crp_name = "HSD엔진"
                    if crp_name == "비지에프":
                        crp_name = "BGF"
                    if crp_name == "울촌화학":
                        crp_name = "율촌화학"
                    if crp_name == "동북아13호선박투자회사":
                        crp_name = "동북아13호선박투자"
                    if crp_name == "비지에프리테일":
                        crp_name = "BGF리테일"
                    if crp_name == "엘에스전선아시아":
                        crp_name = "LS전선아시아"
                    if crp_name == "팀스":
                        crp_name = "시디즈"
                    if crp_name == "동북아12호선박투자회사":
                        crp_name = "동북아13호선박투자"
                    if crp_name == "엘지이노텍":
                        crp_name = "LG이노텍"
                    if crp_name == "엘지디스플레이":
                        crp_name = "LG디스플레이"
                    if crp_name == "_인스코비":
                        crp_name = "인스코비"
                    if crp_name == "코오롱패션머티리얼":
                        crp_name = "코오롱머티리얼"
                    if crp_name == "무림피앤피":
                        crp_name = "무림P&P"
                    if crp_name == "코오롱인더스트리":
                        crp_name = "코오롱인더"
                    if crp_name == "비와이씨":
                        crp_name = "BYC"
                    if crp_name == "동아타이어공업":
                        crp_name = "동아타이어"
                    if crp_name == "선도전기사":
                        crp_name = "선도전기"
                    if crp_name == "한미글로벌건축사사무소":
                        crp_name = "한미글로벌"
                    if crp_name == "에스케이디앤디":
                        crp_name = "SK디앤디"
                    if crp_name == "에스케이씨":
                        crp_name = "SKC"
                    if crp_name == "바다로19호선박투자회사":
                        crp_name = "바다로19호"
                    if crp_name == "에쓰-오일":
                        crp_name = "S-Oil"
                    if crp_name == "한국항공우주산업":
                        crp_name = "한국항공우주"
                    if crp_name == "KT":
                        crp_name = "케이티"
                    if crp_name == "엔에이치엔엔터테인먼트":
                        crp_name = "NHN엔터테인먼트"
                    if crp_name == "NICE홀딩스":
                        crp_name = "NICE"
                    if crp_name == "엘지":
                        crp_name = "LG"
                    if crp_name == "지에스건설":
                        crp_name = "GS건설"
                    if crp_name == "케이이씨":
                        crp_name = "KEC"
                    if crp_name == "하이골드오션3호선박투자회사":
                        crp_name = "하이골드8호"
                    if crp_name == "에스케이디스커버리":
                        crp_name = "SK디스커버리"
                    if crp_name == "롯데제과㈜":
                        crp_name = "롯데제과"
                    if crp_name == "현대EP":
                        crp_name = "HDC현대EP"
                    if crp_name == "제이더블유생명과학":
                        crp_name = "JW생명과학"
                    if crp_name == "케이씨코트렐":
                        crp_name = "KC코트렐"
                    if crp_name == "씨제이씨지브이":
                        crp_name = "CJ CGV"
                    if crp_name == "에스케이케미칼":
                        crp_name = "SK케미칼"
                    if crp_name == "케이씨그린홀딩스":
                        crp_name = "KC그린홀딩스"
                    if crp_name == "신세계아이앤씨":
                        crp_name = "신세계I&C"
                    if crp_name == "에스피씨삼립":
                        crp_name = "SPC삼립"
                    if crp_name == "하이골드오션12호국제선박투자회사":
                        crp_name = "하이골드12호"
                    if crp_name == "네이버":
                        crp_name = "NAVER"
                    if crp_name == "씨에스윈드주식회":
                        crp_name = "씨에스윈드"
                    if crp_name == "효성ITX":
                        crp_name = "효성 ITX"
                    if crp_name == "코라오홀딩스":
                        crp_name = "엘브이엠씨"
                    if crp_name == "컨버":
                        crp_name = "컨버즈"
                    if crp_name == "현대산업개발":
                        crp_name = "HDC"
                    if crp_name == "한국전력기술":
                        crp_name = "한전기술"
                    if crp_name == "현대일렉트릭앤에너지시스템":
                        crp_name = "현대일렉트릭"
                    print(crp_name)
                    crp_data = kospi_list[kospi_list['회사명'] == crp_name]
                    crp_code = str(crp_data.iat[0, 1]).rjust(6, "0")
                    print(crp_name, crp_code)
                m3 = p3.search(i)
                if m3:
                    cash_code = i.replace("통화ISO코드 : ", "")
                    print(cash_code)
                m4 = p4.search(i)
                if m4:
                    unit = i.replace("단위정보(주석제외) : ", "")
                    print(unit)

        for j in range(1, len(sheet_name)):
            m5 = p5.search(sheet_name[j])
            m6 = p6.search(sheet_name[j])
            if m5:
                pass
            elif m6:
                df1 = data[sheet_name[j]]
                clm_nm1 = data[sheet_name[j]].columns[0]
                a = 0
                for k in df1[clm_nm1]:
                    m4 = p4.search(k)
                    if m4:
                        break
                    a = a + 1
                df = pd.DataFrame(data[sheet_name[j]][a + 3:])
                new_list = list(data[sheet_name[j]].iloc[a + 1])
                new_list[0] = df.columns[0]
                b = -1
                for i in new_list:
                    b = b + 1
                    if i != i:
                        # print(i)
                        new_list[b] = new_list[b - 1].replace(new_list[b - 1][-3:], "누적")
                        # print(new_list[b])
                df = df.reset_index(drop=True)
                df.columns = new_list
                data[sheet_name[j]] = df

            else:
                df1 = data[sheet_name[j]]
                clm_nm1 = data[sheet_name[j]].columns[0]
                a = 0
                for k in df1[clm_nm1]:
                    m4 = p4.search(k)
                    if m4:
                        break
                    a = a + 1

                df = pd.DataFrame(data[sheet_name[j]][a + 2:])
                new_list = list(data[sheet_name[j]].iloc[a + 1])
                new_list.remove(" ")
                new_list.insert(0, df.columns[0])
                df = df.reset_index(drop=True)
                df.columns = new_list
                data[sheet_name[j]] = df
        """
        for i in sheet_name[1:]:
            m10 = p10.search(i)
            if m10:
                bal_st(i)
        """
        item1 = 0
        item2 = 0
        item3 = 0
        item4 = 0
        for i in sheet_name:
            if "연결" in i:
                if "포괄손익" in i:
                    item2 = i
                elif "손익" in i:
                    item1 = i
            else:
                if "포괄손익" in i:
                    item4 = i
                elif "손익" in i:
                    item3 = i


        if item1 != 0:
            inc_st(item1)
        elif item2 != 0:
            inc_st(item2)
        if item3 != 0:
            inc_st(item3)
        elif item4 != 0:
            inc_st(item4)

        """
        for i in sheet_name:
            m12 = p12.search(i)
            if m12:
                st_cf(i)
        """

