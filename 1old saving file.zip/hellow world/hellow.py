# 특정 폴더의 파일 리스트 가져오기

import os
import openpyxl
import win32com.client


path_dir = r'C:\Users\RTH\Documents\계산'
file_list = os.listdir(path_dir)

file_list.sort()
path = path_dir+"\\"+file_list[0]

excel = win32com.client.Dispatch("Excel.Application")
excel.Visible = True
wb = excel.Workbooks.Open(path)
ws = wb.ActiveSheet
# print(ws.Cells(18,12))
# ws.Cells(422,2).Value = "=max(A18:A27)"

# for i in range(100):
#     print(ws.Cells(18+i, 12))

raw_data = ws.Range('B18:B77')
print(raw_data)

