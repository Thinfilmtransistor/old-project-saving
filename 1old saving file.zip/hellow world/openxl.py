import os
import win32com.client

# 경로 파일 내부 xls list 얻기

path_dir = r'C:\Users\RTH\Documents\#18-062\측정\180\180828'
file_list = os.listdir(path_dir)

file_list.sort()
path = path_dir+"\\"+file_list[0]

# print(file_list)
xllist = []
for i in file_list:
    if i[-3:] == "xls":
        xllist.append(i)
print(xllist)
# ===============================================================

# excel file에서 raw data 얻기

excel = win32com.client.Dispatch("Excel.Application")
excel.Visible = True
wb = excel.Workbooks.Open(path_dir + "\\" + xllist[1])

ws = wb.Worksheets["Data"]

gate_voltage = ws.Range('B2:B403')
drain_current1 = ws.Range('C2:C403')
drain_current2 = ws.Range('G2:G403')

# excel.Quit()  # 일일이 excel을 안닫고 workbook만 닫을 수 있지 않을까?
print(len(gate_voltage))
print(len(drain_current1))
print(len(drain_current2))
# =================================================================

# 계산 파일 만들기

path_dir2 = r'C:\Users\RTH\Documents\계산'
save_path = path_dir2 + "\\" + xllist[1]

wb1 = excel.Workbooks.Add()
ws1 = wb1.Worksheets["Sheet1"]

ws1.Cells(18, 1).Value = gate_voltage[0]
ws1.Cells(18, 2).Value = drain_current1[0]
ws1.Cells(18, 3).Value = drain_current2[0]
for i in range(401):
    print(gate_voltage[i])
    ws1.Cells(19 + i, 1).Value = gate_voltage[i]
for i in range(401):
    print(drain_current1[i])
    ws1.Cells(19 + i, 2).Value = drain_current1[i]

"""
for i in range(401):
    print(drain_current2[i])
    ws1.Cells(19 + i, 3).Value = drain_current2[i]

ws1.Cells(4,1).Value = "Device Structure"
ws1.Cells(5,1).Value = "GI"
ws1.Cells(6,1).Value = "W/L"
ws1.Cells(7,1).Value = "Cox(Geo)"
ws1.Cells(8,1).Value = "Cox(meas)"
ws1.Cells(9,1).Value = "Measurement Condition"
ws1.Cells(10,1).Value = "VD(lin)"
ws1.Cells(11,1).Value = "VD(sat)"
ws1.Cells(12,1).Value = "VD(sat)"

ws1.Cells(5,2).Value = 0.000011
ws1.Cells(6,2).Value = 2
ws1.Cells(7,2).Value = "=(8.85*10^-14)*7.6/B5"
ws1.Cells(10,2).Value = 0.5
ws1.Cells(11,2).Value = 5.5
ws1.Cells(12,2).Value = 0.2

ws1.Cells(5,3).Value = "cm"
ws1.Cells(7,3).Value = "F/cm2"
ws1.Cells(10,3).Value = "V"
ws1.Cells(11,3).Value = "V"
ws1.Cells(12,3).Value = "V"

ws1.Cells(4,5).Value = "calc process"
ws1.Cells(5,5).Value = "slope(ID)"
ws1.Cells(7,5).Value = "slope(SQRT ID)"
ws1.Cells(9,5).Value = "slope(gm)"
ws1.Cells(11,5).Value = "slope(SS)"

ws1.Cells(5,6).Value = "Intercept"
ws1.Cells(7,6).Value = "Intercept(SQRT)"
ws1.Cells(9,6).Value = "Intercept(gm)"
ws1.Cells(11,6).Value = "Intercept(SS)"

ws1.Cells(4,9).Value = "device parameter"
ws1.Cells(5,9).Value = "VT"
ws1.Cells(6,9).Value = "μ(sat)"
ws1.Cells(7,9).Value = "μ(lin)"
ws1.Cells(8,9).Value = "SS"

ws1.Cells(16,1).Value = "raw data"
ws1.Cells(17,1).Value = "ID(0.5)"
ws1.Cells(17,2).Value = "ID(5.5)"
ws1.Cells(17,3).Value = "ID(0.5)근사"
ws1.Cells(17,4).Value = "gm0.5"
ws1.Cells(17,5).Value = "ID sqrt"
ws1.Cells(17,6).Value = "slop sqrt"
ws1.Cells(17,7).Value = "tangent sqrt"
ws1.Cells(17,8).Value = "slope gm"
ws1.Cells(17,9).Value = "log ID"
ws1.Cells(17,10).Value = "slope SS"
ws1.Cells(17,11).Value = "tangent logID"

# ===========================================
# linear region


"""

for i in range(401):
    ws1.Cells(18 + i, 4).Value = "=(B" + str(19 + i) + "-B" + str(18 + i) + ")/$B$12"


ws1.Cells(17,11).Value = "tangent logID"
ws1.Cells(17,11).Value = "tangent logID"
ws1.Cells(17,11).Value = "tangent logID"











